/**
 * Roohsites Appointment Booking → Settings: the currency symbol follows the Currency dropdown as soon as it changes.
 * Choosing "Other" unlocks the box so the owner can type their own symbol.
 */
( function () {
	'use strict';

	var select = document.getElementById( 'rsab-currency-code' );
	var symbol = document.getElementById( 'rsab-currency' );
	if ( ! select || ! symbol ) {
		return;
	}

	function sync( focus ) {
		var option = select.options[ select.selectedIndex ];
		var chosen = option ? option.getAttribute( 'data-symbol' ) : null;

		if ( chosen ) {
			symbol.value = chosen;
			symbol.readOnly = true;
			return;
		}
		symbol.readOnly = false;
		if ( focus ) {
			symbol.focus();
			symbol.select();
		}
	}

	select.addEventListener( 'change', function () {
		sync( true );
	} );
	sync( false );
}() );
