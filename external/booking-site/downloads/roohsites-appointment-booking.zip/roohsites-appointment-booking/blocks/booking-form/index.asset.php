<?php
defined( 'ABSPATH' ) || exit;

return array(
	'dependencies' => array( 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n', 'wp-shortcode' ),
	'version'      => RSAB_VERSION,
);
