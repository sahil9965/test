<?php
namespace RSAB;

defined( 'ABSPATH' ) || exit;

/**
 * Admin menu and the Bookings screen.
 */
final class Admin {

	const MENU_SLUG = 'rsab';

	public static function init() {
		// Priority 9 so the parent menu exists before WordPress attaches the post type submenus.
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 9 );
		add_action( 'admin_menu', array( __CLASS__, 'settings_menu' ), 20 );
		add_filter( 'plugin_action_links_' . plugin_basename( RSAB_FILE ), array( __CLASS__, 'action_links' ) );
		add_action( 'admin_notices', array( __CLASS__, 'timezone_notice' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function assets( $hook ) {
		if ( 'toplevel_page_' . self::MENU_SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'rsab-admin', RSAB_URL . 'assets/css/admin.css', array(), Plugin::asset_version( 'assets/css/admin.css' ) );
	}

	/**
	 * The summary cards on top of the Bookings screen. Each one opens the matching list below.
	 *
	 * @return array[] Cards with 'key', 'label', 'value', 'hint' and 'view' (a list view, or '' for no link).
	 */
	public static function cards() {
		$statuses = Bookings::statuses();
		$cards    = array(
			array(
				'key'   => 'all',
				'label' => __( 'Total bookings', 'roohsites-appointment-booking' ),
				'value' => Bookings::count( 'all' ),
				'hint'  => __( 'All time', 'roohsites-appointment-booking' ),
				'view'  => 'all',
			),
			array(
				'key'   => 'today',
				'label' => __( 'Today', 'roohsites-appointment-booking' ),
				'value' => Bookings::count( 'today' ),
				'hint'  => wp_date( get_option( 'date_format' ) ),
				'view'  => 'today',
			),
			array(
				'key'   => 'upcoming',
				'label' => __( 'Upcoming', 'roohsites-appointment-booking' ),
				'value' => Bookings::count( 'upcoming' ),
				'hint'  => __( 'From now on', 'roohsites-appointment-booking' ),
				'view'  => 'upcoming',
			),
			array(
				'key'   => 'pending',
				'label' => __( 'Waiting for approval', 'roohsites-appointment-booking' ),
				'value' => Bookings::count( 'pending' ),
				'hint'  => __( 'Confirm or cancel', 'roohsites-appointment-booking' ),
				'view'  => 'pending',
				'alert' => true,
			),
		);
		if ( isset( $statuses['awaiting_payment'] ) ) {
			$cards[] = array(
				'key'   => 'awaiting_payment',
				'label' => $statuses['awaiting_payment'],
				'value' => Bookings::count( 'awaiting_payment' ),
				'hint'  => __( 'Not paid yet', 'roohsites-appointment-booking' ),
				'view'  => 'awaiting_payment',
			);
		}
		$cards[] = array(
			'key'   => 'month',
			'label' => __( 'This month', 'roohsites-appointment-booking' ),
			'value' => Bookings::count( 'month' ),
			'hint'  => wp_date( 'F Y' ),
			'view'  => 'month',
		);
		$cards[] = array(
			'key'   => 'cancelled',
			'label' => __( 'Cancelled', 'roohsites-appointment-booking' ),
			'value' => Bookings::count( 'cancelled' ),
			'hint'  => __( 'All time', 'roohsites-appointment-booking' ),
			'view'  => 'cancelled',
		);

		/**
		 * Filters the summary cards on the Bookings screen (Pro adds revenue).
		 *
		 * @param array[] $cards See Admin::cards().
		 */
		return apply_filters( 'rsab_dashboard_cards', $cards );
	}

	private static function render_cards( $current ) {
		$cards = self::cards();
		// Even rows: 8 cards (with Pro) as 4 + 4, 6 cards as 3 + 3.
		$cols = ( 0 === count( $cards ) % 3 && count( $cards ) <= 6 ) ? 3 : 4;
		echo '<ul class="rsab-cards rsab-cards-' . (int) $cols . '" aria-label="' . esc_attr__( 'Summary', 'roohsites-appointment-booking' ) . '">';
		foreach ( $cards as $card ) {
			$value = is_numeric( $card['value'] ) ? number_format_i18n( (float) $card['value'] ) : (string) $card['value'];
			$class = 'rsab-card' . ( ! empty( $card['alert'] ) && (int) $card['value'] > 0 ? ' is-alert' : '' ) . ( $card['view'] && $card['view'] === $current ? ' is-current' : '' );
			$inner = '<span class="rsab-card-label">' . esc_html( $card['label'] ) . '</span><span class="rsab-card-value">' . esc_html( $value ) . '</span><span class="rsab-card-hint">' . esc_html( $card['hint'] ) . '</span>';
			if ( $card['view'] ) {
				$url = add_query_arg( array( 'page' => self::MENU_SLUG, 'view' => $card['view'] ), admin_url( 'admin.php' ) );
				echo '<li><a class="' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '"' . ( $card['view'] === $current ? ' aria-current="page"' : '' ) . '>' . $inner . '</a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $inner is escaped above.
			} else {
				echo '<li><div class="' . esc_attr( $class ) . '">' . $inner . '</div></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $inner is escaped above.
			}
		}
		echo '</ul>';
	}

	/**
	 * New WordPress sites use UTC, so customers would see booking times in the wrong time zone.
	 */
	public static function timezone_notice() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || false === strpos( (string) $screen->id, 'rsab' ) || ! current_user_can( 'manage_options' ) || ! Settings::timezone_looks_unset() ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p><strong>%1$s</strong> %2$s <a href="%3$s">%4$s</a></p></div>',
			esc_html__( 'Your site’s time zone is UTC.', 'roohsites-appointment-booking' ),
			esc_html__( 'Customers will see booking times in UTC, which is probably not your local time. Choose your city under Timezone. If the list only shows UTC offsets, choose yours instead (for example UTC+5:30 for India).', 'roohsites-appointment-booking' ),
			esc_url( admin_url( 'options-general.php#timezone_string' ) ),
			esc_html__( 'Open the time zone setting', 'roohsites-appointment-booking' )
		);
	}

	public static function menu() {
		$hook = add_menu_page(
			__( 'Bookings', 'roohsites-appointment-booking' ),
			__( 'Rooh Sites', 'roohsites-appointment-booking' ),
			Plugin::capability(),
			self::MENU_SLUG,
			array( __CLASS__, 'render_bookings' ),
			'dashicons-calendar-alt',
			26
		);

		add_submenu_page( self::MENU_SLUG, __( 'Bookings', 'roohsites-appointment-booking' ), __( 'Bookings', 'roohsites-appointment-booking' ), Plugin::capability(), self::MENU_SLUG, array( __CLASS__, 'render_bookings' ) );

		add_action( 'load-' . $hook, array( __CLASS__, 'handle_action' ) );
	}

	public static function settings_menu() {
		add_submenu_page( self::MENU_SLUG, __( 'Roohsites Appointment Booking Settings', 'roohsites-appointment-booking' ), __( 'Settings', 'roohsites-appointment-booking' ), Plugin::capability(), 'rsab-settings', array( 'RSAB\Settings', 'render_page' ) );
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=rsab-settings' ) ) . '">' . esc_html__( 'Settings', 'roohsites-appointment-booking' ) . '</a>' );
		if ( self::upgrade_url() ) {
			$links[] = '<a href="' . esc_url( self::upgrade_url() ) . '" target="_blank" rel="noopener" style="color:#00a32a;font-weight:600">' . esc_html__( 'Get Pro', 'roohsites-appointment-booking' ) . '</a>';
		}
		return $links;
	}

	/**
	 * Where "Get Pro" links point. Empty (links hidden) once Pro is installed.
	 * Filter rsab_upgrade_url to change it, or return '' to hide the links.
	 */
	public static function upgrade_url() {
		if ( defined( 'RSAB_PRO_VERSION' ) ) {
			return '';
		}
		return (string) apply_filters( 'rsab_upgrade_url', 'https://booking.roohsites.com/#pricing' );
	}

	/**
	 * A short Pro card for the Settings screen.
	 */
	public static function render_upgrade_card() {
		$url = self::upgrade_url();
		if ( ! $url ) {
			return;
		}
		$features = array(
			__( 'Online payments and deposits — Razorpay (UPI), Stripe, PayPal', 'roohsites-appointment-booking' ),
			__( 'SMS and WhatsApp reminders that cut no-shows', 'roohsites-appointment-booking' ),
			__( 'Two-way Google Calendar sync', 'roohsites-appointment-booking' ),
			__( 'Drag-and-drop admin calendar', 'roohsites-appointment-booking' ),
			__( 'Customer rescheduling, extras, coupons and branded emails', 'roohsites-appointment-booking' ),
		);
		?>
		<div style="max-width:640px;margin-top:32px;padding:20px 24px;background:#fff;border:1px solid #dcdcde;border-left:4px solid #4f46e5;border-radius:6px">
			<h2 style="margin-top:0"><?php esc_html_e( 'Get paid and stop no-shows with Roohsites Appointment Booking Pro', 'roohsites-appointment-booking' ); ?></h2>
			<ul style="list-style:disc;margin-left:20px">
				<?php foreach ( $features as $feature ) : ?>
					<li><?php echo esc_html( $feature ); ?></li>
				<?php endforeach; ?>
			</ul>
			<p><a class="button button-primary" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'See Pro plans', 'roohsites-appointment-booking' ); ?></a></p>
		</div>
		<?php
	}

	public static function action_url( $action, $id ) {
		return wp_nonce_url(
			add_query_arg(
				array(
					'page'          => self::MENU_SLUG,
					'rsab_do'  => $action,
					'booking'       => (int) $id,
				),
				admin_url( 'admin.php' )
			),
			'rsab_' . $action . '_' . (int) $id
		);
	}

	/**
	 * Runs before the Bookings screen renders, so it can redirect.
	 */
	public static function handle_action() {
		if ( empty( $_GET['rsab_do'] ) || empty( $_GET['booking'] ) ) {
			return;
		}

		$action = sanitize_key( wp_unslash( $_GET['rsab_do'] ) );
		$id     = absint( $_GET['booking'] );

		check_admin_referer( 'rsab_' . $action . '_' . $id );

		if ( ! current_user_can( Plugin::capability() ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'roohsites-appointment-booking' ), 403 );
		}

		$done = '';
		if ( 'confirm' === $action && Bookings::update_status( $id, 'confirmed' ) ) {
			$done = 'confirmed';
		} elseif ( 'cancel' === $action && Bookings::update_status( $id, 'cancelled' ) ) {
			$done = 'cancelled';
		} elseif ( 'delete' === $action && Bookings::delete( $id ) ) {
			$done = 'deleted';
		}

		$back = remove_query_arg( array( 'rsab_do', 'booking', '_wpnonce' ), wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=' . self::MENU_SLUG ) );
		wp_safe_redirect( add_query_arg( 'rsab_done', $done, $back ) );
		exit;
	}

	public static function render_bookings() {
		require_once RSAB_DIR . 'includes/class-bookings-table.php';

		$table = new Bookings_Table();
		$table->prepare_items();

		$notices = array(
			'confirmed' => __( 'Booking confirmed. The customer has been emailed.', 'roohsites-appointment-booking' ),
			'cancelled' => __( 'Booking cancelled. The customer has been emailed.', 'roohsites-appointment-booking' ),
			'deleted'   => __( 'Booking deleted.', 'roohsites-appointment-booking' ),
		);
		$done = isset( $_GET['rsab_done'] ) ? sanitize_key( wp_unslash( $_GET['rsab_done'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Bookings', 'roohsites-appointment-booking' ); ?></h1>
			<hr class="wp-header-end">

			<?php if ( isset( $notices[ $done ] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $notices[ $done ] ); ?></p></div>
			<?php endif; ?>

			<?php if ( ( ! Post_Types::services() || ! Post_Types::staff() ) && Setup::finished() ) : ?>
				<div class="notice notice-info">
					<p>
						<a href="<?php echo esc_url( Setup::url( 'business' ) ); ?>"><?php esc_html_e( 'Run the setup wizard', 'roohsites-appointment-booking' ); ?></a>, <?php esc_html_e( 'or get started in three steps:', 'roohsites-appointment-booking' ); ?>
						<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . Post_Types::SERVICE ) ); ?>"><?php esc_html_e( '1. Add a service', 'roohsites-appointment-booking' ); ?></a>,
						<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . Post_Types::STAFF ) ); ?>"><?php esc_html_e( '2. Add a staff member', 'roohsites-appointment-booking' ); ?></a>,
						<?php esc_html_e( '3. Add the Booking form block (or the [rsab_booking] shortcode) to a page.', 'roohsites-appointment-booking' ); ?>
					</p>
				</div>
			<?php endif; ?>

			<?php self::render_cards( $table->current_view() ); ?>

			<?php $table->views(); ?>
			<form method="get">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::MENU_SLUG ); ?>">
				<?php $table->display(); ?>
			</form>
		</div>
		<?php
	}
}
