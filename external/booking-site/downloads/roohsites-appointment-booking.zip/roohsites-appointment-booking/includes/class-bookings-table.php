<?php
namespace RSAB;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * The table on Roohsites Appointment Booking → Bookings.
 */
final class Bookings_Table extends \WP_List_Table {

	private $view = 'upcoming';

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'booking',
				'plural'   => 'bookings',
				'ajax'     => false,
			)
		);

		$views = array_merge( array( 'upcoming', 'past', 'today', 'month', 'all' ), array_keys( Bookings::statuses() ) );
		$view  = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( in_array( $view, $views, true ) ) {
			$this->view = $view;
		}
	}

	public function current_view() {
		return $this->view;
	}

	public function get_columns() {
		return array(
			'when'     => __( 'When', 'roohsites-appointment-booking' ),
			'customer' => __( 'Customer', 'roohsites-appointment-booking' ),
			'service'  => __( 'Service', 'roohsites-appointment-booking' ),
			'staff'    => __( 'Staff', 'roohsites-appointment-booking' ),
			'status'   => __( 'Status', 'roohsites-appointment-booking' ),
			'notes'    => __( 'Notes', 'roohsites-appointment-booking' ),
		);
	}

	protected function get_views() {
		$labels = array( 'upcoming' => __( 'Upcoming', 'roohsites-appointment-booking' ) ) + Bookings::statuses() + array( 'past' => __( 'Past', 'roohsites-appointment-booking' ) );

		$views = array();
		foreach ( $labels as $key => $label ) {
			$url           = add_query_arg(
				array(
					'page' => Admin::MENU_SLUG,
					'view' => $key,
				),
				admin_url( 'admin.php' )
			);
			$views[ $key ] = sprintf(
				'<a href="%s"%s>%s <span class="count">(%d)</span></a>',
				esc_url( $url ),
				$key === $this->view ? ' class="current" aria-current="page"' : '',
				esc_html( $label ),
				Bookings::count( $key )
			);
		}
		return $views;
	}

	public function prepare_items() {
		$per_page = 20;
		$page     = $this->get_pagenum();

		list( $rows, $total ) = Bookings::query( $this->view, $per_page, $page );

		$this->items           = $rows;
		$this->_column_headers = array( $this->get_columns(), array(), array() );
		$this->set_pagination_args(
			array(
				'total_items' => $total,
				'per_page'    => $per_page,
			)
		);
	}

	public function no_items() {
		esc_html_e( 'No bookings here yet.', 'roohsites-appointment-booking' );
	}

	protected function column_when( $item ) {
		$start   = Bookings::start_timestamp( $item );
		$end     = strtotime( $item['end_at'] . ' UTC' );
		$out     = '<strong>' . esc_html( wp_date( get_option( 'date_format' ), $start ) ) . '</strong><br>';
		$out    .= esc_html( wp_date( get_option( 'time_format' ), $start ) . ' – ' . wp_date( get_option( 'time_format' ), $end ) );
		$actions = array();

		if ( 'pending' === $item['status'] ) {
			$actions['confirm'] = sprintf( '<a href="%s">%s</a>', esc_url( Admin::action_url( 'confirm', $item['id'] ) ), esc_html__( 'Confirm', 'roohsites-appointment-booking' ) );
		}
		if ( 'cancelled' !== $item['status'] ) {
			$actions['cancel'] = sprintf(
				'<a href="%s" onclick="return confirm(%s)">%s</a>',
				esc_url( Admin::action_url( 'cancel', $item['id'] ) ),
				esc_attr( wp_json_encode( __( 'Cancel this booking and email the customer?', 'roohsites-appointment-booking' ) ) ),
				esc_html__( 'Cancel', 'roohsites-appointment-booking' )
			);
		}
		$actions['delete'] = sprintf(
			'<a href="%s" class="submitdelete" onclick="return confirm(%s)">%s</a>',
			esc_url( Admin::action_url( 'delete', $item['id'] ) ),
			esc_attr( wp_json_encode( __( 'Permanently delete this booking? No email is sent.', 'roohsites-appointment-booking' ) ) ),
			esc_html__( 'Delete', 'roohsites-appointment-booking' )
		);

		/**
		 * Row actions under a booking in the admin list.
		 *
		 * @param string[] $actions HTML links keyed by action.
		 * @param array    $booking The booking row.
		 */
		$actions = apply_filters( 'rsab_row_actions', $actions, $item );

		return $out . $this->row_actions( $actions );
	}

	protected function column_customer( $item ) {
		$out = esc_html( $item['customer_name'] ) . '<br><a href="mailto:' . esc_attr( $item['customer_email'] ) . '">' . esc_html( $item['customer_email'] ) . '</a>';
		if ( '' !== $item['customer_phone'] ) {
			$out .= '<br>' . esc_html( $item['customer_phone'] );
		}
		return $out;
	}

	protected function column_service( $item ) {
		$title = Post_Types::title( (int) $item['service_id'] );
		return '' !== $title ? esc_html( $title ) : '&mdash;';
	}

	protected function column_staff( $item ) {
		$title = Post_Types::title( (int) $item['staff_id'] );
		return '' !== $title ? esc_html( $title ) : '&mdash;';
	}

	protected function column_status( $item ) {
		$colors = array(
			'pending'   => '#996800',
			'confirmed' => '#007017',
			'cancelled' => '#8a2424',
		);
		$color  = isset( $colors[ $item['status'] ] ) ? $colors[ $item['status'] ] : 'inherit';
		return '<span style="color:' . esc_attr( $color ) . ';font-weight:600">' . esc_html( Bookings::status_label( $item['status'] ) ) . '</span>';
	}

	protected function column_notes( $item ) {
		$lines = '' !== (string) $item['notes'] ? array( $item['notes'] ) : array();

		/**
		 * Extra lines shown with a booking in the admin list (e.g. extras, custom fields, payment).
		 *
		 * @param string[] $lines   Plain-text lines.
		 * @param array    $booking The booking row.
		 */
		$lines = apply_filters( 'rsab_booking_details', $lines, $item );

		return $lines ? nl2br( esc_html( implode( "\n", $lines ) ) ) : '&mdash;';
	}
}
