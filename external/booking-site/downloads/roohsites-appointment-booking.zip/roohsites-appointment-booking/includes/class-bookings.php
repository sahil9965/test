<?php
namespace RSAB;

use WP_Error;

defined( 'ABSPATH' ) || exit;

// Bookings live in the plugin's own table, so direct queries are expected here; results are not cached
// because availability must always reflect the latest bookings.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

/**
 * Reads and writes rows in the bookings table.
 */
final class Bookings {

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'rsab_bookings';
	}

	/**
	 * All statuses, keyed by status => label. Add-ons may add their own (e.g. awaiting payment).
	 * Any status other than 'cancelled' keeps the time slot reserved.
	 */
	public static function statuses() {
		return apply_filters(
			'rsab_statuses',
			array(
				'pending'   => __( 'Pending', 'roohsites-appointment-booking' ),
				'confirmed' => __( 'Confirmed', 'roohsites-appointment-booking' ),
				'cancelled' => __( 'Cancelled', 'roohsites-appointment-booking' ),
			)
		);
	}

	public static function status_label( $status ) {
		$labels = self::statuses();
		return isset( $labels[ $status ] ) ? $labels[ $status ] : $status;
	}

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', self::table(), $id ), ARRAY_A );
	}

	public static function get_by_token( $token ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE token = %s', self::table(), $token ), ARRAY_A );
	}

	/**
	 * Active (not cancelled) bookings for a staff member that touch the given UTC range.
	 */
	public static function active_for_staff( $staff_id, $from_utc, $to_utc, $ignore_id = 0 ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT start_at, blocked_until FROM %i WHERE staff_id = %d AND status <> 'cancelled' AND start_at < %s AND blocked_until > %s AND id <> %d",
				self::table(),
				$staff_id,
				$to_utc,
				$from_utc,
				(int) $ignore_id
			),
			ARRAY_A
		);
	}

	/**
	 * Validates the slot and stores a new booking.
	 *
	 * @param array                 $data    service_id, staff_id (0 = any), start (Unix timestamp), extra_minutes, name, email, phone, notes.
	 * @param \WP_REST_Request|null $request The original request, passed on to add-ons.
	 * @return array|WP_Error The new booking row.
	 */
	public static function create( array $data, $request = null ) {
		global $wpdb;

		$service = Post_Types::service( $data['service_id'] );
		if ( ! $service ) {
			return new WP_Error( 'rsab_invalid_service', __( 'Please choose a valid service.', 'roohsites-appointment-booking' ), array( 'status' => 400 ) );
		}

		$start = (int) $data['start'];
		$date  = wp_date( 'Y-m-d', $start );
		$extra = isset( $data['extra_minutes'] ) ? max( 0, (int) $data['extra_minutes'] ) : 0;

		// Serialize booking attempts so two customers cannot take the same slot.
		// Some databases (e.g. SQLite) do not support GET_LOCK; booking still works there.
		$suppress = $wpdb->suppress_errors( true );
		$locked   = $wpdb->get_var( "SELECT GET_LOCK('rsab_booking', 5)" );
		$wpdb->suppress_errors( $suppress );

		if ( '0' === $locked ) {
			return new WP_Error( 'rsab_busy', __( 'We are busy right now. Please try again.', 'roohsites-appointment-booking' ), array( 'status' => 503 ) );
		}

		try {
			$slots = Availability::slots( $service['id'], (int) $data['staff_id'], $date, $extra );
			if ( empty( $slots[ $start ] ) ) {
				return new WP_Error( 'rsab_slot_taken', __( 'Sorry, that time is no longer available. Please pick another.', 'roohsites-appointment-booking' ), array( 'status' => 409 ) );
			}

			$staff_id = (int) $data['staff_id'] ? (int) $data['staff_id'] : (int) $slots[ $start ][0];
			$end      = $start + ( $service['duration'] + $extra ) * MINUTE_IN_SECONDS;
			$blocked  = $end + $service['buffer'] * MINUTE_IN_SECONDS;

			$row = array(
				'service_id'     => $service['id'],
				'staff_id'       => $staff_id,
				'start_at'       => gmdate( 'Y-m-d H:i:s', $start ),
				'end_at'         => gmdate( 'Y-m-d H:i:s', $end ),
				'blocked_until'  => gmdate( 'Y-m-d H:i:s', $blocked ),
				/**
				 * Filters the status a new booking starts with (e.g. 'awaiting_payment').
				 *
				 * @param string $status Default from settings: 'pending' or 'confirmed'.
				 * @param array  $data   Booking data.
				 * @param mixed  $request The REST request, if any.
				 */
				'status'         => apply_filters( 'rsab_initial_status', Settings::get( 'default_status' ), $data, $request ),
				'customer_name'  => $data['name'],
				'customer_email' => $data['email'],
				'customer_phone' => $data['phone'],
				'notes'          => $data['notes'],
				'token'          => bin2hex( random_bytes( 16 ) ),
				'created_at'     => gmdate( 'Y-m-d H:i:s' ),
			);

			if ( ! $wpdb->insert( self::table(), $row ) ) {
				return new WP_Error( 'rsab_db_error', __( 'Your booking could not be saved. Please try again.', 'roohsites-appointment-booking' ), array( 'status' => 500 ) );
			}
		} finally {
			if ( $locked ) {
				$wpdb->query( "SELECT RELEASE_LOCK('rsab_booking')" );
			}
		}

		$booking = self::get( $wpdb->insert_id );

		/**
		 * Fires after a customer books an appointment.
		 *
		 * @param array $booking The booking row.
		 * @param array $data    The booking data that was submitted.
		 * @param mixed $request The REST request, if any.
		 */
		do_action( 'rsab_booking_created', $booking, $data, $request );

		return $booking;
	}

	/**
	 * Moves a booking to a new start time (and optionally another staff member), keeping its length.
	 *
	 * @param bool $check Whether to require the new time to be free.
	 * @return array|WP_Error The updated booking row.
	 */
	public static function move( $id, $start, $staff_id = 0, $check = true, $by = 'admin' ) {
		global $wpdb;

		$booking = self::get( $id );
		if ( ! $booking ) {
			return new WP_Error( 'rsab_not_found', __( 'Booking not found.', 'roohsites-appointment-booking' ), array( 'status' => 404 ) );
		}

		$staff_id = $staff_id ? (int) $staff_id : (int) $booking['staff_id'];
		$old_from = self::start_timestamp( $booking );
		$length   = strtotime( $booking['end_at'] . ' UTC' ) - $old_from;
		$buffer   = strtotime( $booking['blocked_until'] . ' UTC' ) - strtotime( $booking['end_at'] . ' UTC' );
		$service  = Post_Types::service( $booking['service_id'] );
		$extra    = $service ? max( 0, (int) round( $length / MINUTE_IN_SECONDS ) - $service['duration'] ) : 0;

		if ( $check ) {
			$slots = Availability::slots( $booking['service_id'], $staff_id, wp_date( 'Y-m-d', $start ), $extra, $booking['id'] );
			if ( empty( $slots[ $start ] ) ) {
				return new WP_Error( 'rsab_slot_taken', __( 'Sorry, that time is no longer available. Please pick another.', 'roohsites-appointment-booking' ), array( 'status' => 409 ) );
			}
		}

		$wpdb->update(
			self::table(),
			array(
				'staff_id'      => $staff_id,
				'start_at'      => gmdate( 'Y-m-d H:i:s', $start ),
				'end_at'        => gmdate( 'Y-m-d H:i:s', $start + $length ),
				'blocked_until' => gmdate( 'Y-m-d H:i:s', $start + $length + $buffer ),
			),
			array( 'id' => (int) $id )
		);

		$updated = self::get( $id );

		/**
		 * Fires after a booking moves to a new time.
		 *
		 * @param array  $updated The updated booking row.
		 * @param array  $booking The booking before the move.
		 * @param string $by      'admin' or 'customer'.
		 */
		do_action( 'rsab_booking_moved', $updated, $booking, $by );

		return $updated;
	}

	/**
	 * @param string $by Who made the change: 'admin' or 'customer'.
	 */
	public static function update_status( $id, $status, $by = 'admin' ) {
		global $wpdb;

		$booking = self::get( $id );
		if ( ! $booking || ! isset( self::statuses()[ $status ] ) || $booking['status'] === $status ) {
			return false;
		}

		$wpdb->update( self::table(), array( 'status' => $status ), array( 'id' => (int) $id ) );

		$old               = $booking['status'];
		$booking['status'] = $status;

		/**
		 * Fires after a booking's status changes.
		 *
		 * @param array  $booking    The updated booking row.
		 * @param string $old_status Previous status.
		 * @param string $by         'admin' or 'customer'.
		 */
		do_action( 'rsab_booking_status_changed', $booking, $old, $by );

		return true;
	}

	public static function delete( $id ) {
		global $wpdb;
		return (bool) $wpdb->delete( self::table(), array( 'id' => (int) $id ) );
	}

	/**
	 * Paged list for the admin screen.
	 *
	 * @param string $view 'upcoming', 'past', or a status.
	 */
	public static function query( $view, $per_page, $page ) {
		global $wpdb;

		$table  = self::table();
		$now    = gmdate( 'Y-m-d H:i:s' );
		$offset = ( $page - 1 ) * $per_page;

		if ( in_array( $view, array( 'today', 'month' ), true ) ) {
			list( $from, $to ) = self::local_range( $view );
			$total = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE start_at >= %s AND start_at < %s AND status <> 'cancelled'", $table, $from, $to ) );
			$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i WHERE start_at >= %s AND start_at < %s AND status <> 'cancelled' ORDER BY start_at ASC LIMIT %d OFFSET %d", $table, $from, $to, $per_page, $offset ), ARRAY_A );
		} elseif ( 'all' === $view ) {
			$total = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $table ) );
			$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i ORDER BY start_at DESC LIMIT %d OFFSET %d', $table, $per_page, $offset ), ARRAY_A );
		} elseif ( 'past' === $view ) {
			$total = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE start_at < %s', $table, $now ) );
			$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE start_at < %s ORDER BY start_at DESC LIMIT %d OFFSET %d', $table, $now, $per_page, $offset ), ARRAY_A );
		} elseif ( isset( self::statuses()[ $view ] ) ) {
			$total = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE status = %s', $table, $view ) );
			$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE status = %s ORDER BY start_at DESC LIMIT %d OFFSET %d', $table, $view, $per_page, $offset ), ARRAY_A );
		} else {
			$total = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE start_at >= %s AND status <> 'cancelled'", $table, $now ) );
			$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i WHERE start_at >= %s AND status <> 'cancelled' ORDER BY start_at ASC LIMIT %d OFFSET %d", $table, $now, $per_page, $offset ), ARRAY_A );
		}

		return array( $rows, (int) $total );
	}

	/**
	 * Start and end (UTC, MySQL format) of today or this month in the site's time zone.
	 *
	 * @param string $what 'today' or 'month'.
	 * @return string[] [from, to), the end is exclusive.
	 */
	public static function local_range( $what ) {
		$now   = new \DateTimeImmutable( 'now', wp_timezone() );
		$start = 'month' === $what ? $now->modify( 'first day of this month' )->setTime( 0, 0 ) : $now->setTime( 0, 0 );
		$end   = 'month' === $what ? $start->modify( 'first day of next month' ) : $start->modify( '+1 day' );
		$utc   = new \DateTimeZone( 'UTC' );
		return array( $start->setTimezone( $utc )->format( 'Y-m-d H:i:s' ), $end->setTimezone( $utc )->format( 'Y-m-d H:i:s' ) );
	}

	public static function count( $view ) {
		list( , $total ) = self::query( $view, 1, 1 );
		return $total;
	}

	public static function start_timestamp( array $booking ) {
		return strtotime( $booking['start_at'] . ' UTC' );
	}

	public static function format_when( array $booking ) {
		return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), self::start_timestamp( $booking ) );
	}
}
