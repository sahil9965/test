<?php
namespace RSAB;

defined( 'ABSPATH' ) || exit;

/**
 * Plain-text notification emails for customers, staff and the site owner.
 *
 * Every email has a type so add-ons can restyle or replace it through the
 * rsab_email filter: customer_received, customer_confirmed, customer_cancelled,
 * customer_moved, team_new, team_cancelled, team_moved.
 */
final class Emails {

	/** Statuses that mean the booking is real (not, say, waiting for payment). */
	const LIVE = array( 'pending', 'confirmed' );

	public static function init() {
		add_action( 'rsab_booking_created', array( __CLASS__, 'on_created' ) );
		add_action( 'rsab_booking_status_changed', array( __CLASS__, 'on_status_changed' ), 10, 3 );
		add_action( 'rsab_booking_moved', array( __CLASS__, 'on_moved' ), 10, 3 );
	}

	public static function on_created( $booking ) {
		// Bookings held for an add-on step (e.g. payment) are announced once they go live.
		if ( ! in_array( $booking['status'], self::LIVE, true ) ) {
			return;
		}

		$site = self::site_name();

		if ( 'confirmed' === $booking['status'] ) {
			/* translators: %s: site name */
			self::to_customer( 'customer_confirmed', $booking, sprintf( __( 'Your booking at %s is confirmed', 'roohsites-appointment-booking' ), $site ), __( 'Your appointment is confirmed. Here are the details:', 'roohsites-appointment-booking' ) );
		} else {
			/* translators: %s: site name */
			self::to_customer( 'customer_received', $booking, sprintf( __( 'We received your booking request at %s', 'roohsites-appointment-booking' ), $site ), __( 'Thanks for your request. We will email you again once it is confirmed. Here are the details:', 'roohsites-appointment-booking' ) );
		}

		/* translators: 1: service name, 2: date and time */
		$subject = sprintf( __( 'New booking: %1$s on %2$s', 'roohsites-appointment-booking' ), Post_Types::title( (int) $booking['service_id'] ), Bookings::format_when( $booking ) );
		$body    = __( 'A new booking was made:', 'roohsites-appointment-booking' ) . "\n\n" . self::details( $booking, true );
		if ( 'pending' === $booking['status'] ) {
			$body .= "\n\n" . __( 'It is waiting for your approval:', 'roohsites-appointment-booking' ) . "\n" . admin_url( 'admin.php?page=' . Admin::MENU_SLUG . '&view=pending' );
		}
		self::to_team( 'team_new', $booking, $subject, $body );
	}

	public static function on_status_changed( $booking, $old, $by ) {
		$site = self::site_name();

		// A held booking just went live: send the usual "new booking" emails.
		if ( ! in_array( $old, self::LIVE, true ) && in_array( $booking['status'], self::LIVE, true ) ) {
			self::on_created( $booking );
			return;
		}

		if ( 'confirmed' === $booking['status'] ) {
			/* translators: %s: site name */
			self::to_customer( 'customer_confirmed', $booking, sprintf( __( 'Your booking at %s is confirmed', 'roohsites-appointment-booking' ), $site ), __( 'Good news, your appointment is confirmed:', 'roohsites-appointment-booking' ) );
			return;
		}

		// Held bookings that expire (e.g. unpaid) were never announced, so nobody needs to hear about it.
		if ( 'cancelled' !== $booking['status'] || ! in_array( $old, self::LIVE, true ) ) {
			return;
		}

		if ( 'customer' === $by ) {
			/* translators: 1: customer name, 2: date and time */
			$subject = sprintf( __( 'Booking cancelled by %1$s (%2$s)', 'roohsites-appointment-booking' ), $booking['customer_name'], Bookings::format_when( $booking ) );
			self::to_team( 'team_cancelled', $booking, $subject, __( 'The customer cancelled this booking:', 'roohsites-appointment-booking' ) . "\n\n" . self::details( $booking, true ) );
			/* translators: %s: site name */
			self::to_customer( 'customer_cancelled', $booking, sprintf( __( 'Your booking at %s was cancelled', 'roohsites-appointment-booking' ), $site ), __( 'Your appointment has been cancelled as requested:', 'roohsites-appointment-booking' ), false );
		} else {
			/* translators: %s: site name */
			self::to_customer( 'customer_cancelled', $booking, sprintf( __( 'Your booking at %s was cancelled', 'roohsites-appointment-booking' ), $site ), __( 'Unfortunately your appointment has been cancelled. Please contact us or book another time:', 'roohsites-appointment-booking' ), false );
		}
	}

	public static function on_moved( $booking, $before, $by ) {
		if ( ! in_array( $booking['status'], self::LIVE, true ) ) {
			return;
		}

		/* translators: %s: site name */
		self::to_customer( 'customer_moved', $booking, sprintf( __( 'Your booking at %s has a new time', 'roohsites-appointment-booking' ), self::site_name() ), __( 'Your appointment has been moved. Here are the new details:', 'roohsites-appointment-booking' ) );

		if ( 'customer' === $by ) {
			/* translators: 1: customer name, 2: new date and time */
			$subject = sprintf( __( '%1$s rescheduled to %2$s', 'roohsites-appointment-booking' ), $booking['customer_name'], Bookings::format_when( $booking ) );
			/* translators: %s: old date and time */
			$body = sprintf( __( 'The customer moved their booking from %s to:', 'roohsites-appointment-booking' ), Bookings::format_when( $before ) ) . "\n\n" . self::details( $booking, true );
			self::to_team( 'team_moved', $booking, $subject, $body );
		}
	}

	public static function cancel_url( $booking ) {
		return add_query_arg( 'rsab_cancel', $booking['token'], home_url( '/' ) );
	}

	public static function site_name() {
		return wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	}

	/**
	 * The booking details as plain-text lines.
	 */
	public static function detail_lines( $booking, $for_team = false ) {
		$service = Post_Types::service( $booking['service_id'] );
		$minutes = (int) round( ( strtotime( $booking['end_at'] . ' UTC' ) - Bookings::start_timestamp( $booking ) ) / MINUTE_IN_SECONDS );
		$lines   = array(
			/* translators: %s: service name */
			sprintf( __( 'Service: %s', 'roohsites-appointment-booking' ), Post_Types::title( (int) $booking['service_id'] ) ),
			/* translators: %s: staff member name */
			sprintf( __( 'With: %s', 'roohsites-appointment-booking' ), Post_Types::title( (int) $booking['staff_id'] ) ),
			/* translators: %s: date and time */
			sprintf( __( 'When: %s', 'roohsites-appointment-booking' ), Bookings::format_when( $booking ) ),
			/* translators: %d: number of minutes */
			sprintf( __( 'Duration: %d minutes', 'roohsites-appointment-booking' ), $minutes ),
		);

		$price = $service ? Post_Types::format_price( $service['price'] ) : '';
		if ( '' !== $price ) {
			/* translators: %s: price */
			$lines[] = sprintf( __( 'Price: %s', 'roohsites-appointment-booking' ), $price );
		}

		if ( $for_team ) {
			$lines[] = '';
			/* translators: %s: customer name */
			$lines[] = sprintf( __( 'Customer: %s', 'roohsites-appointment-booking' ), $booking['customer_name'] );
			/* translators: %s: email address */
			$lines[] = sprintf( __( 'Email: %s', 'roohsites-appointment-booking' ), $booking['customer_email'] );
			if ( '' !== $booking['customer_phone'] ) {
				/* translators: %s: phone number */
				$lines[] = sprintf( __( 'Phone: %s', 'roohsites-appointment-booking' ), $booking['customer_phone'] );
			}
			if ( '' !== (string) $booking['notes'] ) {
				/* translators: %s: customer notes */
				$lines[] = sprintf( __( 'Notes: %s', 'roohsites-appointment-booking' ), $booking['notes'] );
			}
		}

		/**
		 * Filters the detail lines in emails (e.g. to replace the price or add custom fields).
		 *
		 * @param string[] $lines    Plain-text lines.
		 * @param array    $booking  The booking row.
		 * @param bool     $for_team Whether the email goes to the business rather than the customer.
		 */
		return apply_filters( 'rsab_email_details', $lines, $booking, $for_team );
	}

	private static function details( $booking, $for_team = false ) {
		return implode( "\n", self::detail_lines( $booking, $for_team ) );
	}

	private static function to_customer( $type, $booking, $subject, $intro, $with_cancel_link = true ) {
		// Bookings added by staff (walk-ins, phone calls) may have no email address.
		if ( ! is_email( $booking['customer_email'] ) ) {
			return;
		}

		$body = $intro . "\n\n" . self::details( $booking );
		if ( $with_cancel_link ) {
			$body .= "\n\n" . __( 'Need to cancel? Use this link:', 'roohsites-appointment-booking' ) . "\n" . self::cancel_url( $booking );
		}
		$body .= "\n\n— " . self::site_name() . "\n" . home_url( '/' );

		$headers = array();
		$reply   = Settings::get( 'notify_email' );
		if ( is_email( $reply ) ) {
			$headers[] = 'Reply-To: ' . $reply;
		}

		self::send( $booking['customer_email'], $subject, $body, $headers, 'customer', $booking, $type, $intro );
	}

	private static function to_team( $type, $booking, $subject, $body ) {
		$to    = array( Settings::get( 'notify_email' ) );
		$staff = Post_Types::staff_member( $booking['staff_id'] );
		if ( $staff && is_email( $staff['email'] ) ) {
			$to[] = $staff['email'];
		}
		$to = array_values( array_unique( array_filter( $to, 'is_email' ) ) );

		if ( $to ) {
			self::send( $to, $subject, $body, array( 'Reply-To: ' . $booking['customer_email'] ), 'team', $booking, $type, '' );
		}
	}

	private static function send( $to, $subject, $body, $headers, $audience, $booking, $type, $intro ) {
		/**
		 * Filters a Roohsites Appointment Booking email before it is sent. Return false to skip it.
		 *
		 * @param array  $email    to, subject, body, headers, plus type and intro (the opening sentence).
		 * @param string $audience 'customer' or 'team'.
		 * @param array  $booking  Booking row.
		 */
		$email = apply_filters( 'rsab_email', compact( 'to', 'subject', 'body', 'headers', 'type', 'intro' ), $audience, $booking );
		if ( $email ) {
			wp_mail( $email['to'], $email['subject'], $email['body'], $email['headers'] );
		}
	}
}
