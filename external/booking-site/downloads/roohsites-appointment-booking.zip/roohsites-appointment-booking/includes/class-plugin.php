<?php
namespace RSAB;

defined( 'ABSPATH' ) || exit;

/**
 * Wires every component together.
 */
final class Plugin {

	public static function init() {
		Install::maybe_upgrade();
		Post_Types::init();
		Settings::init();
		Rest::init();
		Shortcode::init();
		Block::init();
		Emails::init();
		Cancel::init();
		Privacy::init();

		if ( is_admin() ) {
			Admin::init();
			Setup::init();
		}
	}

	/**
	 * Version string for a CSS or JS file: the plugin version plus the file's last change, so browsers and
	 * page caches load a changed file even when the plugin version stays the same.
	 */
	public static function asset_version( $path ) {
		$file = RSAB_DIR . ltrim( $path, '/' );
		return RSAB_VERSION . ( file_exists( $file ) ? '.' . filemtime( $file ) : '' );
	}

	/**
	 * Capability needed to manage bookings, services, staff and settings.
	 */
	public static function capability() {
		return apply_filters( 'rsab_capability', 'manage_options' );
	}
}
