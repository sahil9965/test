<?php
namespace RSAB;

defined( 'ABSPATH' ) || exit;

/**
 * Services and staff are stored as private custom post types.
 */
final class Post_Types {

	const SERVICE = 'rsab_service';
	const STAFF   = 'rsab_staff';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'meta_boxes' ) );
		add_action( 'save_post_' . self::SERVICE, array( __CLASS__, 'save_service' ) );
		add_action( 'save_post_' . self::STAFF, array( __CLASS__, 'save_staff' ) );
		add_filter( 'manage_' . self::SERVICE . '_posts_columns', array( __CLASS__, 'service_columns' ) );
		add_action( 'manage_' . self::SERVICE . '_posts_custom_column', array( __CLASS__, 'service_column' ), 10, 2 );
		add_filter( 'manage_' . self::STAFF . '_posts_columns', array( __CLASS__, 'staff_columns' ) );
		add_action( 'manage_' . self::STAFF . '_posts_custom_column', array( __CLASS__, 'staff_column' ), 10, 2 );
	}

	public static function register() {
		$common = array(
			'public'       => false,
			'show_ui'      => true,
			'show_in_menu' => Admin::MENU_SLUG,
			'supports'     => array( 'title' ),
			'map_meta_cap' => true,
		);

		register_post_type(
			self::SERVICE,
			array( 'supports' => array( 'title', 'thumbnail' ) ) + $common + array(
				'labels' => array(
					'name'               => __( 'Services', 'roohsites-appointment-booking' ),
					'singular_name'      => __( 'Service', 'roohsites-appointment-booking' ),
					'all_items'          => __( 'Services', 'roohsites-appointment-booking' ),
					'add_new'            => __( 'Add Service', 'roohsites-appointment-booking' ),
					'add_new_item'       => __( 'Add Service', 'roohsites-appointment-booking' ),
					'edit_item'          => __( 'Edit Service', 'roohsites-appointment-booking' ),
					'new_item'           => __( 'New Service', 'roohsites-appointment-booking' ),
					'search_items'       => __( 'Search Services', 'roohsites-appointment-booking' ),
					'not_found'          => __( 'No services yet.', 'roohsites-appointment-booking' ),
					'not_found_in_trash' => __( 'No services in Trash.', 'roohsites-appointment-booking' ),
					'featured_image'     => __( 'Service photo', 'roohsites-appointment-booking' ),
					'set_featured_image' => __( 'Set service photo', 'roohsites-appointment-booking' ),
				),
			)
		);

		// Staff and service photos use the featured image. Enable it for them even if the theme does not.
		if ( ! current_theme_supports( 'post-thumbnails' ) ) {
			add_theme_support( 'post-thumbnails', array( self::STAFF, self::SERVICE ) );
		}

		register_post_type(
			self::STAFF,
			array( 'supports' => array( 'title', 'thumbnail' ) ) + $common + array(
				'labels' => array(
					'name'               => __( 'Staff', 'roohsites-appointment-booking' ),
					'singular_name'      => __( 'Staff Member', 'roohsites-appointment-booking' ),
					'all_items'          => __( 'Staff', 'roohsites-appointment-booking' ),
					'add_new'            => __( 'Add Staff Member', 'roohsites-appointment-booking' ),
					'add_new_item'       => __( 'Add Staff Member', 'roohsites-appointment-booking' ),
					'edit_item'          => __( 'Edit Staff Member', 'roohsites-appointment-booking' ),
					'new_item'           => __( 'New Staff Member', 'roohsites-appointment-booking' ),
					'search_items'       => __( 'Search Staff', 'roohsites-appointment-booking' ),
					'not_found'          => __( 'No staff members yet.', 'roohsites-appointment-booking' ),
					'not_found_in_trash' => __( 'No staff members in Trash.', 'roohsites-appointment-booking' ),
					'featured_image'     => __( 'Photo', 'roohsites-appointment-booking' ),
					'set_featured_image' => __( 'Set photo', 'roohsites-appointment-booking' ),
				),
			)
		);
	}

	/* -----------------------------------------------------------------
	 * Data access
	 * -------------------------------------------------------------- */

	/**
	 * A service or staff name as plain text. get_the_title() returns HTML (e.g. "&" becomes "&#038;"),
	 * which is right for HTML output but wrong for emails, JSON and JavaScript.
	 */
	public static function title( $post ) {
		return html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' );
	}

	public static function service( $id ) {
		$post = get_post( $id );
		if ( ! $post || self::SERVICE !== $post->post_type || 'publish' !== $post->post_status ) {
			return null;
		}

		$duration = (int) get_post_meta( $post->ID, '_rsab_duration', true );

		return array(
			'id'          => $post->ID,
			'name'        => self::title( $post ),
			'description' => (string) get_post_meta( $post->ID, '_rsab_description', true ),
			'duration'    => $duration > 0 ? $duration : 60,
			'buffer'      => max( 0, (int) get_post_meta( $post->ID, '_rsab_buffer', true ) ),
			'price'       => (string) get_post_meta( $post->ID, '_rsab_price', true ),
			'step'        => self::start_step( $post->ID, $duration > 0 ? $duration : 60, max( 0, (int) get_post_meta( $post->ID, '_rsab_buffer', true ) ) ),
			'photo'       => (string) get_the_post_thumbnail_url( $post->ID, 'medium' ),
		);
	}

	/** Choices for "Start times every" on a service. */
	public static function step_choices() {
		return array(
			'length' => __( 'Back to back (service length plus buffer)', 'roohsites-appointment-booking' ),
			'site'   => __( 'Site default (Settings → Time slot interval)', 'roohsites-appointment-booking' ),
			'15'     => __( 'Every 15 minutes', 'roohsites-appointment-booking' ),
			'30'     => __( 'Every 30 minutes', 'roohsites-appointment-booking' ),
			'60'     => __( 'Every hour', 'roohsites-appointment-booking' ),
		);
	}

	/**
	 * Minutes between the start times offered for a service. Services saved before this setting existed
	 * keep the site-wide interval; new services start back to back.
	 */
	public static function start_step( $post_id, $duration, $buffer ) {
		$choice = (string) get_post_meta( $post_id, '_rsab_step', true );
		if ( 'length' === $choice ) {
			return max( 5, $duration + $buffer );
		}
		if ( ctype_digit( $choice ) && (int) $choice >= 5 ) {
			return (int) $choice;
		}
		return max( 5, (int) Settings::get( 'slot_interval' ) );
	}

	public static function services() {
		$ids = get_posts(
			array(
				'post_type'   => self::SERVICE,
				'post_status' => 'publish',
				'numberposts' => -1,
				'orderby'     => array(
					'menu_order' => 'ASC',
					'title'      => 'ASC',
				),
				'fields'      => 'ids',
			)
		);

		return array_values( array_filter( array_map( array( __CLASS__, 'service' ), $ids ) ) );
	}

	public static function staff_member( $id ) {
		$post = get_post( $id );
		if ( ! $post || self::STAFF !== $post->post_type || 'publish' !== $post->post_status ) {
			return null;
		}

		$hours = get_post_meta( $post->ID, '_rsab_hours', true );

		return array(
			'id'       => $post->ID,
			'name'     => self::title( $post ),
			'email'    => (string) get_post_meta( $post->ID, '_rsab_email', true ),
			'services' => array_values( array_filter( array_map( 'intval', (array) get_post_meta( $post->ID, '_rsab_services', true ) ) ) ),
			'hours'    => is_array( $hours ) ? $hours : self::default_hours(),
			'days_off' => array_values( array_filter( (array) get_post_meta( $post->ID, '_rsab_days_off', true ) ) ),
			'photo'    => (string) get_the_post_thumbnail_url( $post, 'thumbnail' ),
		);
	}

	public static function staff() {
		// Availability asks for staff once per day of a month, so keep the list for this request.
		static $cache = null;
		if ( null !== $cache && ! is_admin() ) {
			return $cache;
		}

		$ids = get_posts(
			array(
				'post_type'   => self::STAFF,
				'post_status' => 'publish',
				'numberposts' => -1,
				'orderby'     => array(
					'menu_order' => 'ASC',
					'title'      => 'ASC',
				),
				'fields'      => 'ids',
			)
		);

		$cache = array_values( array_filter( array_map( array( __CLASS__, 'staff_member' ), $ids ) ) );
		return $cache;
	}

	public static function staff_for_service( $service_id ) {
		return array_values(
			array_filter(
				self::staff(),
				function ( $member ) use ( $service_id ) {
					return in_array( (int) $service_id, $member['services'], true );
				}
			)
		);
	}

	/**
	 * Weekly hours keyed by ISO weekday (1 = Monday … 7 = Sunday).
	 */
	public static function default_hours() {
		$hours = array();
		for ( $day = 1; $day <= 7; $day++ ) {
			$hours[ $day ] = array(
				'on'    => $day <= 5,
				'start' => '09:00',
				'end'   => '17:00',
			);
		}
		return $hours;
	}

	/* -----------------------------------------------------------------
	 * Meta boxes
	 * -------------------------------------------------------------- */

	public static function meta_boxes() {
		add_meta_box( 'rsab-service', __( 'Service details', 'roohsites-appointment-booking' ), array( __CLASS__, 'render_service_box' ), self::SERVICE, 'normal', 'high' );
		add_meta_box( 'rsab-staff', __( 'Staff details', 'roohsites-appointment-booking' ), array( __CLASS__, 'render_staff_box' ), self::STAFF, 'normal', 'high' );
	}

	public static function render_service_box( $post ) {
		wp_nonce_field( 'rsab_save_service', 'rsab_nonce' );

		$duration = (int) get_post_meta( $post->ID, '_rsab_duration', true );
		$buffer   = (int) get_post_meta( $post->ID, '_rsab_buffer', true );
		$price    = get_post_meta( $post->ID, '_rsab_price', true );
		$desc     = get_post_meta( $post->ID, '_rsab_description', true );
		$step     = (string) get_post_meta( $post->ID, '_rsab_step', true );
		if ( '' === $step ) {
			// A service being created starts back to back; an older one keeps the site default it used before.
			$step = 'auto-draft' === $post->post_status ? 'length' : 'site';
		}
		?>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="rsab-description"><?php esc_html_e( 'Short description', 'roohsites-appointment-booking' ); ?></label></th>
				<td>
					<input id="rsab-description" type="text" maxlength="160" class="large-text" name="rsab_description" value="<?php echo esc_attr( $desc ); ?>">
					<p class="description"><?php esc_html_e( 'One line shown under the service name, e.g. “Wash, cut and blow-dry”.', 'roohsites-appointment-booking' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="rsab-duration"><?php esc_html_e( 'Duration (minutes)', 'roohsites-appointment-booking' ); ?></label></th>
				<td><input id="rsab-duration" type="number" min="5" max="1440" step="5" class="small-text" name="rsab_duration" value="<?php echo esc_attr( $duration > 0 ? $duration : 60 ); ?>"></td>
			</tr>
			<tr>
				<th scope="row"><label for="rsab-buffer"><?php esc_html_e( 'Buffer after (minutes)', 'roohsites-appointment-booking' ); ?></label></th>
				<td>
					<input id="rsab-buffer" type="number" min="0" max="240" step="5" class="small-text" name="rsab_buffer" value="<?php echo esc_attr( $buffer ); ?>">
					<p class="description"><?php esc_html_e( 'Clean-up or travel time blocked after each appointment.', 'roohsites-appointment-booking' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="rsab-step"><?php esc_html_e( 'Start times every', 'roohsites-appointment-booking' ); ?></label></th>
				<td>
					<select id="rsab-step" name="rsab_step">
						<?php foreach ( self::step_choices() as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $step, (string) $value ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="description"><?php esc_html_e( 'How far apart the start times offered to customers are. Back to back suits most services: a 60-minute haircut offers 10:00, 11:00, 12:00. Pick a shorter step if you want more choice, for example to fit short services between long ones.', 'roohsites-appointment-booking' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="rsab-price"><?php esc_html_e( 'Price', 'roohsites-appointment-booking' ); ?></label></th>
				<td>
					<input id="rsab-price" type="text" inputmode="decimal" class="small-text" name="rsab_price" value="<?php echo esc_attr( $price ); ?>">
					<p class="description"><?php esc_html_e( 'Shown to customers. Leave empty to hide. Payment is collected in person.', 'roohsites-appointment-booking' ); ?></p>
				</td>
			</tr>
		</table>
		<p><?php esc_html_e( 'Remember to assign this service to at least one staff member.', 'roohsites-appointment-booking' ); ?></p>
		<?php
	}

	public static function render_staff_box( $post ) {
		global $wp_locale;

		wp_nonce_field( 'rsab_save_staff', 'rsab_nonce' );

		$email    = get_post_meta( $post->ID, '_rsab_email', true );
		$assigned = array_map( 'intval', (array) get_post_meta( $post->ID, '_rsab_services', true ) );
		$hours    = get_post_meta( $post->ID, '_rsab_hours', true );
		$hours    = is_array( $hours ) ? $hours : self::default_hours();
		$days_off = array_filter( (array) get_post_meta( $post->ID, '_rsab_days_off', true ) );
		$services = self::services();
		?>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="rsab-staff-email"><?php esc_html_e( 'Email', 'roohsites-appointment-booking' ); ?></label></th>
				<td>
					<input id="rsab-staff-email" type="email" class="regular-text" name="rsab_email" value="<?php echo esc_attr( $email ); ?>">
					<p class="description"><?php esc_html_e( 'Optional. This person is emailed about their new bookings.', 'roohsites-appointment-booking' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Services offered', 'roohsites-appointment-booking' ); ?></th>
				<td>
					<?php if ( ! $services ) : ?>
						<p><?php esc_html_e( 'No services yet. Add a service first.', 'roohsites-appointment-booking' ); ?></p>
					<?php endif; ?>
					<fieldset>
						<?php foreach ( $services as $service ) : ?>
							<label style="display:block;margin-bottom:4px">
								<input type="checkbox" name="rsab_services[]" value="<?php echo esc_attr( $service['id'] ); ?>" <?php checked( in_array( $service['id'], $assigned, true ) ); ?>>
								<?php echo esc_html( $service['name'] ); ?>
							</label>
						<?php endforeach; ?>
					</fieldset>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Working hours', 'roohsites-appointment-booking' ); ?></th>
				<td>
					<table class="rsab-hours">
						<?php for ( $day = 1; $day <= 7; $day++ ) : ?>
							<?php
							$row = isset( $hours[ $day ] ) ? $hours[ $day ] : array(
								'on'    => false,
								'start' => '09:00',
								'end'   => '17:00',
							);
							?>
							<tr>
								<td style="padding:4px 12px 4px 0">
									<label>
										<input type="checkbox" name="rsab_hours[<?php echo esc_attr( $day ); ?>][on]" value="1" <?php checked( ! empty( $row['on'] ) ); ?>>
										<?php echo esc_html( $wp_locale->get_weekday( $day % 7 ) ); ?>
									</label>
								</td>
								<td style="padding:4px 0;white-space:nowrap">
									<input type="time" step="300" name="rsab_hours[<?php echo esc_attr( $day ); ?>][start]" value="<?php echo esc_attr( $row['start'] ); ?>" aria-label="<?php esc_attr_e( 'Start time', 'roohsites-appointment-booking' ); ?>">
									&ndash;
									<input type="time" step="300" name="rsab_hours[<?php echo esc_attr( $day ); ?>][end]" value="<?php echo esc_attr( $row['end'] ); ?>" aria-label="<?php esc_attr_e( 'End time', 'roohsites-appointment-booking' ); ?>">
								</td>
							</tr>
						<?php endfor; ?>
					</table>
					<p class="description"><?php esc_html_e( 'Times use the site time zone set in Settings → General.', 'roohsites-appointment-booking' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="rsab-days-off"><?php esc_html_e( 'Days off', 'roohsites-appointment-booking' ); ?></label></th>
				<td>
					<textarea id="rsab-days-off" name="rsab_days_off" rows="4" cols="20" placeholder="2026-12-25"><?php echo esc_textarea( implode( "\n", $days_off ) ); ?></textarea>
					<p class="description"><?php esc_html_e( 'One date per line (YYYY-MM-DD). No bookings are offered on these days.', 'roohsites-appointment-booking' ); ?></p>
				</td>
			</tr>
		</table>
		<?php
	}

	private static function can_save( $post_id ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return false;
		}
		return current_user_can( 'edit_post', $post_id );
	}

	public static function save_service( $post_id ) {
		if ( ! isset( $_POST['rsab_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['rsab_nonce'] ) ), 'rsab_save_service' ) || ! self::can_save( $post_id ) ) {
			return;
		}

		$duration = isset( $_POST['rsab_duration'] ) ? absint( $_POST['rsab_duration'] ) : 60;
		$buffer   = isset( $_POST['rsab_buffer'] ) ? absint( $_POST['rsab_buffer'] ) : 0;
		$price    = isset( $_POST['rsab_price'] ) ? sanitize_text_field( wp_unslash( $_POST['rsab_price'] ) ) : '';

		update_post_meta( $post_id, '_rsab_duration', max( 5, min( 1440, $duration ) ) );
		update_post_meta( $post_id, '_rsab_buffer', min( 240, $buffer ) );
		$step = isset( $_POST['rsab_step'] ) ? sanitize_key( wp_unslash( $_POST['rsab_step'] ) ) : 'site';
		update_post_meta( $post_id, '_rsab_step', array_key_exists( $step, self::step_choices() ) ? $step : 'site' );
		update_post_meta( $post_id, '_rsab_price', substr( $price, 0, 20 ) );

		$desc = isset( $_POST['rsab_description'] ) ? sanitize_text_field( wp_unslash( $_POST['rsab_description'] ) ) : '';
		update_post_meta( $post_id, '_rsab_description', mb_substr( $desc, 0, 160 ) );
	}

	public static function save_staff( $post_id ) {
		if ( ! isset( $_POST['rsab_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['rsab_nonce'] ) ), 'rsab_save_staff' ) || ! self::can_save( $post_id ) ) {
			return;
		}

		$email = isset( $_POST['rsab_email'] ) ? sanitize_email( wp_unslash( $_POST['rsab_email'] ) ) : '';
		update_post_meta( $post_id, '_rsab_email', is_email( $email ) ? $email : '' );

		$services = isset( $_POST['rsab_services'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['rsab_services'] ) ) : array();
		update_post_meta( $post_id, '_rsab_services', array_values( array_unique( array_filter( $services ) ) ) );

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each field is sanitized below.
		$raw   = isset( $_POST['rsab_hours'] ) ? (array) wp_unslash( $_POST['rsab_hours'] ) : array();
		$hours = array();
		for ( $day = 1; $day <= 7; $day++ ) {
			$row           = isset( $raw[ $day ] ) ? (array) $raw[ $day ] : array();
			$start         = self::sanitize_time( isset( $row['start'] ) ? $row['start'] : '', '09:00' );
			$end           = self::sanitize_time( isset( $row['end'] ) ? $row['end'] : '', '17:00' );
			$hours[ $day ] = array(
				'on'    => ! empty( $row['on'] ) && $end > $start,
				'start' => $start,
				'end'   => $end,
			);
		}
		update_post_meta( $post_id, '_rsab_hours', $hours );

		$days_off = array();
		if ( isset( $_POST['rsab_days_off'] ) ) {
			$lines = preg_split( '/\R/', sanitize_textarea_field( wp_unslash( $_POST['rsab_days_off'] ) ) );
			foreach ( $lines as $line ) {
				$line = trim( $line );
				if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $line ) ) {
					$days_off[] = $line;
				}
			}
		}
		$days_off = array_values( array_unique( $days_off ) );
		sort( $days_off );
		update_post_meta( $post_id, '_rsab_days_off', $days_off );
	}

	private static function sanitize_time( $value, $fallback ) {
		$value = substr( sanitize_text_field( (string) $value ), 0, 5 );
		return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $value ) ? $value : $fallback;
	}

	/* -----------------------------------------------------------------
	 * List table columns
	 * -------------------------------------------------------------- */

	public static function service_columns( $columns ) {
		$date = $columns['date'];
		unset( $columns['date'] );
		$columns['rsab_duration'] = __( 'Duration', 'roohsites-appointment-booking' );
		$columns['rsab_price']    = __( 'Price', 'roohsites-appointment-booking' );
		$columns['rsab_id']       = __( 'ID', 'roohsites-appointment-booking' );
		$columns['date']               = $date;
		return $columns;
	}

	public static function service_column( $column, $post_id ) {
		if ( 'rsab_duration' === $column ) {
			$duration = (int) get_post_meta( $post_id, '_rsab_duration', true );
			/* translators: %d: number of minutes */
			echo esc_html( sprintf( __( '%d min', 'roohsites-appointment-booking' ), $duration > 0 ? $duration : 60 ) );
		} elseif ( 'rsab_price' === $column ) {
			echo esc_html( self::format_price( get_post_meta( $post_id, '_rsab_price', true ) ) );
		} elseif ( 'rsab_id' === $column ) {
			echo (int) $post_id;
		}
	}

	public static function staff_columns( $columns ) {
		$date = $columns['date'];
		unset( $columns['date'] );
		$columns['rsab_services'] = __( 'Services', 'roohsites-appointment-booking' );
		$columns['rsab_id']       = __( 'ID', 'roohsites-appointment-booking' );
		$columns['date']               = $date;
		return $columns;
	}

	public static function staff_column( $column, $post_id ) {
		if ( 'rsab_services' === $column ) {
			$names = array();
			foreach ( (array) get_post_meta( $post_id, '_rsab_services', true ) as $service_id ) {
				$service = self::service( $service_id );
				if ( $service ) {
					$names[] = $service['name'];
				}
			}
			echo $names ? esc_html( implode( ', ', $names ) ) : '&mdash;';
		} elseif ( 'rsab_id' === $column ) {
			echo (int) $post_id;
		}
	}

	public static function format_price( $price ) {
		$price = trim( (string) $price );
		if ( '' === $price ) {
			return '';
		}
		// Plain numbers get thousands separators (2500 → 2,500); anything else ("from 500") is shown as typed.
		if ( is_numeric( $price ) ) {
			$price = number_format_i18n( (float) $price, floor( (float) $price ) == (float) $price ? 0 : 2 ); // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual
		}
		return Settings::get( 'currency' ) . $price;
	}
}
