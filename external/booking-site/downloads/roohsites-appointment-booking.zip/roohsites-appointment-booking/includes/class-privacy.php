<?php
namespace RSAB;

defined( 'ABSPATH' ) || exit;

// Bookings live in the plugin's own table, and privacy requests always need fresh data.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

/**
 * WordPress privacy tools (Tools → Export / Erase Personal Data) for bookings,
 * and suggested text for the site's privacy policy.
 */
final class Privacy {

	public static function init() {
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'register_eraser' ) );
		add_action( 'admin_init', array( __CLASS__, 'policy_text' ) );
	}

	public static function register_exporter( $exporters ) {
		$exporters['roohsites-appointment-booking'] = array(
			'exporter_friendly_name' => __( 'Roohsites Appointment Booking bookings', 'roohsites-appointment-booking' ),
			'callback'               => array( __CLASS__, 'export' ),
		);
		return $exporters;
	}

	public static function register_eraser( $erasers ) {
		$erasers['roohsites-appointment-booking'] = array(
			'eraser_friendly_name' => __( 'Roohsites Appointment Booking bookings', 'roohsites-appointment-booking' ),
			'callback'             => array( __CLASS__, 'erase' ),
		);
		return $erasers;
	}

	/**
	 * Every booking made with this email address (any letter case).
	 */
	private static function bookings_for( $email ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE LOWER(customer_email) = %s ORDER BY id', Bookings::table(), strtolower( trim( $email ) ) ), ARRAY_A );
	}

	public static function export( $email, $page = 1 ) {
		$items = array();
		foreach ( self::bookings_for( $email ) as $booking ) {
			$data = array();

			// What the customer's emails show: service, staff, time, price, and add-on lines
			// such as extras, payment and answers to extra questions.
			foreach ( Emails::detail_lines( $booking ) as $line ) {
				if ( '' === trim( (string) $line ) ) {
					continue;
				}

				$parts  = explode( ': ', (string) $line, 2 );
				$data[] = 2 === count( $parts )
					? array(
						'name'  => $parts[0],
						'value' => $parts[1],
					)
					: array(
						'name'  => __( 'Details', 'roohsites-appointment-booking' ),
						'value' => $line,
					);
			}

			$fields = array(
				__( 'Status', 'roohsites-appointment-booking' )    => Bookings::status_label( $booking['status'] ),
				__( 'Name', 'roohsites-appointment-booking' )      => $booking['customer_name'],
				__( 'Email', 'roohsites-appointment-booking' )     => $booking['customer_email'],
				__( 'Phone', 'roohsites-appointment-booking' )     => $booking['customer_phone'],
				__( 'Notes', 'roohsites-appointment-booking' )     => (string) $booking['notes'],
				__( 'Booked on', 'roohsites-appointment-booking' ) => get_date_from_gmt( $booking['created_at'], get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ),
			);
			foreach ( $fields as $name => $value ) {
				$data[] = array(
					'name'  => $name,
					'value' => $value,
				);
			}

			$items[] = array(
				'group_id'    => 'rsab-bookings',
				'group_label' => __( 'Bookings', 'roohsites-appointment-booking' ),
				'item_id'     => 'rsab-booking-' . $booking['id'],
				'data'        => array_values(
					array_filter(
						$data,
						function ( $field ) {
							return '' !== (string) $field['value'];
						}
					)
				),
			);
		}

		return array(
			'data' => $items,
			'done' => true,
		);
	}

	/**
	 * Removes the customer's details from their bookings. The booking itself (service, staff,
	 * time, status) stays for the business's records. Upcoming bookings are kept as they are,
	 * so an appointment isn't lost by accident: cancel it first.
	 */
	public static function erase( $email, $page = 1 ) {
		global $wpdb;

		$removed  = false;
		$retained = false;
		$messages = array();
		$now      = time();

		foreach ( self::bookings_for( $email ) as $booking ) {
			$upcoming = in_array( $booking['status'], Emails::LIVE, true ) && Bookings::start_timestamp( $booking ) > $now;

			/**
			 * Whether a booking's personal details may be erased.
			 *
			 * @param bool  $erase   False for upcoming bookings, true otherwise.
			 * @param array $booking The booking row.
			 */
			if ( ! apply_filters( 'rsab_privacy_erase_booking', ! $upcoming, $booking ) ) {
				$retained   = true;
				$messages[] = sprintf(
					/* translators: 1: booking number, 2: date and time */
					__( 'Booking #%1$d on %2$s is still upcoming, so it was kept. Cancel it first, then erase again.', 'roohsites-appointment-booking' ),
					$booking['id'],
					Bookings::format_when( $booking )
				);
				continue;
			}

			$wpdb->update(
				Bookings::table(),
				array(
					'customer_name'  => wp_privacy_anonymize_data( 'text', $booking['customer_name'] ),
					'customer_email' => wp_privacy_anonymize_data( 'email', $booking['customer_email'] ),
					'customer_phone' => '',
					'notes'          => '',
					// A new secret, so links in old emails no longer open the booking.
					'token'          => bin2hex( random_bytes( 16 ) ),
				),
				array( 'id' => (int) $booking['id'] )
			);

			/**
			 * Fires after a booking's personal details are erased, so add-ons can erase theirs.
			 *
			 * @param array $booking The booking row as it was before erasing.
			 */
			do_action( 'rsab_booking_erased', $booking );
			$removed = true;
		}

		return array(
			'items_removed'  => $removed,
			'items_retained' => $retained,
			'messages'       => $messages,
			'done'           => true,
		);
	}

	public static function policy_text() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}
		$text  = '<p class="privacy-policy-tutorial">' . esc_html__( 'Roohsites Appointment Booking stores booking details in your WordPress database and sends them nowhere else. It sets no cookies. Adapt this text to what you collect and how long you keep it.', 'roohsites-appointment-booking' ) . '</p>';
		$text .= '<p><strong class="privacy-policy-tutorial">' . esc_html__( 'Suggested text:', 'roohsites-appointment-booking' ) . ' </strong>';
		$text .= esc_html__( 'When you book an appointment on this website, we store your name, email address, phone number, any notes you add and the details of your booking, so we can provide the appointment and send you confirmations. To prevent spam, a one-way hash of your IP address is kept for 10 minutes after you book. You can ask us for a copy of your booking data, or ask us to erase it.', 'roohsites-appointment-booking' ) . '</p>';

		wp_add_privacy_policy_content( 'Roohsites Appointment Booking', wp_kses_post( $text ) );
	}
}
