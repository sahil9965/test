<?php
/**
 * Per-IP counters for rate limits, safe under parallel requests.
 *
 * Each count lives in a fixed time window. The increment is a single atomic operation, so two requests
 * arriving at the same moment can never both read the old value and both get through:
 * - with a persistent object cache (Redis, Memcached), wp_cache_add() + wp_cache_incr();
 * - otherwise one "INSERT … ON DUPLICATE KEY UPDATE option_value = option_value + 1" on the options table,
 *   which the database applies atomically.
 *
 * @package RSAB
 */

namespace RSAB;

defined( 'ABSPATH' ) || exit;

class Rate_Limit {

	const PREFIX = '_rsab_rl_';
	const GROUP  = 'rsab_rate_limit';

	/**
	 * Counts one hit for $name from the current visitor and returns the new total for this window.
	 *
	 * @param string $name   Short name of the limit, e.g. 'booking'.
	 * @param int    $window Window length in seconds.
	 * @return int
	 */
	public static function hit( $name, $window ) {
		return self::change( $name, $window, 1 );
	}

	/**
	 * Takes back one hit (for example when the booking it was reserved for failed).
	 *
	 * @param string $name   Short name of the limit.
	 * @param int    $window Window length in seconds.
	 */
	public static function undo( $name, $window ) {
		self::change( $name, $window, -1 );
	}

	private static function change( $name, $window, $by ) {
		$window = max( 60, (int) $window );
		$bucket = (int) floor( time() / $window );
		$key    = self::PREFIX . $bucket . '_' . md5( $name . '|' . self::ip() );

		if ( wp_using_ext_object_cache() ) {
			wp_cache_add( $key, 0, self::GROUP, 2 * $window );
			$value = $by > 0 ? wp_cache_incr( $key, 1, self::GROUP ) : wp_cache_decr( $key, 1, self::GROUP );
			return (int) $value;
		}

		global $wpdb;
		if ( $by > 0 ) {
			// Atomic: the database creates the row at 1 or adds 1 to it in one statement.
			$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- an atomic counter cannot go through the options cache.
				$wpdb->prepare(
					"INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, '1', 'no') ON DUPLICATE KEY UPDATE option_value = option_value + 1",
					$key
				)
			);
		} else {
			$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- same counter as above.
				$wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = GREATEST(option_value - 1, 0) WHERE option_name = %s", $key )
			);
		}

		// Now and then, remove counters from windows that have ended.
		if ( 1 === wp_rand( 1, 50 ) ) {
			self::cleanup( $bucket - 1 );
		}

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- read the value the statement above just wrote.
			$wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $key )
		);
	}

	/**
	 * Deletes counters older than $keep_from. Bucket numbers have the same number of digits for centuries,
	 * so comparing option names as text compares the buckets.
	 *
	 * @param int $keep_from Oldest bucket to keep.
	 */
	public static function cleanup( $keep_from = PHP_INT_MAX ) {
		global $wpdb;
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- removes expired counter rows.
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name < %s",
				$wpdb->esc_like( self::PREFIX ) . '%',
				self::PREFIX . $keep_from . '_'
			)
		);
	}

	private static function ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	}
}
