<?php
namespace RSAB;

use DateTimeImmutable;
use WP_Error;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

/**
 * Public REST endpoints used by the booking form.
 */
final class Rest {

	const NAMESPACE_V1 = 'rsab/v1';

	/** Bookings allowed per IP address in RATE_WINDOW seconds. Filterable via rsab_rate_limit. */
	const RATE_LIMIT  = 10;
	const RATE_WINDOW = 600;

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route(
			self::NAMESPACE_V1,
			'/slots',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_slots' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'service' => array(
						'type'     => 'integer',
						'required' => true,
						'minimum'  => 1,
					),
					'staff'   => array(
						'type'    => 'integer',
						'default' => 0,
						'minimum' => 0,
					),
					'date'    => array(
						'type'     => 'string',
						'required' => true,
						'pattern'  => '^\d{4}-\d{2}-\d{2}$',
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/days',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_days' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'service' => array(
						'type'     => 'integer',
						'required' => true,
						'minimum'  => 1,
					),
					'staff'   => array(
						'type'    => 'integer',
						'default' => 0,
						'minimum' => 0,
					),
					'month'   => array(
						'type'     => 'string',
						'required' => true,
						'pattern'  => '^\d{4}-\d{2}$',
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/bookings',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'create_booking' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'service' => array(
						'type'     => 'integer',
						'required' => true,
						'minimum'  => 1,
					),
					'staff'   => array(
						'type'    => 'integer',
						'default' => 0,
						'minimum' => 0,
					),
					'start'   => array(
						'type'     => 'integer',
						'required' => true,
						'minimum'  => 1,
					),
					'name'    => array(
						'type'      => 'string',
						'required'  => true,
						'minLength' => 1,
						'maxLength' => 190,
					),
					'email'   => array(
						'type'     => 'string',
						'required' => true,
						'format'   => 'email',
					),
					'phone'   => array(
						'type'      => 'string',
						'default'   => '',
						'maxLength' => 50,
					),
					'notes'   => array(
						'type'      => 'string',
						'default'   => '',
						'maxLength' => 2000,
					),
					// Honeypot: real visitors never see or fill this field.
					'website' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);
	}

	public static function get_slots( WP_REST_Request $request ) {
		$extra   = self::extra_minutes( $request );
		$slots   = Availability::slots( $request['service'], $request['staff'], $request['date'], $extra );
		$service = Post_Types::service( $request['service'] );
		$length  = ( $service ? $service['duration'] : 0 ) + max( 0, (int) $extra );
		$out     = array();

		foreach ( array_keys( $slots ) as $timestamp ) {
			$out[] = array(
				'start'    => $timestamp,
				'label'    => wp_date( get_option( 'time_format' ), $timestamp ),
				'endLabel' => $length ? wp_date( get_option( 'time_format' ), $timestamp + $length * MINUTE_IN_SECONDS ) : '',
				'hour'     => (int) wp_date( 'G', $timestamp ),
			);
		}

		return rest_ensure_response( array( 'slots' => $out ) );
	}

	public static function create_booking( WP_REST_Request $request ) {
		if ( '' !== trim( (string) $request['website'] ) ) {
			return new WP_Error( 'rsab_rejected', __( 'Your booking could not be completed.', 'roohsites-appointment-booking' ), array( 'status' => 400 ) );
		}

		if ( self::rate_limited() ) {
			return new WP_Error( 'rsab_rate_limited', __( 'Too many booking attempts. Please wait a few minutes and try again.', 'roohsites-appointment-booking' ), array( 'status' => 429 ) );
		}

		$name  = sanitize_text_field( $request['name'] );
		$email = sanitize_email( $request['email'] );

		if ( '' === $name ) {
			return new WP_Error( 'rsab_invalid_name', __( 'Please enter your name.', 'roohsites-appointment-booking' ), array( 'status' => 400 ) );
		}
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'rsab_invalid_email', __( 'Please enter a valid email address.', 'roohsites-appointment-booking' ), array( 'status' => 400 ) );
		}

		$data = array(
			'service_id'    => (int) $request['service'],
			'staff_id'      => (int) $request['staff'],
			'start'         => (int) $request['start'],
			'extra_minutes' => self::extra_minutes( $request ),
			'name'          => $name,
			'email'         => $email,
			'phone'         => sanitize_text_field( $request['phone'] ),
			'notes'         => sanitize_textarea_field( $request['notes'] ),
		);

		/**
		 * Lets add-ons validate a booking request before it is saved.
		 *
		 * @param true|WP_Error   $valid   Return a WP_Error to reject the booking.
		 * @param array           $data    Sanitized booking data.
		 * @param WP_REST_Request $request The full request, including add-on fields.
		 */
		$valid = apply_filters( 'rsab_validate_booking', true, $data, $request );
		if ( is_wp_error( $valid ) ) {
			return $valid;
		}

		$booking = Bookings::create( $data, $request );

		if ( is_wp_error( $booking ) ) {
			return $booking;
		}

		self::count_booking();

		$response = self::summary( $booking );

		/**
		 * Filters the booking response. Add-ons can add a 'redirect' URL (e.g. to a payment page).
		 *
		 * @param array           $response Response data.
		 * @param array           $booking  The booking row.
		 * @param WP_REST_Request $request  The request.
		 */
		return rest_ensure_response( apply_filters( 'rsab_booking_response', $response, $booking, $request ) );
	}

	/**
	 * What the booking form shows on its final screen.
	 */
	public static function summary( array $booking ) {
		$start   = Bookings::start_timestamp( $booking );
		$message = 'confirmed' === $booking['status']
			? __( 'A confirmation email is on its way to you.', 'roohsites-appointment-booking' )
			: __( 'We will email you as soon as it is confirmed.', 'roohsites-appointment-booking' );

		/**
		 * Filters the final-screen summary of a booking (e.g. for a payment status message).
		 *
		 * @param array $summary Summary data.
		 * @param array $booking The booking row.
		 */
		return apply_filters(
			'rsab_booking_summary',
			array(
				'id'        => (int) $booking['id'],
				'status'    => $booking['status'],
				'message'   => $message,
				'start'     => $start,
				'end'       => strtotime( $booking['end_at'] . ' UTC' ),
				'date'      => wp_date( 'Y-m-d', $start ),
				'timeLabel' => wp_date( get_option( 'time_format' ), $start ),
				'staff'     => Post_Types::title( (int) $booking['staff_id'] ),
				'service'   => Post_Types::title( (int) $booking['service_id'] ),
			),
			$booking
		);
	}

	/**
	 * Extra minutes added to the service duration, e.g. by service extras in an add-on.
	 */
	public static function extra_minutes( WP_REST_Request $request ) {
		return max( 0, (int) apply_filters( 'rsab_extra_minutes', 0, $request ) );
	}

	public static function get_days( WP_REST_Request $request ) {
		$tz    = wp_timezone();
		$first = DateTimeImmutable::createFromFormat( '!Y-m-d', $request['month'] . '-01', $tz );
		if ( ! $first ) {
			return rest_ensure_response( array( 'days' => array() ) );
		}

		$today = ( new DateTimeImmutable( 'now', $tz ) )->setTime( 0, 0 );
		$last  = $today->modify( '+' . (int) Settings::get( 'max_days_ahead' ) . ' days' );
		$extra = self::extra_minutes( $request );
		$days  = array();

		for ( $day = $first; $day->format( 'm' ) === $first->format( 'm' ); $day = $day->modify( '+1 day' ) ) {
			if ( $day < $today || $day > $last ) {
				continue;
			}
			$key = $day->format( 'Y-m-d' );
			if ( Availability::slots( $request['service'], $request['staff'], $key, $extra ) ) {
				$days[] = $key;
			}
		}

		return rest_ensure_response( array( 'days' => $days ) );
	}

	/**
	 * Successful bookings per IP address in RATE_WINDOW seconds.
	 * Failed attempts (taken slot, typo in email) do not count, and site managers are never limited.
	 */
	private static function rate_limited() {
		if ( current_user_can( Plugin::capability() ) ) {
			return false;
		}

		/**
		 * Filters how many bookings one IP address may make in 10 minutes.
		 * Raise it if your host puts every visitor behind the same proxy IP. 0 disables the limit.
		 *
		 * @param int $limit Default 10.
		 */
		$limit = (int) apply_filters( 'rsab_rate_limit', self::RATE_LIMIT );

		return $limit > 0 && (int) get_transient( self::rate_key() ) >= $limit;
	}

	private static function count_booking() {
		$key = self::rate_key();
		set_transient( $key, (int) get_transient( $key ) + 1, self::RATE_WINDOW );
	}

	private static function rate_key() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		return 'rsab_rl_' . md5( $ip );
	}
}
