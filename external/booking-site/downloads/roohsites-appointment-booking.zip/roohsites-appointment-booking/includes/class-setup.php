<?php
namespace RSAB;

defined( 'ABSPATH' ) || exit;

/**
 * Setup wizard: business type, opening hours, services, staff and the booking page, then a test booking.
 * Opens once after activation on a site with no services yet, can be skipped at any step, and resumes where
 * it was left (Roohsites Appointment Booking → Setup wizard).
 */
final class Setup {

	const PAGE   = 'rsab-setup';
	const OPTION = 'rsab_setup';
	const ACTION = 'rsab_setup';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 30 );
		add_action( 'admin_init', array( __CLASS__, 'maybe_redirect' ) );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'save' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
	}

	/** The steps, in order: key => label. */
	public static function steps() {
		return array(
			'business' => __( 'Your business', 'roohsites-appointment-booking' ),
			'hours'    => __( 'Opening hours', 'roohsites-appointment-booking' ),
			'services' => __( 'Services', 'roohsites-appointment-booking' ),
			'staff'    => __( 'Staff', 'roohsites-appointment-booking' ),
			'page'     => __( 'Booking page', 'roohsites-appointment-booking' ),
			'done'     => __( 'Test booking', 'roohsites-appointment-booking' ),
		);
	}

	/**
	 * Ready-made services per business type: [ name, minutes ]. Prices are left for the owner to type,
	 * because they depend on the currency and the town.
	 */
	public static function presets() {
		return array(
			'salon'      => array( __( 'Hair or beauty salon', 'roohsites-appointment-booking' ), array( array( __( 'Haircut', 'roohsites-appointment-booking' ), 45 ), array( __( 'Hair colour', 'roohsites-appointment-booking' ), 120 ), array( __( 'Blow-dry & styling', 'roohsites-appointment-booking' ), 45 ), array( __( 'Manicure', 'roohsites-appointment-booking' ), 45 ) ) ),
			'barber'     => array( __( 'Barber', 'roohsites-appointment-booking' ), array( array( __( 'Haircut', 'roohsites-appointment-booking' ), 30 ), array( __( 'Beard trim', 'roohsites-appointment-booking' ), 20 ), array( __( 'Haircut & beard', 'roohsites-appointment-booking' ), 45 ), array( __( 'Hot towel shave', 'roohsites-appointment-booking' ), 30 ) ) ),
			'clinic'     => array( __( 'Clinic or therapist', 'roohsites-appointment-booking' ), array( array( __( 'Consultation', 'roohsites-appointment-booking' ), 30 ), array( __( 'Follow-up visit', 'roohsites-appointment-booking' ), 15 ), array( __( 'Treatment session', 'roohsites-appointment-booking' ), 45 ) ) ),
			'tutor'      => array( __( 'Tutor or teacher', 'roohsites-appointment-booking' ), array( array( __( 'Lesson', 'roohsites-appointment-booking' ), 60 ), array( __( 'Trial lesson', 'roohsites-appointment-booking' ), 30 ), array( __( 'Exam preparation', 'roohsites-appointment-booking' ), 90 ) ) ),
			'consultant' => array( __( 'Consultant or coach', 'roohsites-appointment-booking' ), array( array( __( 'Discovery call', 'roohsites-appointment-booking' ), 30 ), array( __( 'Consultation', 'roohsites-appointment-booking' ), 60 ), array( __( 'Strategy session', 'roohsites-appointment-booking' ), 90 ) ) ),
			'fitness'    => array( __( 'Fitness, yoga or studio', 'roohsites-appointment-booking' ), array( array( __( 'Personal training', 'roohsites-appointment-booking' ), 60 ), array( __( 'Private yoga session', 'roohsites-appointment-booking' ), 60 ), array( __( 'Fitness assessment', 'roohsites-appointment-booking' ), 30 ) ) ),
			'other'      => array( __( 'Something else', 'roohsites-appointment-booking' ), array( array( __( 'Appointment', 'roohsites-appointment-booking' ), 60 ) ) ),
		);
	}

	public static function state() {
		return wp_parse_args(
			(array) get_option( self::OPTION, array() ),
			array(
				'step'     => 'business',
				'status'   => '',        // '', 'done' or 'skipped'.
				'type'     => '',
				'hours'    => array(),
				'page_id'  => 0,
				'started'  => 0,
				'finished' => 0,
			)
		);
	}

	private static function update( array $changes ) {
		update_option( self::OPTION, array_merge( self::state(), $changes ), false );
	}

	public static function finished() {
		return in_array( self::state()['status'], array( 'done', 'skipped' ), true );
	}

	public static function url( $step = '' ) {
		return add_query_arg( array_filter( array( 'page' => self::PAGE, 'step' => $step ) ), admin_url( 'admin.php' ) );
	}

	/** Called from Install::activate(): open the wizard once on a site that has no services yet. */
	public static function on_activate() {
		if ( ! self::finished() && ! Post_Types::services() ) {
			set_transient( 'rsab_setup_redirect', 1, 60 );
		}
	}

	public static function maybe_redirect() {
		if ( ! get_transient( 'rsab_setup_redirect' ) ) {
			return;
		}
		delete_transient( 'rsab_setup_redirect' );
		// Not when several plugins were activated at once, and never for AJAX, cron or users who cannot manage Roohsites Appointment Booking.
		if ( wp_doing_ajax() || isset( $_GET['activate-multi'] ) || ! current_user_can( Plugin::capability() ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		wp_safe_redirect( self::url() );
		exit;
	}

	public static function menu() {
		add_submenu_page( Admin::MENU_SLUG, __( 'Set up Roohsites Appointment Booking', 'roohsites-appointment-booking' ), __( 'Setup wizard', 'roohsites-appointment-booking' ), Plugin::capability(), self::PAGE, array( __CLASS__, 'render' ) );
		// Once setup is finished the screen leaves the menu, but stays reachable (Settings links to it): WordPress
		// refuses screens missing from the menu, so it is only removed while another screen is open.
		$open = isset( $_GET['page'] ) && self::PAGE === sanitize_key( wp_unslash( $_GET['page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( self::finished() && ! $open ) {
			remove_submenu_page( Admin::MENU_SLUG, self::PAGE );
		}
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::PAGE ) ) {
			return;
		}
		wp_enqueue_style( 'rsab-setup', RSAB_URL . 'assets/css/setup.css', array(), Plugin::asset_version( 'assets/css/setup.css' ) );
	}

	/** On Roohsites Appointment Booking screens only: a reminder to finish setup while it is unfinished. */
	public static function notice() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( self::finished() || ! $screen || false === strpos( (string) $screen->id, 'rsab' ) || false !== strpos( (string) $screen->id, self::PAGE ) || ! current_user_can( Plugin::capability() ) ) {
			return;
		}
		$keys = array_keys( self::steps() );
		$step = array_search( self::state()['step'], $keys, true );
		printf(
			'<div class="notice notice-info"><p><strong>%1$s</strong> %2$s <a class="button button-primary" style="margin-left:8px" href="%3$s">%4$s</a></p></div>',
			esc_html__( 'Finish setting up Roohsites Appointment Booking.', 'roohsites-appointment-booking' ),
			/* translators: 1: current step number, 2: number of steps. */
			esc_html( sprintf( __( 'Step %1$d of %2$d, about 5 minutes left.', 'roohsites-appointment-booking' ), (int) $step + 1, count( $keys ) ) ),
			esc_url( self::url( self::state()['step'] ) ),
			esc_html__( 'Continue setup', 'roohsites-appointment-booking' )
		);
	}

	/* -----------------------------------------------------------------
	 * Screen
	 * -------------------------------------------------------------- */

	public static function render() {
		if ( ! current_user_can( Plugin::capability() ) ) {
			return;
		}
		$state = self::state();
		if ( ! $state['started'] ) {
			self::update( array( 'started' => time() ) );
		}
		$steps = self::steps();
		$step  = isset( $_GET['step'] ) ? sanitize_key( wp_unslash( $_GET['step'] ) ) : $state['step']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $steps[ $step ] ) ) {
			$step = 'business';
		}
		$keys  = array_keys( $steps );
		$index = array_search( $step, $keys, true );
		?>
		<div class="wrap rsab-setup">
			<div class="ss-setup-card">
				<p class="ss-setup-brand"><?php esc_html_e( 'Roohsites Appointment Booking setup', 'roohsites-appointment-booking' ); ?></p>
				<ol class="ss-setup-steps" aria-label="<?php esc_attr_e( 'Setup steps', 'roohsites-appointment-booking' ); ?>">
					<?php foreach ( $keys as $i => $key ) : ?>
						<li class="<?php echo esc_attr( $i < $index ? 'is-done' : ( $i === $index ? 'is-current' : '' ) ); ?>"<?php echo $i === $index ? ' aria-current="step"' : ''; ?>><span><?php echo (int) $i + 1; ?></span><?php echo esc_html( $steps[ $key ] ); ?></li>
					<?php endforeach; ?>
				</ol>
				<?php
				if ( 'done' === $step ) {
					self::render_done();
				} else {
					?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
						<input type="hidden" name="step" value="<?php echo esc_attr( $step ); ?>">
						<?php wp_nonce_field( self::ACTION . '_' . $step ); ?>
						<?php call_user_func( array( __CLASS__, 'render_' . $step ), $state ); ?>
						<div class="ss-setup-actions">
							<?php if ( $index > 0 ) : ?>
								<a class="button" href="<?php echo esc_url( self::url( $keys[ $index - 1 ] ) ); ?>"><?php esc_html_e( 'Back', 'roohsites-appointment-booking' ); ?></a>
							<?php endif; ?>
							<button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'Save and continue', 'roohsites-appointment-booking' ); ?></button>
						</div>
					</form>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="ss-setup-skip">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
						<input type="hidden" name="step" value="skip">
						<?php wp_nonce_field( self::ACTION . '_skip' ); ?>
						<button type="submit" class="button-link"><?php esc_html_e( 'Skip setup, I’ll do it myself', 'roohsites-appointment-booking' ); ?></button>
					</form>
					<?php
				}
				?>
			</div>
		</div>
		<?php
	}

	private static function render_business( $state ) {
		$settings = Settings::all();
		?>
		<h1><?php esc_html_e( 'What kind of business is this?', 'roohsites-appointment-booking' ); ?></h1>
		<p class="ss-setup-lead"><?php esc_html_e( 'We’ll suggest services to start with. You can change everything later.', 'roohsites-appointment-booking' ); ?></p>
		<div class="ss-setup-choices">
			<?php foreach ( self::presets() as $key => $preset ) : ?>
				<label class="ss-setup-choice"><input type="radio" name="type" value="<?php echo esc_attr( $key ); ?>" <?php checked( $state['type'] ? $state['type'] : 'salon', $key ); ?>><span><?php echo esc_html( $preset[0] ); ?></span></label>
			<?php endforeach; ?>
		</div>
		<p class="ss-setup-field">
			<label for="ss-currency"><?php esc_html_e( 'Currency for your prices', 'roohsites-appointment-booking' ); ?></label>
			<select id="ss-currency" name="currency_code">
				<?php foreach ( Settings::currencies() as $code => $c ) : ?>
					<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $settings['currency_code'], $code ); ?>><?php echo esc_html( $c[0] . '  ' . $c[1] . ' (' . $code . ')' ); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<?php
	}

	private static function render_hours( $state ) {
		global $wp_locale;
		$hours = $state['hours'] ? $state['hours'] : Post_Types::default_hours();
		?>
		<h1><?php esc_html_e( 'When can clients book?', 'roohsites-appointment-booking' ); ?></h1>
		<p class="ss-setup-lead"><?php esc_html_e( 'Your usual opening hours. Each staff member can have their own hours later, plus days off.', 'roohsites-appointment-booking' ); ?></p>
		<table class="ss-setup-hours" role="presentation">
			<?php for ( $d = 1; $d <= 7; $d++ ) : ?>
				<?php $h = isset( $hours[ $d ] ) ? $hours[ $d ] : array( 'on' => false, 'start' => '09:00', 'end' => '17:00' ); ?>
				<tr>
					<th scope="row"><label><input type="checkbox" name="hours[<?php echo (int) $d; ?>][on]" value="1" <?php checked( ! empty( $h['on'] ) ); ?>> <?php echo esc_html( $wp_locale->get_weekday( $d % 7 ) ); ?></label></th>
					<td>
						<input type="time" name="hours[<?php echo (int) $d; ?>][start]" value="<?php echo esc_attr( $h['start'] ); ?>" aria-label="<?php esc_attr_e( 'Opens', 'roohsites-appointment-booking' ); ?>">
						<span aria-hidden="true">–</span>
						<input type="time" name="hours[<?php echo (int) $d; ?>][end]" value="<?php echo esc_attr( $h['end'] ); ?>" aria-label="<?php esc_attr_e( 'Closes', 'roohsites-appointment-booking' ); ?>">
					</td>
				</tr>
			<?php endfor; ?>
		</table>
		<?php if ( Settings::timezone_looks_unset() ) : ?>
			<p class="ss-setup-field">
				<label for="ss-timezone"><?php esc_html_e( 'Your time zone', 'roohsites-appointment-booking' ); ?></label>
				<select id="ss-timezone" name="timezone_string"><?php echo wp_timezone_choice( '', get_user_locale() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core markup. ?></select>
				<span class="description"><?php esc_html_e( 'Your site is set to UTC, so clients would see the wrong times. Pick your city.', 'roohsites-appointment-booking' ); ?></span>
			</p>
		<?php endif; ?>
		<?php
	}

	private static function render_services( $state ) {
		$existing = Post_Types::services();
		$presets  = self::presets();
		$rows     = isset( $presets[ $state['type'] ] ) ? $presets[ $state['type'] ][1] : $presets['other'][1];
		$symbol   = Settings::get( 'currency' );
		?>
		<h1><?php esc_html_e( 'What can clients book?', 'roohsites-appointment-booking' ); ?></h1>
		<?php if ( $existing ) : ?>
			<p class="ss-setup-lead">
				<?php
				/* translators: %d: number of services. */
				echo esc_html( sprintf( _n( 'You already have %d service. Add more below, or leave the rows empty and continue.', 'You already have %d services. Add more below, or leave the rows empty and continue.', count( $existing ), 'roohsites-appointment-booking' ), count( $existing ) ) );
				$rows = array();
				?>
			</p>
		<?php else : ?>
			<p class="ss-setup-lead"><?php esc_html_e( 'We filled in a few to start with. Change the names and lengths, add your prices, and clear any row you don’t need.', 'roohsites-appointment-booking' ); ?></p>
		<?php endif; ?>
		<table class="ss-setup-services">
			<thead><tr><th><?php esc_html_e( 'Service', 'roohsites-appointment-booking' ); ?></th><th><?php esc_html_e( 'Minutes', 'roohsites-appointment-booking' ); ?></th><th><?php echo esc_html( sprintf( /* translators: %s: currency symbol. */ __( 'Price (%s)', 'roohsites-appointment-booking' ), $symbol ) ); ?></th></tr></thead>
			<tbody>
				<?php for ( $i = 0; $i < 6; $i++ ) : ?>
					<?php $r = isset( $rows[ $i ] ) ? $rows[ $i ] : array( '', 60 ); ?>
					<tr>
						<td><input type="text" name="services[<?php echo (int) $i; ?>][name]" value="<?php echo esc_attr( $r[0] ); ?>" maxlength="80" aria-label="<?php esc_attr_e( 'Service name', 'roohsites-appointment-booking' ); ?>" placeholder="<?php echo 0 === $i && ! $rows ? esc_attr__( 'e.g. Consultation', 'roohsites-appointment-booking' ) : ''; ?>"></td>
						<td><input type="number" name="services[<?php echo (int) $i; ?>][minutes]" value="<?php echo esc_attr( $r[1] ); ?>" min="5" max="480" step="5" class="small-text" aria-label="<?php esc_attr_e( 'Length in minutes', 'roohsites-appointment-booking' ); ?>"></td>
						<td><input type="text" inputmode="decimal" name="services[<?php echo (int) $i; ?>][price]" value="" class="small-text" aria-label="<?php esc_attr_e( 'Price', 'roohsites-appointment-booking' ); ?>" placeholder="<?php esc_attr_e( 'Optional', 'roohsites-appointment-booking' ); ?>"></td>
					</tr>
				<?php endfor; ?>
			</tbody>
		</table>
		<p class="description"><?php esc_html_e( 'Start times follow each service’s length, so a 45-minute service offers 10:00, 10:45, 11:30. Add photos and descriptions later in Roohsites Appointment Booking → Services.', 'roohsites-appointment-booking' ); ?></p>
		<?php
	}

	private static function render_staff( $state ) {
		$me = wp_get_current_user();
		?>
		<h1><?php esc_html_e( 'Who takes the appointments?', 'roohsites-appointment-booking' ); ?></h1>
		<p class="ss-setup-lead"><?php esc_html_e( 'Clients can pick a person, or choose “Anyone”. Each person gets your opening hours and every service; change that later per person.', 'roohsites-appointment-booking' ); ?></p>
		<?php for ( $i = 0; $i < 4; $i++ ) : ?>
			<p class="ss-setup-field">
				<label for="ss-staff-<?php echo (int) $i; ?>">
					<?php
					/* translators: %d: person number. */
					echo esc_html( 0 === $i ? __( 'Your name, or the first person’s', 'roohsites-appointment-booking' ) : sprintf( __( 'Person %d (optional)', 'roohsites-appointment-booking' ), $i + 1 ) );
					?>
				</label>
				<input type="text" id="ss-staff-<?php echo (int) $i; ?>" name="staff[]" value="<?php echo 0 === $i && ! Post_Types::staff() ? esc_attr( $me->display_name ) : ''; ?>" maxlength="60" class="regular-text">
			</p>
		<?php endfor; ?>
		<?php if ( Post_Types::staff() ) : ?>
			<p class="description"><?php esc_html_e( 'You already have staff members. Leave the boxes empty to keep them as they are.', 'roohsites-appointment-booking' ); ?></p>
		<?php endif; ?>
		<?php
	}

	private static function render_page( $state ) {
		$pages = get_pages( array( 'post_status' => 'publish' ) );
		?>
		<h1><?php esc_html_e( 'Where should the booking form go?', 'roohsites-appointment-booking' ); ?></h1>
		<p class="ss-setup-lead"><?php esc_html_e( 'A page clients open to book. Link to it from your menu, your Instagram bio or your WhatsApp profile.', 'roohsites-appointment-booking' ); ?></p>
		<label class="ss-setup-choice wide"><input type="radio" name="page_mode" value="new" checked><span><?php esc_html_e( 'Create a new page called “Book online”', 'roohsites-appointment-booking' ); ?></span></label>
		<?php if ( $pages ) : ?>
			<label class="ss-setup-choice wide"><input type="radio" name="page_mode" value="existing"><span><?php esc_html_e( 'Add it to the bottom of an existing page:', 'roohsites-appointment-booking' ); ?>
				<select name="page_id" aria-label="<?php esc_attr_e( 'Existing page', 'roohsites-appointment-booking' ); ?>">
					<?php foreach ( $pages as $page ) : ?>
						<option value="<?php echo (int) $page->ID; ?>"><?php echo esc_html( $page->post_title ? $page->post_title : '#' . $page->ID ); ?></option>
					<?php endforeach; ?>
				</select></span></label>
		<?php endif; ?>
		<label class="ss-setup-choice wide"><input type="radio" name="page_mode" value="none"><span><?php esc_html_e( 'I’ll add the Booking form block myself', 'roohsites-appointment-booking' ); ?></span></label>
		<?php
	}

	private static function render_done() {
		$state = self::state();
		$page  = $state['page_id'] ? get_permalink( $state['page_id'] ) : '';
		$mins  = ( $state['started'] && $state['finished'] ) ? max( 1, (int) round( ( $state['finished'] - $state['started'] ) / 60 ) ) : 0;
		?>
		<h1><?php esc_html_e( 'You’re ready to take bookings', 'roohsites-appointment-booking' ); ?></h1>
		<?php if ( $mins ) : ?>
			<p class="ss-setup-lead">
				<?php
				/* translators: %d: minutes. */
				echo esc_html( sprintf( _n( 'Set up in %d minute.', 'Set up in %d minutes.', $mins, 'roohsites-appointment-booking' ), $mins ) );
				?>
			</p>
		<?php endif; ?>
		<ol class="ss-setup-next">
			<?php if ( $page ) : ?>
				<li><strong><?php esc_html_e( 'Make a test booking.', 'roohsites-appointment-booking' ); ?></strong> <?php esc_html_e( 'Book a time the way a client would. It shows up under Roohsites Appointment Booking → Bookings, and you get the email.', 'roohsites-appointment-booking' ); ?><br><a class="button button-primary button-hero" href="<?php echo esc_url( $page ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open your booking page', 'roohsites-appointment-booking' ); ?></a></li>
			<?php else : ?>
				<li><strong><?php esc_html_e( 'Add the booking form to a page.', 'roohsites-appointment-booking' ); ?></strong> <?php esc_html_e( 'Edit any page, add the “Booking form” block (or the [rsab_booking] shortcode) and publish.', 'roohsites-appointment-booking' ); ?></li>
			<?php endif; ?>
			<li><strong><?php esc_html_e( 'Add photos and descriptions', 'roohsites-appointment-booking' ); ?></strong> <?php esc_html_e( 'to your services and staff.', 'roohsites-appointment-booking' ); ?> <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . Post_Types::SERVICE ) ); ?>"><?php esc_html_e( 'Services', 'roohsites-appointment-booking' ); ?></a> · <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . Post_Types::STAFF ) ); ?>"><?php esc_html_e( 'Staff', 'roohsites-appointment-booking' ); ?></a></li>
			<li><strong><?php esc_html_e( 'Choose your brand colour and font', 'roohsites-appointment-booking' ); ?></strong> <?php esc_html_e( 'and whether you approve bookings yourself.', 'roohsites-appointment-booking' ); ?> <a href="<?php echo esc_url( admin_url( 'admin.php?page=rsab-settings' ) ); ?>"><?php esc_html_e( 'Settings', 'roohsites-appointment-booking' ); ?></a></li>
		</ol>
		<p><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=' . Admin::MENU_SLUG ) ); ?>"><?php esc_html_e( 'Go to Bookings', 'roohsites-appointment-booking' ); ?></a></p>
		<?php
	}

	/* -----------------------------------------------------------------
	 * Saving
	 * -------------------------------------------------------------- */

	public static function save() {
		$step = isset( $_POST['step'] ) ? sanitize_key( wp_unslash( $_POST['step'] ) ) : '';
		check_admin_referer( self::ACTION . '_' . $step );
		if ( ! current_user_can( Plugin::capability() ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'roohsites-appointment-booking' ), 403 );
		}

		if ( 'skip' === $step ) {
			self::update( array( 'status' => 'skipped' ) );
			wp_safe_redirect( admin_url( 'admin.php?page=' . Admin::MENU_SLUG ) );
			exit;
		}

		$next = array( 'business' => 'hours', 'hours' => 'services', 'services' => 'staff', 'staff' => 'page', 'page' => 'done' );
		if ( ! isset( $next[ $step ] ) ) {
			wp_safe_redirect( self::url() );
			exit;
		}
		call_user_func( array( __CLASS__, 'save_' . $step ) );
		$changes = array( 'step' => $next[ $step ] );
		if ( 'page' === $step ) {
			$changes['status']   = 'done';
			$changes['finished'] = time();
		}
		self::update( $changes );
		wp_safe_redirect( self::url( $next[ $step ] ) );
		exit;
	}

	// phpcs:disable WordPress.Security.NonceVerification.Missing -- save() checks the nonce before calling these.

	private static function save_business() {
		$type = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : 'other';
		self::update( array( 'type' => isset( self::presets()[ $type ] ) ? $type : 'other' ) );
		if ( isset( $_POST['currency_code'] ) ) {
			$settings                  = Settings::all();
			$settings['currency_code'] = sanitize_text_field( wp_unslash( $_POST['currency_code'] ) );
			update_option( Settings::OPTION, Settings::sanitize( $settings ) );
		}
	}

	private static function save_hours() {
		$raw   = isset( $_POST['hours'] ) && is_array( $_POST['hours'] ) ? wp_unslash( $_POST['hours'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each value is checked below.
		$hours = array();
		$time  = function ( $v, $fallback ) {
			$v = sanitize_text_field( (string) $v );
			return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $v ) ? $v : $fallback;
		};
		for ( $d = 1; $d <= 7; $d++ ) {
			$row         = isset( $raw[ $d ] ) && is_array( $raw[ $d ] ) ? $raw[ $d ] : array();
			$hours[ $d ] = array(
				'on'    => ! empty( $row['on'] ),
				'start' => $time( isset( $row['start'] ) ? $row['start'] : '', '09:00' ),
				'end'   => $time( isset( $row['end'] ) ? $row['end'] : '', '17:00' ),
			);
		}
		self::update( array( 'hours' => $hours ) );
		if ( ! empty( $_POST['timezone_string'] ) ) {
			$tz = sanitize_text_field( wp_unslash( $_POST['timezone_string'] ) );
			if ( in_array( $tz, timezone_identifiers_list(), true ) ) {
				update_option( 'timezone_string', $tz );
			} elseif ( preg_match( '/^UTC([+-]\d+(\.\d+)?)$/', $tz, $m ) ) {
				update_option( 'timezone_string', '' );
				update_option( 'gmt_offset', (float) $m[1] );
			}
		}
	}

	private static function save_services() {
		$rows = isset( $_POST['services'] ) && is_array( $_POST['services'] ) ? wp_unslash( $_POST['services'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each value is sanitized below.
		$i    = 0;
		foreach ( $rows as $row ) {
			$name = isset( $row['name'] ) ? sanitize_text_field( $row['name'] ) : '';
			if ( '' === $name ) {
				continue;
			}
			$id = wp_insert_post(
				array(
					'post_type'   => Post_Types::SERVICE,
					'post_status' => 'publish',
					'post_title'  => mb_substr( $name, 0, 80 ),
					'menu_order'  => $i++,
				)
			);
			if ( ! $id || is_wp_error( $id ) ) {
				continue;
			}
			$minutes = isset( $row['minutes'] ) ? absint( $row['minutes'] ) : 60;
			update_post_meta( $id, '_rsab_duration', max( 5, min( 480, $minutes ? $minutes : 60 ) ) );
			update_post_meta( $id, '_rsab_buffer', 0 );
			update_post_meta( $id, '_rsab_step', 'length' );
			update_post_meta( $id, '_rsab_price', isset( $row['price'] ) ? substr( sanitize_text_field( $row['price'] ), 0, 20 ) : '' );
		}
	}

	private static function save_staff() {
		$names = isset( $_POST['staff'] ) && is_array( $_POST['staff'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['staff'] ) ) : array();
		$names = array_slice( array_values( array_filter( array_map( 'trim', $names ) ) ), 0, 4 );
		if ( ! $names && ! Post_Types::staff() ) {
			$names = array( wp_get_current_user()->display_name ? wp_get_current_user()->display_name : __( 'Me', 'roohsites-appointment-booking' ) );
		}
		$state    = self::state();
		$hours    = $state['hours'] ? $state['hours'] : Post_Types::default_hours();
		$services = wp_list_pluck( Post_Types::services(), 'id' );
		foreach ( $names as $name ) {
			$id = wp_insert_post(
				array(
					'post_type'   => Post_Types::STAFF,
					'post_status' => 'publish',
					'post_title'  => mb_substr( $name, 0, 60 ),
				)
			);
			if ( $id && ! is_wp_error( $id ) ) {
				update_post_meta( $id, '_rsab_services', array_map( 'intval', $services ) );
				update_post_meta( $id, '_rsab_hours', $hours );
			}
		}
	}

	private static function save_page() {
		$mode  = isset( $_POST['page_mode'] ) ? sanitize_key( wp_unslash( $_POST['page_mode'] ) ) : 'new';
		$block = '<!-- wp:' . Block::NAME . ' /-->';
		$page  = 0;
		if ( 'new' === $mode ) {
			$page = wp_insert_post(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => __( 'Book online', 'roohsites-appointment-booking' ),
					'post_content' => $block,
				)
			);
		} elseif ( 'existing' === $mode && ! empty( $_POST['page_id'] ) ) {
			$post = get_post( absint( $_POST['page_id'] ) );
			if ( $post && 'page' === $post->post_type && current_user_can( 'edit_post', $post->ID ) ) {
				if ( false === strpos( $post->post_content, Block::NAME ) && ! has_shortcode( $post->post_content, 'rsab_booking' ) ) {
					wp_update_post( array( 'ID' => $post->ID, 'post_content' => $post->post_content . "\n\n" . $block ) );
				}
				$page = $post->ID;
			}
		}
		self::update( array( 'page_id' => ( $page && ! is_wp_error( $page ) ) ? (int) $page : 0 ) );
	}

	// phpcs:enable
}
