<?php
namespace RSAB;

defined( 'ABSPATH' ) || exit;

/**
 * The [rsab_booking] booking form. The markup is built by assets/js/booking.js
 * from the JSON data printed here.
 */
final class Shortcode {

	public static function init() {
		add_shortcode( 'rsab_booking', array( __CLASS__, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		add_action( 'template_redirect', array( __CLASS__, 'skip_cache_for_form_pages' ), 0 );
	}

	/**
	 * Page caches such as LiteSpeed Cache decide whether to cache a page before its content is rendered, so the
	 * request made while rendering the form (no_page_cache()) can come too late. Pages and posts that contain
	 * the booking form block or shortcode are marked as not cacheable here, before the page is built.
	 */
	public static function skip_cache_for_form_pages() {
		if ( ! is_singular() ) {
			return;
		}
		$post = get_queried_object();
		if ( ! $post instanceof \WP_Post ) {
			return;
		}
		$has_form = has_shortcode( $post->post_content, 'rsab_booking' ) || has_block( 'rsab/booking-form', $post );
		if ( apply_filters( 'rsab_page_has_booking_form', $has_form, $post ) ) {
			self::no_page_cache();
			nocache_headers();
		}
	}

	public static function register_assets() {
		wp_register_style( 'roohsites-appointment-booking', RSAB_URL . 'assets/css/booking.css', array(), Plugin::asset_version( 'assets/css/booking.css' ) );
		wp_register_script( 'roohsites-appointment-booking', RSAB_URL . 'assets/js/booking.js', array(), Plugin::asset_version( 'assets/js/booking.js' ), true );
		wp_add_inline_script(
			'roohsites-appointment-booking',
			'window.rsabConfig = ' . wp_json_encode(
				array(
					'restUrl'     => esc_url_raw( rest_url( Rest::NAMESPACE_V1 . '/' ) ),
					// Only logged-in users need it (booking is public). A guest's token would expire inside a cached page.
					'nonce'       => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
					'locale'      => str_replace( '_', '-', get_locale() ),
					'startOfWeek' => (int) get_option( 'start_of_week', 1 ),
					'siteName'    => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
					'i18n'        => array(
						'steps'            => array( __( 'Service', 'roohsites-appointment-booking' ), __( 'Date & time', 'roohsites-appointment-booking' ), __( 'Your details', 'roohsites-appointment-booking' ) ),
						'chooseService'    => __( 'Choose a service', 'roohsites-appointment-booking' ),
						'chooseStaff'      => __( 'Choose a professional', 'roohsites-appointment-booking' ),
						'anyone'           => __( 'Anyone', 'roohsites-appointment-booking' ),
						'anyoneSub'        => __( 'First available', 'roohsites-appointment-booking' ),
						'pickDateTime'     => __( 'Pick a date and time', 'roohsites-appointment-booking' ),
						'selectDate'       => __( 'Select a date to see times.', 'roohsites-appointment-booking' ),
						'noTimes'          => __( 'No times left on this day.', 'roohsites-appointment-booking' ),
						'noDays'           => __( 'Fully booked this month. Try the next month.', 'roohsites-appointment-booking' ),
						'morning'          => __( 'Morning', 'roohsites-appointment-booking' ),
						'afternoon'        => __( 'Afternoon', 'roohsites-appointment-booking' ),
						'evening'          => __( 'Evening', 'roohsites-appointment-booking' ),
						'prevMonth'        => __( 'Previous month', 'roohsites-appointment-booking' ),
						'nextMonth'        => __( 'Next month', 'roohsites-appointment-booking' ),
						'yourDetails'      => __( 'Your details', 'roohsites-appointment-booking' ),
						'name'             => __( 'Full name', 'roohsites-appointment-booking' ),
						'email'            => __( 'Email', 'roohsites-appointment-booking' ),
						'phone'            => __( 'Phone', 'roohsites-appointment-booking' ),
						'notes'            => __( 'Anything we should know?', 'roohsites-appointment-booking' ),
						'optional'         => __( 'optional', 'roohsites-appointment-booking' ),
						'summary'          => __( 'Booking summary', 'roohsites-appointment-booking' ),
						'service'          => __( 'Service', 'roohsites-appointment-booking' ),
						'with'             => __( 'With', 'roohsites-appointment-booking' ),
						/* translators: 1: service name, 2: staff member name */
						'serviceWith'      => __( '%1$s with %2$s', 'roohsites-appointment-booking' ),
						'date'             => __( 'Date', 'roohsites-appointment-booking' ),
						'time'             => __( 'Time', 'roohsites-appointment-booking' ),
						'duration'         => __( 'Duration', 'roohsites-appointment-booking' ),
						/* translators: %d: number of minutes */
						'durMin'           => __( '%d min', 'roohsites-appointment-booking' ),
						/* translators: %s: number of hours, e.g. 1 or 1.5 */
						'durHrOne'         => _n( '%s hr', '%s hrs', 1, 'roohsites-appointment-booking' ),
						/* translators: %s: number of hours, e.g. 1 or 1.5 */
						'durHrMany'        => _n( '%s hr', '%s hrs', 2, 'roohsites-appointment-booking' ),
						'price'            => __( 'Price', 'roohsites-appointment-booking' ),
						'payInPerson'      => __( 'Pay at your appointment', 'roohsites-appointment-booking' ),
						'continue'         => __( 'Continue', 'roohsites-appointment-booking' ),
						'back'             => __( 'Back', 'roohsites-appointment-booking' ),
						'confirm'          => __( 'Confirm booking', 'roohsites-appointment-booking' ),
						'booking'          => __( 'Booking…', 'roohsites-appointment-booking' ),
						'bookedTitle'      => __( 'You’re booked!', 'roohsites-appointment-booking' ),
						'requestedTitle'   => __( 'Request received', 'roohsites-appointment-booking' ),
						'addToCalendar'    => __( 'Add to calendar', 'roohsites-appointment-booking' ),
						'bookAnother'      => __( 'Book another appointment', 'roohsites-appointment-booking' ),
						'error'            => __( 'Something went wrong. Please try again.', 'roohsites-appointment-booking' ),
						'pickService'      => __( 'No service selected', 'roohsites-appointment-booking' ),
					),
				)
			) . ';',
			'before'
		);
	}

	public static function render( $atts ) {
		$atts = shortcode_atts(
			array(
				'service' => 0,
				'staff'   => 0,
			),
			$atts,
			'roohsites-appointment-booking'
		);

		$services = Post_Types::services();
		$staff    = Post_Types::staff();

		if ( ! $services || ! $staff ) {
			if ( current_user_can( Plugin::capability() ) ) {
				return '<p class="rsab-notice">' . esc_html__( 'Roohsites Appointment Booking: add at least one service and one staff member offering it to show the booking form.', 'roohsites-appointment-booking' ) . '</p>';
			}
			return '';
		}

		wp_enqueue_style( 'roohsites-appointment-booking' );
		wp_enqueue_script( 'roohsites-appointment-booking' );
		self::no_page_cache();

		$tz    = wp_timezone();
		$today = new \DateTimeImmutable( 'now', $tz );

		$data = array(
			'today'     => $today->format( 'Y-m-d' ),
			'maxDate'   => $today->modify( '+' . (int) Settings::get( 'max_days_ahead' ) . ' days' )->format( 'Y-m-d' ),
			'preselect' => array(
				'service' => (int) $atts['service'],
				'staff'   => (int) $atts['staff'],
			),
			'services'  => array_map(
				function ( $service ) {
					return array(
						'id'          => $service['id'],
						'name'        => $service['name'],
						'description' => $service['description'],
						'duration'      => $service['duration'],
						'durationLabel' => self::duration_label( $service['duration'] ),
						'price'         => Post_Types::format_price( $service['price'] ),
						'photo'         => $service['photo'],
					);
				},
				$services
			),
			'staff'     => array_map(
				function ( $member ) {
					return array(
						'id'       => $member['id'],
						'name'     => $member['name'],
						'services' => $member['services'],
						'photo'    => $member['photo'],
					);
				},
				$staff
			),
		);

		// Coming back from an add-on step such as payment: show the result screen.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the secret token identifies the booking.
		$token = isset( $_GET['rsab_booking'] ) ? sanitize_text_field( wp_unslash( $_GET['rsab_booking'] ) ) : '';
		if ( preg_match( '/^[a-f0-9]{32}$/', $token ) ) {
			$booking = Bookings::get_by_token( $token );
			if ( $booking ) {
				$data['returned'] = Rest::summary( $booking );
			}
		}

		/**
		 * Filters the data the booking form is built from (e.g. to add service extras or form fields).
		 *
		 * @param array $data Form data.
		 * @param array $atts Shortcode attributes.
		 */
		$data = apply_filters( 'rsab_form_data', $data, $atts );

		return sprintf(
			'<div class="ssm" data-rsab style="%1$s"><script type="application/json" class="ssm-data">%2$s</script><noscript><p>%3$s</p></noscript></div>',
			esc_attr( Settings::style_vars() ),
			wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ),
			esc_html__( 'Please enable JavaScript to book an appointment.', 'roohsites-appointment-booking' )
		);
	}

	/**
	 * The form carries today's date and the current settings, so a cached copy goes stale: ask page
	 * caches to skip this page. WP Rocket, W3 Total Cache, WP Super Cache and LiteSpeed Cache honour it.
	 */
	public static function no_page_cache() {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- the standard flag read by page caches.
		}
		do_action( 'litespeed_control_set_nocache', 'Roohsites Appointment Booking booking form' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LiteSpeed Cache's own hook.
	}

	private static function duration_label( $minutes ) {
		if ( $minutes < 60 || $minutes % 30 ) {
			/* translators: %d: number of minutes */
			return sprintf( __( '%d min', 'roohsites-appointment-booking' ), $minutes );
		}
		$hours = $minutes / 60;
		/* translators: %s: number of hours, e.g. 1 or 1.5 */
		return sprintf( _n( '%s hr', '%s hrs', (int) ceil( $hours ), 'roohsites-appointment-booking' ), number_format_i18n( $hours, $minutes % 60 ? 1 : 0 ) );
	}
}
