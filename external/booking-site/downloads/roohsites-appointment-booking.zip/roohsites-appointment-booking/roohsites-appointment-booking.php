<?php
/**
 * Plugin Name:       Roohsites Appointment Booking
 * Plugin URI:        https://booking.roohsites.com
 * Description:       Simple appointment booking for salons, tutors, coaches and other service businesses.
 * Version:           1.0.1
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Sahil Arora
 * Author URI:        https://roohsites.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       roohsites-appointment-booking
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'RSAB_VERSION', '1.0.1' );
define( 'RSAB_FILE', __FILE__ );
define( 'RSAB_DIR', plugin_dir_path( __FILE__ ) );
define( 'RSAB_URL', plugin_dir_url( __FILE__ ) );

require_once RSAB_DIR . 'includes/class-settings.php';
require_once RSAB_DIR . 'includes/class-install.php';
require_once RSAB_DIR . 'includes/class-post-types.php';
require_once RSAB_DIR . 'includes/class-bookings.php';
require_once RSAB_DIR . 'includes/class-availability.php';
require_once RSAB_DIR . 'includes/class-rate-limit.php';
require_once RSAB_DIR . 'includes/class-rest.php';
require_once RSAB_DIR . 'includes/class-shortcode.php';
require_once RSAB_DIR . 'includes/class-block.php';
require_once RSAB_DIR . 'includes/class-emails.php';
require_once RSAB_DIR . 'includes/class-cancel.php';
require_once RSAB_DIR . 'includes/class-privacy.php';
require_once RSAB_DIR . 'includes/class-admin.php';
require_once RSAB_DIR . 'includes/class-setup.php';
require_once RSAB_DIR . 'includes/class-plugin.php';

register_activation_hook( __FILE__, array( 'RSAB\Install', 'activate' ) );
add_action( 'plugins_loaded', array( 'RSAB\Plugin', 'init' ) );
