<?php
/**
 * Removes Roohsites Appointment Booking data, but only if the site owner opted in under Settings.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$rsab_settings = get_option( 'rsab_settings' );
if ( empty( $rsab_settings['delete_on_uninstall'] ) ) {
	return;
}

global $wpdb;

// Removing the plugin's own table on uninstall (only when the owner opted in above).
$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . 'rsab_bookings' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange

foreach ( array( 'rsab_service', 'rsab_staff' ) as $rsab_type ) {
	$rsab_ids = get_posts(
		array(
			'post_type'   => $rsab_type,
			'post_status' => 'any',
			'numberposts' => -1,
			'fields'      => 'ids',
		)
	);
	foreach ( $rsab_ids as $rsab_id ) {
		wp_delete_post( $rsab_id, true );
	}
}

delete_option( 'rsab_settings' );
delete_option( 'rsab_db_version' );
delete_option( 'rsab_setup' );
