( function () {
	'use strict';

	var config = window.slotsmithConfig || {};
	var t = config.i18n || {};
	var uid = 0;

	/*
	 * Extension points for add-ons. Register before DOMContentLoaded:
	 *   window.slotsmithHooks.add( 'detailsFields', function ( fields, ctx ) { ...; return fields; } );
	 * Hooks: requestParams, bookingPayload, servicePanel, detailsFields, summaryRows,
	 * summaryTotal, footerPrice, footerDuration, confirmLabel, serviceChanged.
 * ctx.durationLabel( minutes ) formats a length the way service durations are shown.
	 */
	var hooks = window.slotsmithHooks = window.slotsmithHooks || { filters: {} };
	hooks.filters = hooks.filters || {};
	hooks.add = hooks.add || function ( name, fn ) {
		( hooks.filters[ name ] = hooks.filters[ name ] || [] ).push( fn );
	};

	/*
	 * A length in minutes as the services show it: "45 min", "1 hr", "1.5 hrs" (same rules as the PHP side).
	 */
	function durationLabel( minutes ) {
		if ( minutes < 60 || minutes % 30 ) {
			return ( t.durMin || '%d min' ).replace( '%d', minutes );
		}
		var hours = minutes / 60;
		var text = hours.toLocaleString( document.documentElement.lang || undefined, { minimumFractionDigits: minutes % 60 ? 1 : 0, maximumFractionDigits: 1 } );
		return ( Math.ceil( hours ) === 1 ? t.durHrOne || '%s hr' : t.durHrMany || '%s hrs' ).replace( '%s', text );
	}

	function applyHook( name, value, ctx ) {
		( hooks.filters[ name ] || [] ).forEach( function ( fn ) {
			value = fn( value, ctx );
		} );
		return value;
	}

	var ICONS = {
		clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
		check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
		left: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>',
		right: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
		users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.4 3.2-5.5 6.5-5.5s5.9 2.1 6.5 5.5"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18.5 14.8c1.6.8 2.7 2.6 3 5.2"/></svg>',
		calendar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>',
		alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5M12 16.5v.01"/></svg>',
	};

	/* ------------------------------------------------------------------
	 * Helpers
	 * ---------------------------------------------------------------- */

	function h( tag, props, children ) {
		var el = document.createElement( tag );
		Object.keys( props || {} ).forEach( function ( key ) {
			var value = props[ key ];
			if ( value === null || value === undefined || value === false ) {
				return;
			}
			if ( key === 'class' ) {
				el.className = value;
			} else if ( key === 'text' ) {
				el.textContent = value;
			} else if ( key.indexOf( 'on' ) === 0 ) {
				el.addEventListener( key.slice( 2 ).toLowerCase(), value );
			} else {
				el.setAttribute( key, value === true ? '' : value );
			}
		} );
		[].concat( children === undefined ? [] : children ).forEach( function ( child ) {
			if ( child === null || child === undefined || child === false ) {
				return;
			}
			el.appendChild( typeof child === 'string' ? document.createTextNode( child ) : child );
		} );
		return el;
	}

	function icon( name, extraClass ) {
		var span = h( 'span', { class: 'ssm-icon' + ( extraClass ? ' ' + extraClass : '' ), 'aria-hidden': 'true' } );
		span.innerHTML = ICONS[ name ]; // Static, trusted markup.
		return span;
	}

	function endpoint( path, params ) {
		// Works with pretty permalinks (/wp-json/...) and plain ones (?rest_route=...).
		var url = new URL( config.restUrl, window.location.href );
		if ( url.searchParams.has( 'rest_route' ) ) {
			url.searchParams.set( 'rest_route', url.searchParams.get( 'rest_route' ) + path );
		} else {
			url.pathname += path;
		}
		Object.keys( params || {} ).forEach( function ( key ) {
			url.searchParams.set( key, params[ key ] );
		} );
		return url.toString();
	}

	function request( url, options ) {
		options = options || {};
		// Logged-in users only: guests don't get a token, so cached pages can't hold an expired one.
		options.headers = Object.assign( config.nonce ? { 'X-WP-Nonce': config.nonce } : {}, options.headers || {} );
		return fetch( url, options ).then( function ( res ) {
			return res.json().catch( function () {
				return {};
			} ).then( function ( data ) {
				if ( ! res.ok ) {
					var err = new Error( data.message || t.error );
					err.code = data.code;
					throw err;
				}
				return data;
			} );
		} );
	}

	function pad( n ) {
		return ( n < 10 ? '0' : '' ) + n;
	}

	function parseKey( key ) {
		var p = key.split( '-' ).map( Number );
		return { y: p[ 0 ], m: p[ 1 ], d: p[ 2 ] || 1 };
	}

	// Dates are calendar days in the site time zone, so format them as UTC to avoid shifting.
	function formatDay( key, options ) {
		var p = parseKey( key );
		var date = new Date( Date.UTC( p.y, p.m - 1, p.d ) );
		options = Object.assign( { timeZone: 'UTC' }, options );
		try {
			return date.toLocaleDateString( config.locale, options );
		} catch ( e ) {
			return date.toLocaleDateString( undefined, options );
		}
	}

	function initials( name ) {
		// Only words that start with a letter or digit, so "Blow-dry & styling" gives "BS", not "B&".
		return name.split( /\s+/ ).filter( function ( w ) {
			return /^[\p{L}\p{N}]/u.test( w );
		} ).slice( 0, 2 ).map( function ( w ) {
			return w.charAt( 0 );
		} ).join( '' ).toUpperCase();
	}

	function avatar( member ) {
		if ( member.photo ) {
			return h( 'img', { class: 'ssm-avatar', src: member.photo, alt: '' } );
		}
		var el = h( 'span', { class: 'ssm-avatar', 'aria-hidden': 'true', text: initials( member.name ) } );
		el.style.setProperty( '--ssm-hue', ( member.id * 47 ) % 360 );
		return el;
	}

	function icsDate( ts ) {
		var d = new Date( ts * 1000 );
		return d.getUTCFullYear() + pad( d.getUTCMonth() + 1 ) + pad( d.getUTCDate() ) + 'T' + pad( d.getUTCHours() ) + pad( d.getUTCMinutes() ) + '00Z';
	}

	function icsText( s ) {
		return String( s ).replace( /[\\,;]/g, '\\$&' ).replace( /\n/g, '\\n' );
	}

	/* ------------------------------------------------------------------
	 * Booking widget
	 * ---------------------------------------------------------------- */

	function init( root ) {
		var data = JSON.parse( root.querySelector( '.ssm-data' ).textContent );
		var id = 'ssm-' + ( ++uid );
		var app = h( 'div', { class: 'ssm-app' } );
		var state = {
			step: 1,
			service: null,
			staff: 0,
			month: data.today.slice( 0, 7 ),
			date: null,
			days: null,
			slots: null,
			slot: null,
			details: { name: '', email: '', phone: '', notes: '' },
			error: '',
			result: null,
			busy: false,
		};
		var refs = {};
		var latest = 0;
		var ctx = {
			state: state,
			data: data,
			t: t,
			config: config,
			h: h,
			icon: icon,
			render: function () {
				render();
			},
			refreshFooter: function () {
				refreshFooter();
			},
			durationLabel: durationLabel,
		};

		state.service = findService( data.preselect.service ) || ( data.services.length === 1 ? data.services[ 0 ] : null );
		if ( state.service && offers( findStaff( data.preselect.staff ), state.service ) ) {
			state.staff = data.preselect.staff;
		}

		// Returning from an add-on step (e.g. payment) straight to the result screen.
		if ( data.returned ) {
			state.step = 4;
			state.result = data.returned;
			state.date = data.returned.date;
			state.slot = { start: data.returned.start, label: data.returned.timeLabel };
			if ( window.history.replaceState ) {
				var clean = new URL( window.location.href );
				clean.searchParams.delete( 'slotsmith_booking' );
				window.history.replaceState( null, '', clean.toString() );
			}
		}

		root.appendChild( app );
		render();

		function findService( serviceId ) {
			return data.services.filter( function ( s ) {
				return s.id === serviceId;
			} )[ 0 ] || null;
		}

		function findStaff( staffId ) {
			return data.staff.filter( function ( s ) {
				return s.id === staffId;
			} )[ 0 ] || null;
		}

		function offers( member, service ) {
			return !! member && !! service && member.services.indexOf( service.id ) !== -1;
		}

		function staffName() {
			var member = findStaff( state.staff );
			return member ? member.name : t.anyone;
		}

		function go( step ) {
			state.step = step;
			state.error = '';
			if ( step === 2 ) {
				state.days = null; // Always show fresh availability.
			}
			render();
			var heading = app.querySelector( '.ssm-title' );
			if ( heading ) {
				heading.focus( { preventScroll: true } );
			}
			if ( root.getBoundingClientRect().top < 0 ) {
				root.scrollIntoView( { behavior: 'smooth', block: 'start' } );
			}
		}

		/* ----- Layout ----- */

		function render( focusSelector ) {
			app.innerHTML = '';
			app.appendChild( stepper() );

			var body = h( 'div', { class: 'ssm-body' + ( state.step !== refs.renderedStep ? ' is-entering' : '' ) } );
			refs.renderedStep = state.step;
			if ( state.error ) {
				body.appendChild( h( 'div', { class: 'ssm-alert', role: 'alert' }, [ icon( 'alert' ), h( 'span', { text: state.error } ) ] ) );
			}
			if ( state.step === 1 ) {
				stepService( body );
			} else if ( state.step === 2 ) {
				stepWhen( body );
			} else if ( state.step === 3 ) {
				stepDetails( body );
			} else {
				stepDone( body );
			}
			app.appendChild( body );

			if ( state.step < 4 ) {
				refs.footer = footer();
				app.appendChild( refs.footer );
			}

			if ( focusSelector ) {
				var el = app.querySelector( focusSelector );
				if ( el ) {
					el.focus();
				}
			}
			if ( state.step === 2 && state.days === null ) {
				loadDays();
			}
		}

		function stepper() {
			var list = h( 'ol', { class: 'ssm-steps' } );
			( t.steps || [] ).forEach( function ( label, i ) {
				var n = i + 1;
				var cls = 'ssm-step' + ( n === state.step ? ' is-active' : '' ) + ( n < state.step ? ' is-done' : '' );
				list.appendChild(
					h( 'li', { class: cls, 'aria-current': n === state.step ? 'step' : null }, [
						h( 'span', { class: 'ssm-step-num' }, n < state.step ? icon( 'check' ) : String( n ) ),
						h( 'span', { class: 'ssm-step-label', text: label } ),
					] )
				);
			} );
			return list;
		}

		function footer() {
			var parts = [];
			if ( state.service ) {
				parts.push( state.service.name );
				if ( state.step >= 2 && state.date ) {
					parts.push( formatDay( state.date, { weekday: 'short', day: 'numeric', month: 'short' } ) + ( state.slot ? ', ' + state.slot.label : '' ) );
				} else {
					parts.push( applyHook( 'footerDuration', state.service.durationLabel, ctx ) );
				}
			}

			var footerPrice = state.service ? applyHook( 'footerPrice', state.service.price, ctx ) : '';
			var summary = h( 'div', { class: 'ssm-footer-summary' }, [
				h( 'span', { class: 'ssm-footer-main', text: parts.length ? parts.join( ' · ' ) : t.pickService } ),
				footerPrice ? h( 'span', { class: 'ssm-footer-price', text: footerPrice } ) : null,
			] );

			var actions = h( 'div', { class: 'ssm-actions' } );
			if ( state.step > 1 ) {
				actions.appendChild( h( 'button', { type: 'button', class: 'ssm-btn ssm-btn-ghost', onclick: function () {
					go( state.step - 1 );
				} }, t.back ) );
			}
			if ( state.step === 1 ) {
				actions.appendChild( h( 'button', { type: 'button', class: 'ssm-btn ssm-btn-primary', disabled: ! state.service, onclick: function () {
					go( 2 );
				} }, t.continue ) );
			} else if ( state.step === 2 ) {
				actions.appendChild( h( 'button', { type: 'button', class: 'ssm-btn ssm-btn-primary', disabled: ! state.slot, onclick: function () {
					go( 3 );
				} }, t.continue ) );
			} else {
				actions.appendChild( h( 'button', { type: 'submit', form: id + '-form', class: 'ssm-btn ssm-btn-primary', disabled: state.busy }, state.busy ? t.booking : applyHook( 'confirmLabel', t.confirm, ctx ) ) );
			}

			return h( 'div', { class: 'ssm-footer' }, [ summary, actions ] );
		}

		function refreshFooter() {
			var next = footer();
			app.replaceChild( next, refs.footer );
			refs.footer = next;
		}

		function title( text ) {
			return h( 'h3', { class: 'ssm-title', tabindex: '-1', text: text } );
		}

		/* ----- Step 1: service and staff ----- */

		function stepService( body ) {
			var list = h( 'div', { class: 'ssm-services' } );
			data.services.forEach( function ( service ) {
				var selected = state.service && state.service.id === service.id;
				var card = h( 'label', { class: 'ssm-service' + ( selected ? ' is-selected' : '' ) }, [
					h( 'input', { type: 'radio', class: 'ssm-sr', name: id + '-service', value: service.id, checked: selected, onchange: function () {
						state.service = service;
						applyHook( 'serviceChanged', null, ctx );
						if ( ! offers( findStaff( state.staff ), service ) ) {
							state.staff = 0;
						}
						state.date = null;
						state.slot = null;
						render( 'input[name="' + id + '-service"]:checked' );
						// Bring the professional picker into view when it opens below the fold.
						var panel = app.querySelector( '.ssm-service-panel' );
						if ( panel ) {
							panel.scrollIntoView( { behavior: 'smooth', block: 'nearest' } );
						}
					} } ),
					service.photo
						? h( 'img', { class: 'ssm-service-badge ssm-service-photo', src: service.photo, alt: '' } )
						: h( 'span', { class: 'ssm-service-badge', 'aria-hidden': 'true', text: initials( service.name ) } ),
					h( 'span', { class: 'ssm-service-main' }, [
						h( 'span', { class: 'ssm-service-name', text: service.name } ),
						service.description ? h( 'span', { class: 'ssm-service-desc', text: service.description } ) : null,
						h( 'span', { class: 'ssm-meta' }, [ icon( 'clock' ), service.durationLabel ] ),
					] ),
					service.price ? h( 'span', { class: 'ssm-service-price', text: service.price } ) : null,
					h( 'span', { class: 'ssm-check' }, icon( 'check' ) ),
				] );

				// The professional picker opens directly under the chosen service.
				list.appendChild( h( 'div', { class: 'ssm-service-item' + ( selected ? ' is-open' : '' ) }, [ card, selected ? staffPanel() : null ] ) );
			} );
			body.appendChild( h( 'section', { class: 'ssm-section' }, [ title( t.chooseService ), list ] ) );
		}

		function staffPanel() {
			var grid = h( 'div', { class: 'ssm-staff', role: 'radiogroup', 'aria-label': t.chooseStaff } );
			var options = [ { id: 0, name: t.anyone, sub: t.anyoneSub } ].concat( data.staff.filter( function ( m ) {
				return offers( m, state.service );
			} ) );
			options.forEach( function ( member ) {
				var selected = state.staff === member.id;
				grid.appendChild(
					h( 'label', { class: 'ssm-person' + ( selected ? ' is-selected' : '' ) }, [
						h( 'input', { type: 'radio', class: 'ssm-sr', name: id + '-staff', value: member.id, checked: selected, onchange: function () {
							state.staff = member.id;
							state.date = null;
							state.slot = null;
							render( 'input[name="' + id + '-staff"]:checked' );
						} } ),
						member.id ? avatar( member ) : h( 'span', { class: 'ssm-avatar ssm-avatar-any' }, icon( 'users' ) ),
						h( 'span', { class: 'ssm-person-name', text: member.name } ),
						member.sub ? h( 'span', { class: 'ssm-person-sub', text: member.sub } ) : null,
					] )
				);
			} );
			return h( 'div', { class: 'ssm-service-panel' }, [ h( 'h4', { class: 'ssm-subtitle', text: t.chooseStaff } ), grid ].concat( applyHook( 'servicePanel', [], ctx ) ) );
		}

		/* ----- Step 2: date and time ----- */

		function stepWhen( body ) {
			refs.calendar = h( 'div', { class: 'ssm-calendar' } );
			refs.times = h( 'div', { class: 'ssm-times', 'aria-live': 'polite' } );
			body.appendChild( title( t.pickDateTime ) );
			body.appendChild( h( 'div', { class: 'ssm-when' }, [ refs.calendar, refs.times ] ) );
			renderCalendar();
			renderTimes();
		}

		function shiftMonth( delta ) {
			var p = parseKey( state.month );
			var d = new Date( Date.UTC( p.y, p.m - 1 + delta, 1 ) );
			state.month = d.getUTCFullYear() + '-' + pad( d.getUTCMonth() + 1 );
			state.date = null;
			state.slot = null;
			loadDays();
			refreshFooter();
		}

		function renderCalendar() {
			var cal = refs.calendar;
			var p = parseKey( state.month );
			var minMonth = data.today.slice( 0, 7 );
			var maxMonth = data.maxDate.slice( 0, 7 );
			var start = ( typeof config.startOfWeek === 'number' ) ? config.startOfWeek : 1;

			cal.innerHTML = '';
			cal.classList.toggle( 'is-loading', state.days === null );

			cal.appendChild(
				h( 'div', { class: 'ssm-cal-head' }, [
					h( 'span', { class: 'ssm-cal-title', text: formatDay( state.month + '-01', { month: 'long', year: 'numeric' } ) } ),
					h( 'div', { class: 'ssm-cal-nav' }, [
						h( 'button', { type: 'button', class: 'ssm-icon-btn', 'aria-label': t.prevMonth, disabled: state.month <= minMonth, onclick: function () {
							shiftMonth( -1 );
						} }, icon( 'left' ) ),
						h( 'button', { type: 'button', class: 'ssm-icon-btn', 'aria-label': t.nextMonth, disabled: state.month >= maxMonth, onclick: function () {
							shiftMonth( 1 );
						} }, icon( 'right' ) ),
					] ),
				] )
			);

			var grid = h( 'div', { class: 'ssm-cal-grid' } );
			for ( var i = 0; i < 7; i++ ) {
				// 2023-01-01 was a Sunday.
				var weekday = formatDay( '2023-01-' + pad( 1 + ( ( start + i ) % 7 ) ), { weekday: 'narrow' } );
				grid.appendChild( h( 'span', { class: 'ssm-cal-dow', 'aria-hidden': 'true', text: weekday } ) );
			}

			var first = new Date( Date.UTC( p.y, p.m - 1, 1 ) ).getUTCDay();
			var count = new Date( Date.UTC( p.y, p.m, 0 ) ).getUTCDate();
			for ( var b = 0; b < ( first - start + 7 ) % 7; b++ ) {
				grid.appendChild( h( 'span', { class: 'ssm-cal-blank' } ) );
			}
			for ( var d = 1; d <= count; d++ ) {
				( function ( key, day ) {
					var available = !! state.days && state.days.indexOf( key ) !== -1;
					var cls = 'ssm-day' + ( available ? ' is-available' : '' ) + ( key === state.date ? ' is-selected' : '' ) + ( key === data.today ? ' is-today' : '' );
					grid.appendChild(
						h( 'button', {
							type: 'button',
							class: cls,
							disabled: ! available,
							'aria-pressed': key === state.date ? 'true' : 'false',
							'aria-label': formatDay( key, { weekday: 'long', day: 'numeric', month: 'long' } ),
							onclick: function () {
								state.date = key;
								state.slot = null;
								renderCalendar();
								loadSlots();
								refreshFooter();
							},
						}, String( day ) )
					);
				} )( state.month + '-' + pad( d ), d );
			}
			cal.appendChild( grid );
		}

		function loadDays() {
			var token = ++latest;
			state.days = null;
			state.slots = null;
			renderCalendar();
			renderTimes();
			request( endpoint( 'days', applyHook( 'requestParams', { service: state.service.id, staff: state.staff, month: state.month }, ctx ) ) )
				.then( function ( res ) {
					if ( token !== latest ) {
						return;
					}
					state.days = res.days || [];
					if ( ! state.date || state.days.indexOf( state.date ) === -1 ) {
						state.date = state.days[ 0 ] || null;
						state.slot = null;
					}
					renderCalendar();
					refreshFooter();
					if ( state.date ) {
						loadSlots();
					} else {
						renderTimes();
					}
				} )
				.catch( showError );
		}

		function loadSlots() {
			var token = ++latest;
			state.slots = null;
			renderTimes();
			request( endpoint( 'slots', applyHook( 'requestParams', { service: state.service.id, staff: state.staff, date: state.date }, ctx ) ) )
				.then( function ( res ) {
					if ( token !== latest ) {
						return;
					}
					state.slots = res.slots || [];
					if ( state.slot && ! state.slots.some( function ( s ) {
						return s.start === state.slot.start;
					} ) ) {
						state.slot = null;
					}
					renderTimes();
					refreshFooter();
				} )
				.catch( showError );
		}

		// Shows a loading error without re-rendering, so a failing request is not retried in a loop.
		function showError( err ) {
			var body = app.querySelector( '.ssm-body' );
			var old = body.querySelector( '.ssm-alert' );
			if ( old ) {
				old.remove();
			}
			state.error = err.message || t.error;
			body.insertBefore( h( 'div', { class: 'ssm-alert', role: 'alert' }, [ icon( 'alert' ), h( 'span', { text: state.error } ) ] ), body.firstChild );
		}

		function renderTimes() {
			var box = refs.times;
			box.innerHTML = '';

			if ( state.days !== null && ! state.days.length ) {
				box.appendChild( h( 'div', { class: 'ssm-empty' }, [ icon( 'calendar' ), h( 'p', { text: t.noDays } ) ] ) );
				return;
			}
			if ( ! state.date ) {
				if ( state.days === null ) {
					box.appendChild( skeleton() );
				} else {
					box.appendChild( h( 'div', { class: 'ssm-empty' }, [ icon( 'calendar' ), h( 'p', { text: t.selectDate } ) ] ) );
				}
				return;
			}

			box.appendChild( h( 'div', { class: 'ssm-times-date', text: formatDay( state.date, { weekday: 'long', day: 'numeric', month: 'long' } ) } ) );

			if ( state.slots === null ) {
				box.appendChild( skeleton() );
				return;
			}
			if ( ! state.slots.length ) {
				box.appendChild( h( 'div', { class: 'ssm-empty' }, [ icon( 'calendar' ), h( 'p', { text: t.noTimes } ) ] ) );
				return;
			}

			var groups = [
				{ label: t.morning, test: function ( hr ) {
					return hr < 12;
				} },
				{ label: t.afternoon, test: function ( hr ) {
					return hr >= 12 && hr < 17;
				} },
				{ label: t.evening, test: function ( hr ) {
					return hr >= 17;
				} },
			];

			groups.forEach( function ( group ) {
				var slots = state.slots.filter( function ( s ) {
					return group.test( s.hour );
				} );
				if ( ! slots.length ) {
					return;
				}
				var grid = h( 'div', { class: 'ssm-slot-grid' } );
				slots.forEach( function ( slot ) {
					var selected = state.slot && state.slot.start === slot.start;
					grid.appendChild(
						h( 'button', {
							type: 'button',
							class: 'ssm-slot' + ( selected ? ' is-selected' : '' ),
							'aria-pressed': selected ? 'true' : 'false',
							onclick: function () {
								state.slot = slot;
								grid.parentNode.parentNode.querySelectorAll( '.ssm-slot' ).forEach( function ( btn ) {
									btn.classList.remove( 'is-selected' );
									btn.setAttribute( 'aria-pressed', 'false' );
								} );
								this.classList.add( 'is-selected' );
								this.setAttribute( 'aria-pressed', 'true' );
								refreshFooter();
							},
						}, slot.endLabel
							? [ h( 'span', { class: 'ssm-slot-start', text: slot.label } ), h( 'span', { class: 'ssm-slot-end', text: '– ' + slot.endLabel } ) ]
							: slot.label )
					);
				} );
				box.appendChild( h( 'div', { class: 'ssm-slot-group' }, [ h( 'div', { class: 'ssm-slot-label', text: group.label } ), grid ] ) );
			} );
		}

		function skeleton() {
			var grid = h( 'div', { class: 'ssm-slot-grid ssm-skeleton', 'aria-hidden': 'true' } );
			for ( var i = 0; i < 9; i++ ) {
				grid.appendChild( h( 'span', { class: 'ssm-slot' } ) );
			}
			return grid;
		}

		/* ----- Step 3: details ----- */

		function field( name, label, attrs, optional ) {
			var inputId = id + '-' + name;
			var tag = name === 'notes' ? 'textarea' : 'input';
			var input = h( tag, Object.assign( { id: inputId, name: name, class: 'ssm-input', oninput: function () {
				state.details[ name ] = this.value;
			} }, attrs ) );
			input.value = state.details[ name ];
			return h( 'div', { class: 'ssm-field' + ( name === 'notes' ? ' ssm-field-wide' : '' ) }, [
				h( 'label', { for: inputId }, [ label, optional ? h( 'span', { class: 'ssm-optional', text: ' (' + t.optional + ')' } ) : null ] ),
				input,
			] );
		}

		function summaryCard() {
			var rows = applyHook( 'summaryRows', [
				[ t.service, state.service.name ],
				[ t.with, staffName() ],
				[ t.date, formatDay( state.date, { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' } ) ],
				[ t.time, state.slot.label ],
				[ t.duration, state.service.durationLabel ],
			], ctx );
			var list = h( 'dl', { class: 'ssm-summary-list' } );
			rows.forEach( function ( row ) {
				list.appendChild( h( 'div', {}, [ h( 'dt', { text: row[ 0 ] } ), h( 'dd', { text: row[ 1 ] } ) ] ) );
			} );
			var children = [ h( 'div', { class: 'ssm-summary-title', text: t.summary } ), list ];
			var total = applyHook( 'summaryTotal', state.service.price ? { label: t.price, value: state.service.price, note: t.payInPerson } : null, ctx );
			if ( total ) {
				children.push(
					h( 'div', { class: 'ssm-summary-total' }, [
						h( 'span', { text: total.label } ),
						h( 'strong', { text: total.value } ),
					] )
				);
				if ( total.note ) {
					children.push( h( 'p', { class: 'ssm-summary-note', text: total.note } ) );
				}
			}
			return h( 'aside', { class: 'ssm-summary' }, children );
		}

		function stepDetails( body ) {
			var form = h( 'form', { id: id + '-form', class: 'ssm-form', onsubmit: submit }, [
				field( 'name', t.name, { type: 'text', required: true, maxlength: '190', autocomplete: 'name' } ),
				field( 'email', t.email, { type: 'email', required: true, autocomplete: 'email' } ),
				field( 'phone', t.phone, { type: 'tel', maxlength: '50', autocomplete: 'tel', required: !! data.phoneRequired }, ! data.phoneRequired ),
				field( 'notes', t.notes, { rows: '3', maxlength: '2000' }, true ),
			].concat( applyHook( 'detailsFields', [], ctx ), [
				h( 'div', { class: 'ssm-hp', 'aria-hidden': 'true' }, [
					h( 'label', { for: id + '-website', text: 'Website' } ),
					h( 'input', { id: id + '-website', type: 'text', name: 'website', tabindex: '-1', autocomplete: 'off' } ),
				] ),
			] ) );
			body.appendChild( title( t.yourDetails ) );
			body.appendChild( h( 'div', { class: 'ssm-details' }, [ form, summaryCard() ] ) );
		}

		function submit( event ) {
			event.preventDefault();
			if ( state.busy ) {
				return;
			}
			var form = event.target;
			state.busy = true;
			state.error = '';
			refreshFooter();

			request( endpoint( 'bookings' ), {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify( applyHook( 'bookingPayload', {
					service: state.service.id,
					staff: state.staff,
					start: state.slot.start,
					name: state.details.name,
					email: state.details.email,
					phone: state.details.phone,
					notes: state.details.notes,
					website: form.elements.website.value,
				}, ctx ) ),
			} )
				.then( function ( res ) {
					// An add-on step such as payment takes over from here.
					if ( res.redirect ) {
						window.location.assign( res.redirect );
						return;
					}
					state.busy = false;
					state.result = res;
					go( 4 );
				} )
				.catch( function ( err ) {
					state.busy = false;
					if ( err.code === 'slotsmith_slot_taken' ) {
						// Someone else took the time: go back and show fresh availability.
						state.slot = null;
						state.days = null;
						state.step = 2;
					}
					state.error = err.message;
					render();
				} );
		}

		/* ----- Step 4: done ----- */

		function stepDone( body ) {
			var res = state.result;
			var confirmed = res.status === 'confirmed';
			var held = ! confirmed && res.status !== 'pending'; // e.g. still waiting for payment.
			var when = formatDay( state.date, { weekday: 'long', day: 'numeric', month: 'long' } ) + ' · ' + state.slot.label;

			var calendarBtn = h( 'button', { type: 'button', class: 'ssm-btn ssm-btn-ghost', onclick: function () {
				var lines = [
					'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Slotsmith//EN', 'BEGIN:VEVENT',
					'UID:slotsmith-' + res.id + '@' + window.location.hostname,
					'DTSTAMP:' + icsDate( Math.floor( Date.now() / 1000 ) ),
					'DTSTART:' + icsDate( res.start ),
					'DTEND:' + icsDate( res.end ),
					'SUMMARY:' + icsText( res.service + ( config.siteName ? ' – ' + config.siteName : '' ) ),
					'DESCRIPTION:' + icsText( t.with + ': ' + res.staff ),
					'END:VEVENT', 'END:VCALENDAR',
				];
				var link = h( 'a', { href: URL.createObjectURL( new Blob( [ lines.join( '\r\n' ) ], { type: 'text/calendar' } ) ), download: 'appointment.ics' } );
				document.body.appendChild( link );
				link.click();
				link.remove();
			} }, [ icon( 'calendar' ), t.addToCalendar ] );

			body.appendChild(
				h( 'div', { class: 'ssm-done' }, [
					h( 'span', { class: 'ssm-done-icon' + ( confirmed ? '' : ' is-pending' ) + ( held ? ' is-warning' : '' ) }, icon( confirmed ? 'check' : ( held ? 'alert' : 'clock' ) ) ),
					h( 'h3', { class: 'ssm-title', tabindex: '-1', text: res.title || ( confirmed ? t.bookedTitle : t.requestedTitle ) } ),
					h( 'p', { class: 'ssm-done-when', text: when } ),
					h( 'p', { class: 'ssm-done-msg', text: t.serviceWith.replace( '%1$s', res.service ).replace( '%2$s', res.staff ) + '. ' + res.message } ),
					h( 'div', { class: 'ssm-done-actions' }, [
						res.action ? h( 'a', { class: 'ssm-btn ssm-btn-primary', href: res.action.url }, res.action.label ) : null,
						held ? null : calendarBtn,
						h( 'button', { type: 'button', class: 'ssm-link', onclick: function () {
							state.date = null;
							state.slot = null;
							state.result = null;
							state.details.notes = '';
							go( 1 );
						} }, t.bookAnother ),
					] ),
				] )
			);
		}
	}

	// Wait for DOMContentLoaded so add-on scripts loaded after this one can register hooks first.
	function start() {
		document.querySelectorAll( '[data-slotsmith]' ).forEach( init );
	}
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
} )();
