/**
 * "Booking form" block. On the live page the form is drawn by assets/js/booking.js,
 * so the editor shows a summary card and the sidebar picks what the form starts with.
 * Plain JavaScript on the wp.* globals: no build step.
 */
( function ( wp ) {
	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var sprintf = wp.i18n.sprintf;
	var blockEditor = wp.blockEditor;
	var components = wp.components;
	var data = window.slotsmithBlock || { services: [], staff: [] };

	var icon = el(
		'svg',
		{ xmlns: 'http://www.w3.org/2000/svg', viewBox: '0 0 24 24' },
		el( 'path', { d: 'M7 2.75a.75.75 0 0 1 .75.75V5h8.5V3.5a.75.75 0 0 1 1.5 0V5h.75A2.5 2.5 0 0 1 21 7.5v11a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 18.5v-11A2.5 2.5 0 0 1 5.5 5h.75V3.5A.75.75 0 0 1 7 2.75ZM4.5 10v8.5a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V10h-15Zm11.03 2.47a.75.75 0 0 1 0 1.06l-4 4a.75.75 0 0 1-1.06 0l-2-2a.75.75 0 1 1 1.06-1.06L11 15.94l3.47-3.47a.75.75 0 0 1 1.06 0Z' } )
	);

	function find( list, id ) {
		for ( var i = 0; i < list.length; i++ ) {
			if ( list[ i ].id === id ) {
				return list[ i ];
			}
		}
		return null;
	}

	function staffFor( service ) {
		return data.staff.filter( function ( member ) {
			return member.services.indexOf( service.id ) !== -1;
		} );
	}

	function options( list ) {
		return [ { value: '0', label: __( 'Customer chooses', 'slotsmith' ) } ].concat(
			list.map( function ( item ) {
				return { value: String( item.id ), label: item.name };
			} )
		);
	}

	function step( number, title, value ) {
		return el(
			'div',
			{ className: 'ssm-block__step' },
			el( 'span', { className: 'ssm-block__num' }, number ),
			el( 'span', { className: 'ssm-block__text' }, el( 'strong', {}, title ), el( 'span', {}, value ) )
		);
	}

	function Edit( props ) {
		var attrs = props.attributes;
		var service = find( data.services, attrs.service );
		var team = service ? staffFor( service ) : [];
		var member = service ? find( team, attrs.staff ) : null;
		var ready = data.services.length > 0 && data.staff.length > 0;
		var note = __( 'The live form appears when you preview or publish the page.', 'slotsmith' );

		if ( attrs.service && ! service ) {
			note = __( 'The chosen service is no longer published, so the form starts with the full list.', 'slotsmith' );
		} else if ( attrs.staff && service && ! member ) {
			note = __( 'The chosen staff member no longer offers this service, so customers choose who they book with.', 'slotsmith' );
		}

		var first = __( 'Customer chooses', 'slotsmith' );
		if ( service ) {
			/* translators: 1: service name, 2: staff member name */
			first = member ? sprintf( __( '%1$s with %2$s', 'slotsmith' ), service.name, member.name ) : service.name;
		}

		var body = ready
			? [
				el(
					'div',
					{ className: 'ssm-block__steps', key: 'steps' },
					step( 1, __( 'Service', 'slotsmith' ), first ),
					step( 2, __( 'Date & time', 'slotsmith' ), __( 'Customer picks a free time', 'slotsmith' ) ),
					step( 3, __( 'Your details', 'slotsmith' ), __( 'Name, email and phone', 'slotsmith' ) )
				),
				el( 'p', { className: 'ssm-block__note', key: 'note' }, note ),
			]
			: [
				el( 'p', { className: 'ssm-block__note ssm-block__note--warn', key: 'note' }, __( 'Add at least one service and one staff member offering it, and the booking form will show here.', 'slotsmith' ) ),
				data.canManage
					? el(
						'div',
						{ className: 'ssm-block__actions', key: 'actions' },
						el( components.Button, { variant: 'secondary', href: data.urls.addService, target: '_blank' }, __( 'Add a service', 'slotsmith' ) ),
						el( components.Button, { variant: 'secondary', href: data.urls.addStaff, target: '_blank' }, __( 'Add a staff member', 'slotsmith' ) )
					)
					: null,
			];

		return el(
			'div',
			blockEditor.useBlockProps( { className: 'ssm-block', style: { '--ssm-accent': data.accent } } ),
			el(
				blockEditor.InspectorControls,
				{},
				el(
					components.PanelBody,
					{ title: __( 'Start with', 'slotsmith' ) },
					el(
						'div',
						{ style: { marginBottom: '16px' } },
						el( components.SelectControl, {
							label: __( 'Service', 'slotsmith' ),
							value: String( service ? service.id : 0 ),
							options: options( data.services ),
							help: __( 'Already selected when the form opens. Customers can still change it.', 'slotsmith' ),
							onChange: function ( value ) {
								var next = find( data.services, parseInt( value, 10 ) );
								props.setAttributes( {
									service: next ? next.id : 0,
									staff: next && find( staffFor( next ), attrs.staff ) ? attrs.staff : 0,
								} );
							},
							__nextHasNoMarginBottom: true,
						} )
					),
					service
						? el(
							'div',
							{ style: { marginBottom: '16px' } },
							el( components.SelectControl, {
								label: __( 'Staff member', 'slotsmith' ),
								value: String( member ? member.id : 0 ),
								options: options( team ),
								onChange: function ( value ) {
									props.setAttributes( { staff: parseInt( value, 10 ) || 0 } );
								},
								__nextHasNoMarginBottom: true,
							} )
						)
						: null,
					data.canManage
						? el( components.ExternalLink, { href: data.urls.services }, __( 'Manage services and staff', 'slotsmith' ) )
						: null
				)
			),
			el(
				'div',
				{ className: 'ssm-block__head' },
				el( 'span', { className: 'ssm-block__icon' }, icon ),
				el(
					'span',
					{},
					el( 'strong', { className: 'ssm-block__title' }, __( 'Booking form', 'slotsmith' ) ),
					el( 'span', { className: 'ssm-block__sub' }, __( 'Customers choose a service, pick a time and book in under a minute.', 'slotsmith' ) )
				)
			),
			body
		);
	}

	function shortcodeText( attrs ) {
		return '[slotsmith' + ( attrs.service ? ' service="' + attrs.service + '"' : '' ) + ( attrs.staff ? ' staff="' + attrs.staff + '"' : '' ) + ']';
	}

	function number( value ) {
		return parseInt( value, 10 ) || 0;
	}

	wp.blocks.registerBlockType( 'slotsmith/booking-form', {
		icon: icon,
		edit: Edit,
		save: function () {
			return null;
		},
		transforms: {
			from: [
				{
					// Pasting [slotsmith ...] into the editor.
					type: 'shortcode',
					tag: 'slotsmith',
					attributes: {
						service: { type: 'integer', shortcode: function ( attrs ) {
							return number( attrs.named.service );
						} },
						staff: { type: 'integer', shortcode: function ( attrs ) {
							return number( attrs.named.staff );
						} },
					},
				},
				{
					// A Shortcode block holding only [slotsmith ...]: Transform to → Booking form.
					type: 'block',
					blocks: [ 'core/shortcode' ],
					isMatch: function ( attrs ) {
						return /^\[slotsmith(\s[^\]]*)?\]$/.test( ( attrs.text || '' ).trim() );
					},
					transform: function ( attrs ) {
						var match = wp.shortcode.next( 'slotsmith', attrs.text || '' );
						var named = match ? match.shortcode.attrs.named : {};
						return wp.blocks.createBlock( 'slotsmith/booking-form', { service: number( named.service ), staff: number( named.staff ) } );
					},
				},
			],
			to: [
				{
					type: 'block',
					blocks: [ 'core/shortcode' ],
					transform: function ( attrs ) {
						return wp.blocks.createBlock( 'core/shortcode', { text: shortcodeText( attrs ) } );
					},
				},
			],
		},
	} );
} )( window.wp );
