<?php
namespace Slotsmith;

use DateTimeImmutable;

defined( 'ABSPATH' ) || exit;

/**
 * Works out which start times are free for a service on a given day.
 */
final class Availability {

	/**
	 * @param int    $service_id     Service post ID.
	 * @param int    $staff_id       Staff post ID, or 0 for any staff member who offers the service.
	 * @param string $date           Day in the site time zone, as Y-m-d.
	 * @param int    $extra_minutes  Added to the service duration (e.g. service extras).
	 * @param int    $ignore_booking Booking ID to treat as free (used when rescheduling it).
	 * @return array Map of Unix timestamp => list of free staff IDs, sorted by time.
	 */
	public static function slots( $service_id, $staff_id, $date, $extra_minutes = 0, $ignore_booking = 0 ) {
		$service = Post_Types::service( $service_id );
		$tz      = wp_timezone();
		$day     = DateTimeImmutable::createFromFormat( '!Y-m-d', (string) $date, $tz );

		if ( ! $service || ! $day || $day->format( 'Y-m-d' ) !== $date ) {
			return array();
		}

		if ( $staff_id ) {
			$member = Post_Types::staff_member( $staff_id );
			$staff  = ( $member && in_array( (int) $service_id, $member['services'], true ) ) ? array( $member ) : array();
		} else {
			$staff = Post_Types::staff_for_service( $service_id );
		}

		$now      = time();
		$earliest = $now + (int) Settings::get( 'min_notice_hours' ) * HOUR_IN_SECONDS;
		$last_day = ( new DateTimeImmutable( 'now', $tz ) )->setTime( 0, 0 )->modify( '+' . (int) Settings::get( 'max_days_ahead' ) . ' days' );

		if ( $day > $last_day ) {
			return array();
		}

		$duration = $service['duration'] + max( 0, (int) $extra_minutes );
		$interval = max( 5, (int) $service['step'] ) * MINUTE_IN_SECONDS;
		$length   = $duration * MINUTE_IN_SECONDS;
		$blocked  = ( $duration + $service['buffer'] ) * MINUTE_IN_SECONDS;
		$weekday  = (int) $day->format( 'N' );
		$slots    = array();

		foreach ( $staff as $member ) {
			$hours = isset( $member['hours'][ $weekday ] ) ? $member['hours'][ $weekday ] : null;
			if ( in_array( $date, $member['days_off'], true ) ) {
				$hours = null;
			}

			/**
			 * Filters a staff member's working hours for one day (e.g. special opening hours).
			 *
			 * @param array|null $hours  Array with 'on', 'start' (H:i) and 'end' (H:i), or null when off.
			 * @param array      $member Staff data.
			 * @param string     $date   Y-m-d in the site time zone.
			 */
			$hours = apply_filters( 'slotsmith_staff_hours', $hours, $member, $date );
			if ( empty( $hours['on'] ) ) {
				continue;
			}

			$open  = self::at( $day, $hours['start'] );
			$close = self::at( $day, $hours['end'] );
			if ( $close <= $open ) {
				continue;
			}

			$busy = array();
			foreach ( Bookings::active_for_staff( $member['id'], gmdate( 'Y-m-d H:i:s', $open - DAY_IN_SECONDS ), gmdate( 'Y-m-d H:i:s', $close + DAY_IN_SECONDS ), $ignore_booking ) as $row ) {
				$busy[] = array( strtotime( $row['start_at'] . ' UTC' ), strtotime( $row['blocked_until'] . ' UTC' ) );
			}

			/**
			 * Filters the busy time ranges for a staff member on a day (e.g. breaks, external calendars).
			 *
			 * @param array  $busy   List of [start, end] Unix timestamps.
			 * @param array  $member Staff data.
			 * @param string $date   Y-m-d in the site time zone.
			 * @param int    $open   Opening time (Unix timestamp).
			 * @param int    $close  Closing time (Unix timestamp).
			 */
			$busy = apply_filters( 'slotsmith_busy_ranges', $busy, $member, $date, $open, $close );

			for ( $start = $open; $start + $length <= $close; $start += $interval ) {
				if ( $start < $earliest || self::overlaps( $busy, $start, $start + $blocked ) ) {
					continue;
				}
				$slots[ $start ][] = $member['id'];
			}
		}

		ksort( $slots );

		/**
		 * Filters the free slots for a day.
		 *
		 * @param array  $slots    Map of timestamp => staff IDs.
		 * @param array  $service  Service data.
		 * @param int    $staff_id Requested staff ID (0 = any).
		 * @param string $date     Y-m-d in the site time zone.
		 */
		return apply_filters( 'slotsmith_slots', $slots, $service, $staff_id, $date );
	}

	/**
	 * Unix timestamp for a H:i time on a day.
	 */
	public static function at( DateTimeImmutable $day, $time ) {
		list( $h, $m ) = array_map( 'intval', explode( ':', $time ) );
		return $day->setTime( $h, $m )->getTimestamp();
	}

	public static function overlaps( array $busy, $start, $end ) {
		foreach ( $busy as $range ) {
			if ( $range[0] < $end && $range[1] > $start ) {
				return true;
			}
		}
		return false;
	}
}
