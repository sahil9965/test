<?php
namespace Slotsmith;

defined( 'ABSPATH' ) || exit;

/**
 * The "Booking form" block: the [slotsmith] form, with the service and staff
 * to start with picked in the editor sidebar. Editor code: blocks/booking-form/.
 */
final class Block {

	const NAME = 'slotsmith/booking-form';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'editor_data' ) );
	}

	public static function register() {
		register_block_type( SLOTSMITH_DIR . 'blocks/booking-form', array( 'render_callback' => array( __CLASS__, 'render' ) ) );
	}

	public static function render( $attributes ) {
		$html = Shortcode::render(
			array(
				'service' => isset( $attributes['service'] ) ? (int) $attributes['service'] : 0,
				'staff'   => isset( $attributes['staff'] ) ? (int) $attributes['staff'] : 0,
			)
		);
		return '' === $html ? '' : '<div ' . get_block_wrapper_attributes() . '>' . $html . '</div>';
	}

	/**
	 * Services and staff for the sidebar menus (names only; nothing private).
	 */
	public static function editor_data() {
		$accent = sanitize_hex_color( Settings::get( 'accent_color' ) );
		$data   = array(
			'accent'    => $accent ? $accent : '#4f46e5',
			'canManage' => current_user_can( Plugin::capability() ),
			'services'  => array_map(
				function ( $service ) {
					return array(
						'id'   => $service['id'],
						'name' => $service['name'],
					);
				},
				Post_Types::services()
			),
			'staff'     => array_map(
				function ( $member ) {
					return array(
						'id'       => $member['id'],
						'name'     => $member['name'],
						'services' => $member['services'],
					);
				},
				Post_Types::staff()
			),
			'urls'      => array(
				'services'   => admin_url( 'edit.php?post_type=' . Post_Types::SERVICE ),
				'addService' => admin_url( 'post-new.php?post_type=' . Post_Types::SERVICE ),
				'addStaff'   => admin_url( 'post-new.php?post_type=' . Post_Types::STAFF ),
			),
		);
		wp_add_inline_script( generate_block_asset_handle( self::NAME, 'editorScript' ), 'window.slotsmithBlock = ' . wp_json_encode( $data ) . ';', 'before' );
	}
}
