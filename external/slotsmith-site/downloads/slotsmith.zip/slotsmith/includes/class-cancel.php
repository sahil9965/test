<?php
namespace Slotsmith;

defined( 'ABSPATH' ) || exit;

/**
 * Lets customers cancel from the link in their email.
 *
 * The link opens a confirmation page; the booking is only cancelled when the
 * customer presses the button, so email scanners that open links cannot cancel it.
 * The page is a small standalone screen in the booking form's style, so it looks
 * the same with every theme.
 */
final class Cancel {

	/** Nonce action prefix; the booking token is appended, so a nonce only works for its own booking. */
	const NONCE_ACTION = 'slotsmith_cancel_';

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'handle' ) );
	}

	public static function handle() {
		if ( ! isset( $_GET['slotsmith_cancel'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the secret token in the link identifies the booking; the button below is protected by a nonce.
			return;
		}

		// Page caches must never keep this screen: it holds a one-time form and a private link.
		Shortcode::no_page_cache();

		$token   = sanitize_text_field( wp_unslash( $_GET['slotsmith_cancel'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$booking = preg_match( '/^[a-f0-9]{32}$/', $token ) ? Bookings::get_by_token( $token ) : null;

		if ( ! $booking ) {
			self::page( 'alert', __( 'Link not valid', 'slotsmith' ), __( 'This cancellation link is not valid. It may have been copied incompletely.', 'slotsmith' ), '', 404 );
		}

		$summary = self::summary( $booking );

		if ( 'cancelled' === $booking['status'] ) {
			self::page( 'done', __( 'Booking cancelled', 'slotsmith' ), __( 'This booking is already cancelled.', 'slotsmith' ), $summary . self::home_button( __( 'Book another time', 'slotsmith' ) ) );
		}

		if ( Bookings::start_timestamp( $booking ) <= time() ) {
			self::page( 'alert', __( 'Too late to cancel online', 'slotsmith' ), __( 'This appointment has already started, so it can no longer be cancelled online. Please contact us.', 'slotsmith' ), $summary );
		}

		$message = __( 'The time will be released for other customers. This cannot be undone.', 'slotsmith' );

		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['slotsmith_confirm_cancel'] ) ) {
			$nonce = isset( $_POST['slotsmith_cancel_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['slotsmith_cancel_nonce'] ) ) : '';

			if ( wp_verify_nonce( $nonce, self::NONCE_ACTION . $token ) ) {
				Bookings::update_status( $booking['id'], 'cancelled', 'customer' );
				self::page( 'done', __( 'Booking cancelled', 'slotsmith' ), __( 'Your booking has been cancelled. We have emailed you a confirmation.', 'slotsmith' ), $summary . self::home_button( __( 'Book another time', 'slotsmith' ) ) );
			}

			// An old tab, or a form that was not sent from this page: nothing is cancelled, ask again.
			$message = __( 'This page had expired, so your booking was not cancelled yet. Please confirm again.', 'slotsmith' );
		}

		$actions  = '<form class="ssm-cancel-actions" method="post" action="' . esc_url( Emails::cancel_url( $booking ) ) . '">';
		$actions .= wp_nonce_field( self::NONCE_ACTION . $token, 'slotsmith_cancel_nonce', false, false );
		$actions .= '<a class="ssm-btn ssm-btn-ghost" href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'No, keep it', 'slotsmith' ) . '</a>';
		$actions .= '<button type="submit" name="slotsmith_confirm_cancel" value="1" class="ssm-btn ssm-btn-danger">' . esc_html__( 'Yes, cancel booking', 'slotsmith' ) . '</button>';
		$actions .= '</form>';

		self::page( 'question', __( 'Cancel this booking?', 'slotsmith' ), $message, $summary . $actions );
	}

	private static function summary( array $booking ) {
		$start = Bookings::start_timestamp( $booking );
		$rows  = array(
			__( 'Service', 'slotsmith' ) => Post_Types::title( (int) $booking['service_id'] ),
			__( 'With', 'slotsmith' )    => Post_Types::title( (int) $booking['staff_id'] ),
			__( 'Date', 'slotsmith' )    => wp_date( get_option( 'date_format' ), $start ),
			__( 'Time', 'slotsmith' )    => wp_date( get_option( 'time_format' ), $start ),
		);

		$html = '<dl class="ssm-summary-list ssm-cancel-summary' . ( 'cancelled' === $booking['status'] ? ' is-cancelled' : '' ) . '">';
		foreach ( $rows as $label => $value ) {
			$html .= '<div><dt>' . esc_html( $label ) . '</dt><dd>' . esc_html( $value ) . '</dd></div>';
		}
		return $html . '</dl>';
	}

	private static function home_button( $label ) {
		return '<div class="ssm-cancel-actions"><a class="ssm-btn ssm-btn-primary" href="' . esc_url( self::booking_page_url() ) . '">' . esc_html( $label ) . '</a></div>';
	}

	/**
	 * The first published page with the booking form, or the home page.
	 */
	private static function booking_page_url() {
		foreach ( array( '[slotsmith', 'wp:' . Block::NAME ) as $needle ) {
			$pages = get_posts(
				array(
					'post_type'   => 'page',
					'post_status' => 'publish',
					's'           => $needle,
					'numberposts' => 5,
				)
			);
			foreach ( $pages as $page ) {
				if ( has_shortcode( $page->post_content, 'slotsmith' ) || has_block( Block::NAME, $page ) ) {
					return get_permalink( $page );
				}
			}
		}
		return home_url( '/' );
	}

	/**
	 * Prints a standalone page and stops.
	 *
	 * @param string $icon  'question', 'done' or 'alert'.
	 * @param string $body  Escaped HTML shown under the message.
	 */
	private static function page( $icon, $title, $message, $body = '', $status = 200 ) {
		$accent = sanitize_hex_color( Settings::get( 'accent_color' ) );
		$site   = Emails::site_name();
		$icons  = array(
			'question' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4M10 14l4 4M14 14l-4 4"/></svg>',
			'done'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
			'alert'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5M12 16.5v.01"/></svg>',
		);

		status_header( $status );
		nocache_headers();
		header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
		?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex">
	<title><?php echo esc_html( $title . ' – ' . $site ); ?></title>
	<?php
	if ( ! wp_style_is( 'slotsmith', 'registered' ) ) {
		Shortcode::register_assets();
	}
	wp_register_style( 'slotsmith-cancel', SLOTSMITH_URL . 'assets/css/cancel.css', array( 'slotsmith' ), Plugin::asset_version( 'assets/css/cancel.css' ) );
	wp_print_styles( array( 'slotsmith', 'slotsmith-cancel' ) );
	?>
</head>
<body>
	<a class="ssm-cancel-site" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( $site ); ?></a>
	<main class="ssm ssm-cancel" style="--ssm-accent:<?php echo esc_attr( $accent ? $accent : '#4f46e5' ); ?>">
		<div class="ssm-body">
			<span class="ssm-done-icon<?php echo 'done' === $icon ? '' : ' is-' . esc_attr( $icon ); ?>"><span class="ssm-icon" aria-hidden="true"><?php echo $icons[ $icon ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></span></span>
			<h1 class="ssm-title"><?php echo esc_html( $title ); ?></h1>
			<p class="ssm-cancel-message"><?php echo esc_html( $message ); ?></p>
			<?php echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts. ?>
		</div>
	</main>
</body>
</html>
		<?php
		exit;
	}
}
