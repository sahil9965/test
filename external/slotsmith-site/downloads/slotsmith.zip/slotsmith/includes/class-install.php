<?php
namespace Slotsmith;

defined( 'ABSPATH' ) || exit;

/**
 * Creates and upgrades the bookings table.
 */
final class Install {

	const DB_VERSION = '1';

	public static function activate() {
		self::create_tables();
		add_option( Settings::OPTION, Settings::defaults() );
		Setup::on_activate();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'slotsmith_db_version' ) !== self::DB_VERSION ) {
			self::create_tables();
		}
	}

	public static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = Bookings::table();
		$charset = $wpdb->get_charset_collate();

		// All datetimes are stored in UTC. blocked_until = end_at + the service buffer.
		dbDelta(
			"CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			service_id bigint(20) unsigned NOT NULL,
			staff_id bigint(20) unsigned NOT NULL,
			start_at datetime NOT NULL,
			end_at datetime NOT NULL,
			blocked_until datetime NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			customer_name varchar(190) NOT NULL,
			customer_email varchar(190) NOT NULL,
			customer_phone varchar(50) NOT NULL DEFAULT '',
			notes text NULL,
			token char(32) NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY staff_time (staff_id,start_at),
			KEY status (status),
			KEY token (token)
			) {$charset};"
		);

		update_option( 'slotsmith_db_version', self::DB_VERSION );
	}
}
