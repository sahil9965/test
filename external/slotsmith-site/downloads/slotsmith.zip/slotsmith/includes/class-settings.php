<?php
namespace Slotsmith;

defined( 'ABSPATH' ) || exit;

/**
 * Plugin-wide settings, stored in a single option.
 */
final class Settings {

	const OPTION = 'slotsmith_settings';
	const GROUP  = 'slotsmith_settings_group';

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	public static function defaults() {
		return array(
			'slot_interval'       => 30,
			'min_notice_hours'    => 2,
			'max_days_ahead'      => 60,
			'default_status'      => 'pending',
			'notify_email'        => get_option( 'admin_email' ),
			'currency'            => '$',
			'currency_code'       => '',
			'accent_color'        => '#4f46e5',
			'font_family'         => '',
			'corners'             => 'rounded',
			'delete_on_uninstall' => 0,
		);
	}

	/**
	 * Currencies offered in the Settings dropdown: code => array( symbol, name ).
	 * Choosing one sets the symbol prices show, and (with Slotsmith Pro) the currency payments are charged in.
	 */
	public static function currencies() {
		return array(
			'USD' => array( '$', __( 'US dollar', 'slotsmith' ) ),
			'INR' => array( '₹', __( 'Indian rupee', 'slotsmith' ) ),
			'EUR' => array( '€', __( 'Euro', 'slotsmith' ) ),
			'GBP' => array( '£', __( 'British pound', 'slotsmith' ) ),
			'AUD' => array( '$', __( 'Australian dollar', 'slotsmith' ) ),
			'CAD' => array( '$', __( 'Canadian dollar', 'slotsmith' ) ),
			'NZD' => array( '$', __( 'New Zealand dollar', 'slotsmith' ) ),
			'SGD' => array( '$', __( 'Singapore dollar', 'slotsmith' ) ),
			'HKD' => array( '$', __( 'Hong Kong dollar', 'slotsmith' ) ),
			'MXN' => array( '$', __( 'Mexican peso', 'slotsmith' ) ),
			'AED' => array( 'AED', __( 'UAE dirham', 'slotsmith' ) ),
			'JPY' => array( '¥', __( 'Japanese yen', 'slotsmith' ) ),
			'CNY' => array( '¥', __( 'Chinese yuan', 'slotsmith' ) ),
			'ZAR' => array( 'R', __( 'South African rand', 'slotsmith' ) ),
			'BRL' => array( 'R$', __( 'Brazilian real', 'slotsmith' ) ),
			'PHP' => array( '₱', __( 'Philippine peso', 'slotsmith' ) ),
			'MYR' => array( 'RM', __( 'Malaysian ringgit', 'slotsmith' ) ),
			'PKR' => array( 'Rs', __( 'Pakistani rupee', 'slotsmith' ) ),
			'BDT' => array( '৳', __( 'Bangladeshi taka', 'slotsmith' ) ),
			'LKR' => array( 'Rs', __( 'Sri Lankan rupee', 'slotsmith' ) ),
			'NGN' => array( '₦', __( 'Nigerian naira', 'slotsmith' ) ),
			'KES' => array( 'KSh', __( 'Kenyan shilling', 'slotsmith' ) ),
			'THB' => array( '฿', __( 'Thai baht', 'slotsmith' ) ),
			'IDR' => array( 'Rp', __( 'Indonesian rupiah', 'slotsmith' ) ),
			'TRY' => array( '₺', __( 'Turkish lira', 'slotsmith' ) ),
			'ILS' => array( '₪', __( 'Israeli shekel', 'slotsmith' ) ),
			'PLN' => array( 'zł', __( 'Polish złoty', 'slotsmith' ) ),
			'CHF' => array( 'CHF', __( 'Swiss franc', 'slotsmith' ) ),
			'SEK' => array( 'kr', __( 'Swedish krona', 'slotsmith' ) ),
			'NOK' => array( 'kr', __( 'Norwegian krone', 'slotsmith' ) ),
			'DKK' => array( 'kr', __( 'Danish krone', 'slotsmith' ) ),
		);
	}

	/**
	 * The currency code to preselect for sites that only have a symbol saved ('' when it matches none).
	 */
	public static function code_for_symbol( $symbol ) {
		foreach ( self::currencies() as $code => $currency ) {
			if ( $currency[0] === trim( (string) $symbol ) ) {
				return $code;
			}
		}
		return '';
	}

	/**
	 * True when the site is on plain UTC, WordPress's default for new sites, so booking times would show in UTC.
	 */
	public static function timezone_looks_unset() {
		return in_array( strtoupper( wp_timezone_string() ), array( 'UTC', '+00:00', 'UTC+0', 'UTC+00:00' ), true );
	}

	public static function all() {
		return wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() );
	}

	public static function get( $key ) {
		$settings = self::all();
		return isset( $settings[ $key ] ) ? $settings[ $key ] : null;
	}

	public static function enqueue( $hook ) {
		if ( false !== strpos( (string) $hook, 'slotsmith-settings' ) ) {
			wp_enqueue_script( 'slotsmith-settings', SLOTSMITH_URL . 'assets/js/settings.js', array(), Plugin::asset_version( 'assets/js/settings.js' ), true );
		}
	}

	public static function register() {
		register_setting(
			self::GROUP,
			self::OPTION,
			array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) )
		);
	}

	/** Corner styles for the booking form: key => array( label, card radius, control radius ). */
	public static function corner_styles() {
		return array(
			'rounded' => array( __( 'Rounded', 'slotsmith' ), '20px', '12px' ),
			'soft'    => array( __( 'Slightly rounded', 'slotsmith' ), '12px', '8px' ),
			'square'  => array( __( 'Square', 'slotsmith' ), '4px', '3px' ),
		);
	}

	/** Font names shown as suggestions under the font box. Empty means the theme's font. */
	public static function font_suggestions() {
		return array( 'system-ui', 'Georgia', 'Helvetica', 'Verdana', 'Trebuchet MS' );
	}

	/**
	 * A font family list typed by the site owner, reduced to safe characters (letters, digits, spaces,
	 * hyphens, commas and quotes), so it can go straight into a CSS variable.
	 */
	public static function clean_font( $value ) {
		$value = preg_replace( '/[^A-Za-z0-9 ,\'"\-]/', '', (string) $value );
		return trim( substr( $value, 0, 120 ) );
	}

	/**
	 * Inline CSS variables for the booking form: brand colour, font and corners.
	 * Developers can override any of them in their theme with .ssm { --ssm-accent: ...; }.
	 */
	public static function style_vars() {
		$accent  = sanitize_hex_color( self::get( 'accent_color' ) );
		$corners = self::corner_styles();
		$corner  = isset( $corners[ self::get( 'corners' ) ] ) ? $corners[ self::get( 'corners' ) ] : $corners['rounded'];
		$vars    = '--ssm-accent:' . ( $accent ? $accent : '#4f46e5' ) . ';--ssm-card-radius:' . $corner[1] . ';--ssm-radius:' . $corner[2] . ';--ssm-radius-sm:' . $corner[2];
		$font    = self::clean_font( self::get( 'font_family' ) );
		if ( '' !== $font ) {
			$vars .= ';--ssm-font:' . $font;
		}
		return $vars;
	}

	public static function sanitize( $input ) {
		$input    = (array) $input;
		$defaults = self::defaults();

		$interval = isset( $input['slot_interval'] ) ? absint( $input['slot_interval'] ) : $defaults['slot_interval'];
		$email    = isset( $input['notify_email'] ) ? sanitize_email( $input['notify_email'] ) : '';
		$accent   = isset( $input['accent_color'] ) ? sanitize_hex_color( $input['accent_color'] ) : '';

		// A listed currency sets both the code and its symbol. "Other" keeps the symbol typed and no code.
		$currencies = self::currencies();
		$code       = isset( $input['currency_code'] ) ? strtoupper( sanitize_text_field( $input['currency_code'] ) ) : '';
		if ( isset( $currencies[ $code ] ) ) {
			$symbol = $currencies[ $code ][0];
		} else {
			$code   = '';
			$symbol = isset( $input['currency'] ) ? substr( sanitize_text_field( $input['currency'] ), 0, 5 ) : $defaults['currency'];
		}

		return array(
			'slot_interval'       => in_array( $interval, array( 5, 10, 15, 20, 30, 45, 60 ), true ) ? $interval : $defaults['slot_interval'],
			'min_notice_hours'    => isset( $input['min_notice_hours'] ) ? min( 720, absint( $input['min_notice_hours'] ) ) : $defaults['min_notice_hours'],
			'max_days_ahead'      => isset( $input['max_days_ahead'] ) ? max( 1, min( 365, absint( $input['max_days_ahead'] ) ) ) : $defaults['max_days_ahead'],
			'default_status'      => ( isset( $input['default_status'] ) && 'confirmed' === $input['default_status'] ) ? 'confirmed' : 'pending',
			'notify_email'        => is_email( $email ) ? $email : $defaults['notify_email'],
			'currency'            => $symbol,
			'currency_code'       => $code,
			'accent_color'        => $accent ? $accent : $defaults['accent_color'],
			'font_family'         => self::clean_font( isset( $input['font_family'] ) ? $input['font_family'] : '' ),
			'corners'             => ( isset( $input['corners'] ) && isset( self::corner_styles()[ $input['corners'] ] ) ) ? $input['corners'] : 'rounded',
			'delete_on_uninstall' => empty( $input['delete_on_uninstall'] ) ? 0 : 1,
		);
	}

	public static function render_page() {
		if ( ! current_user_can( Plugin::capability() ) ) {
			return;
		}

		$s    = self::all();
		$name = self::OPTION;
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Slotsmith Settings', 'slotsmith' ); ?></h1>

			<form method="post" action="options.php">
				<?php settings_fields( self::GROUP ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="slotsmith-interval"><?php esc_html_e( 'Time slot interval', 'slotsmith' ); ?></label></th>
						<td>
							<select id="slotsmith-interval" name="<?php echo esc_attr( $name ); ?>[slot_interval]">
								<?php foreach ( array( 5, 10, 15, 20, 30, 45, 60 ) as $minutes ) : ?>
									<option value="<?php echo esc_attr( $minutes ); ?>" <?php selected( (int) $s['slot_interval'], $minutes ); ?>>
										<?php
										/* translators: %d: number of minutes */
										echo esc_html( sprintf( __( 'Every %d minutes', 'slotsmith' ), $minutes ) );
										?>
									</option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'How often a new start time is offered (e.g. 9:00, 9:30, 10:00).', 'slotsmith' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="slotsmith-notice"><?php esc_html_e( 'Minimum notice (hours)', 'slotsmith' ); ?></label></th>
						<td>
							<input id="slotsmith-notice" type="number" min="0" max="720" class="small-text" name="<?php echo esc_attr( $name ); ?>[min_notice_hours]" value="<?php echo esc_attr( $s['min_notice_hours'] ); ?>">
							<p class="description"><?php esc_html_e( 'Customers cannot book a slot that starts sooner than this.', 'slotsmith' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="slotsmith-ahead"><?php esc_html_e( 'Booking window (days)', 'slotsmith' ); ?></label></th>
						<td>
							<input id="slotsmith-ahead" type="number" min="1" max="365" class="small-text" name="<?php echo esc_attr( $name ); ?>[max_days_ahead]" value="<?php echo esc_attr( $s['max_days_ahead'] ); ?>">
							<p class="description"><?php esc_html_e( 'How many days ahead customers can book.', 'slotsmith' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'New bookings', 'slotsmith' ); ?></th>
						<td>
							<fieldset>
								<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[default_status]" value="pending" <?php checked( $s['default_status'], 'pending' ); ?>> <?php esc_html_e( 'Need my approval (pending)', 'slotsmith' ); ?></label><br>
								<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[default_status]" value="confirmed" <?php checked( $s['default_status'], 'confirmed' ); ?>> <?php esc_html_e( 'Are confirmed automatically', 'slotsmith' ); ?></label>
							</fieldset>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="slotsmith-email"><?php esc_html_e( 'Notification email', 'slotsmith' ); ?></label></th>
						<td>
							<input id="slotsmith-email" type="email" class="regular-text" name="<?php echo esc_attr( $name ); ?>[notify_email]" value="<?php echo esc_attr( $s['notify_email'] ); ?>">
							<p class="description"><?php esc_html_e( 'Where new booking and cancellation emails are sent.', 'slotsmith' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="slotsmith-currency-code"><?php esc_html_e( 'Currency', 'slotsmith' ); ?></label></th>
						<td>
							<?php $chosen = $s['currency_code'] ? $s['currency_code'] : self::code_for_symbol( $s['currency'] ); ?>
							<select id="slotsmith-currency-code" name="<?php echo esc_attr( $name ); ?>[currency_code]">
								<?php foreach ( self::currencies() as $code => $currency ) : ?>
									<option value="<?php echo esc_attr( $code ); ?>" data-symbol="<?php echo esc_attr( $currency[0] ); ?>" <?php selected( $chosen, $code ); ?>><?php echo esc_html( $currency[0] . ' ' . $currency[1] . ' (' . $code . ')' ); ?></option>
								<?php endforeach; ?>
								<option value="" <?php selected( $chosen, '' ); ?>><?php esc_html_e( 'Other (type your own symbol)', 'slotsmith' ); ?></option>
							</select>
							<input id="slotsmith-currency" type="text" class="small-text" name="<?php echo esc_attr( $name ); ?>[currency]" value="<?php echo esc_attr( $s['currency'] ); ?>" aria-label="<?php esc_attr_e( 'Custom currency symbol', 'slotsmith' ); ?>">
							<p class="description"><?php esc_html_e( 'The symbol shown next to prices follows the currency you choose. The box is only used for “Other”.', 'slotsmith' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="slotsmith-accent"><?php esc_html_e( 'Brand colour', 'slotsmith' ); ?></label></th>
						<td>
							<input id="slotsmith-accent" type="color" name="<?php echo esc_attr( $name ); ?>[accent_color]" value="<?php echo esc_attr( $s['accent_color'] ); ?>">
							<p class="description"><?php esc_html_e( 'Used for buttons and selected items in the booking form.', 'slotsmith' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="slotsmith-font"><?php esc_html_e( 'Font', 'slotsmith' ); ?></label></th>
						<td>
							<input id="slotsmith-font" type="text" class="regular-text" list="slotsmith-font-list" name="<?php echo esc_attr( $name ); ?>[font_family]" value="<?php echo esc_attr( $s['font_family'] ); ?>" placeholder="<?php esc_attr_e( 'Your theme’s font', 'slotsmith' ); ?>">
							<datalist id="slotsmith-font-list">
								<?php foreach ( self::font_suggestions() as $font ) : ?>
									<option value="<?php echo esc_attr( $font ); ?>"></option>
								<?php endforeach; ?>
							</datalist>
							<p class="description"><?php esc_html_e( 'Leave empty to use your theme’s font (recommended). Or type a font your site already loads, for example “Poppins”.', 'slotsmith' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="slotsmith-corners"><?php esc_html_e( 'Corners', 'slotsmith' ); ?></label></th>
						<td>
							<select id="slotsmith-corners" name="<?php echo esc_attr( $name ); ?>[corners]">
								<?php foreach ( self::corner_styles() as $key => $style ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $s['corners'], $key ); ?>><?php echo esc_html( $style[0] ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Developers: every colour, radius and the font are CSS variables on .ssm (for example --ssm-accent, --ssm-font, --ssm-radius), so a theme can override them.', 'slotsmith' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Uninstall', 'slotsmith' ); ?></th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[delete_on_uninstall]" value="1" <?php checked( $s['delete_on_uninstall'], 1 ); ?>> <?php esc_html_e( 'Delete all bookings, services, staff and settings when the plugin is deleted', 'slotsmith' ); ?></label>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>

			<h2><?php esc_html_e( 'Show the booking form', 'slotsmith' ); ?></h2>
			<p><?php esc_html_e( 'In the block editor, add the Booking form block to any page. Its sidebar can preselect a service and staff member.', 'slotsmith' ); ?></p>
			<p>
				<?php esc_html_e( 'With the classic editor or a page builder, use this shortcode:', 'slotsmith' ); ?>
				<code>[slotsmith]</code>
			</p>
			<p>
				<?php esc_html_e( 'To preselect a service or staff member, add their ID:', 'slotsmith' ); ?>
				<code>[slotsmith service="12" staff="7"]</code>
			</p>

			<p><a href="<?php echo esc_url( Setup::url( 'business' ) ); ?>"><?php esc_html_e( 'Run the setup wizard again', 'slotsmith' ); ?></a> <span class="description"><?php esc_html_e( '(adds services, staff and a booking page; nothing you have is deleted)', 'slotsmith' ); ?></span></p>
			<?php Admin::render_upgrade_card(); ?>
		</div>
		<?php
	}
}
