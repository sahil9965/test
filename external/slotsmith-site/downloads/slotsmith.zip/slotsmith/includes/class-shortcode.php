<?php
namespace Slotsmith;

defined( 'ABSPATH' ) || exit;

/**
 * The [slotsmith] booking form. The markup is built by assets/js/booking.js
 * from the JSON data printed here.
 */
final class Shortcode {

	public static function init() {
		add_shortcode( 'slotsmith', array( __CLASS__, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
	}

	public static function register_assets() {
		wp_register_style( 'slotsmith', SLOTSMITH_URL . 'assets/css/booking.css', array(), Plugin::asset_version( 'assets/css/booking.css' ) );
		wp_register_script( 'slotsmith', SLOTSMITH_URL . 'assets/js/booking.js', array(), Plugin::asset_version( 'assets/js/booking.js' ), true );
		wp_add_inline_script(
			'slotsmith',
			'window.slotsmithConfig = ' . wp_json_encode(
				array(
					'restUrl'     => esc_url_raw( rest_url( Rest::NAMESPACE_V1 . '/' ) ),
					// Only logged-in users need it (booking is public). A guest's token would expire inside a cached page.
					'nonce'       => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
					'locale'      => str_replace( '_', '-', get_locale() ),
					'startOfWeek' => (int) get_option( 'start_of_week', 1 ),
					'siteName'    => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
					'i18n'        => array(
						'steps'            => array( __( 'Service', 'slotsmith' ), __( 'Date & time', 'slotsmith' ), __( 'Your details', 'slotsmith' ) ),
						'chooseService'    => __( 'Choose a service', 'slotsmith' ),
						'chooseStaff'      => __( 'Choose a professional', 'slotsmith' ),
						'anyone'           => __( 'Anyone', 'slotsmith' ),
						'anyoneSub'        => __( 'First available', 'slotsmith' ),
						'pickDateTime'     => __( 'Pick a date and time', 'slotsmith' ),
						'selectDate'       => __( 'Select a date to see times.', 'slotsmith' ),
						'noTimes'          => __( 'No times left on this day.', 'slotsmith' ),
						'noDays'           => __( 'Fully booked this month. Try the next month.', 'slotsmith' ),
						'morning'          => __( 'Morning', 'slotsmith' ),
						'afternoon'        => __( 'Afternoon', 'slotsmith' ),
						'evening'          => __( 'Evening', 'slotsmith' ),
						'prevMonth'        => __( 'Previous month', 'slotsmith' ),
						'nextMonth'        => __( 'Next month', 'slotsmith' ),
						'yourDetails'      => __( 'Your details', 'slotsmith' ),
						'name'             => __( 'Full name', 'slotsmith' ),
						'email'            => __( 'Email', 'slotsmith' ),
						'phone'            => __( 'Phone', 'slotsmith' ),
						'notes'            => __( 'Anything we should know?', 'slotsmith' ),
						'optional'         => __( 'optional', 'slotsmith' ),
						'summary'          => __( 'Booking summary', 'slotsmith' ),
						'service'          => __( 'Service', 'slotsmith' ),
						'with'             => __( 'With', 'slotsmith' ),
						/* translators: 1: service name, 2: staff member name */
						'serviceWith'      => __( '%1$s with %2$s', 'slotsmith' ),
						'date'             => __( 'Date', 'slotsmith' ),
						'time'             => __( 'Time', 'slotsmith' ),
						'duration'         => __( 'Duration', 'slotsmith' ),
						/* translators: %d: number of minutes */
						'durMin'           => __( '%d min', 'slotsmith' ),
						/* translators: %s: number of hours, e.g. 1 or 1.5 */
						'durHrOne'         => _n( '%s hr', '%s hrs', 1, 'slotsmith' ),
						/* translators: %s: number of hours, e.g. 1 or 1.5 */
						'durHrMany'        => _n( '%s hr', '%s hrs', 2, 'slotsmith' ),
						'price'            => __( 'Price', 'slotsmith' ),
						'payInPerson'      => __( 'Pay at your appointment', 'slotsmith' ),
						'continue'         => __( 'Continue', 'slotsmith' ),
						'back'             => __( 'Back', 'slotsmith' ),
						'confirm'          => __( 'Confirm booking', 'slotsmith' ),
						'booking'          => __( 'Booking…', 'slotsmith' ),
						'bookedTitle'      => __( 'You’re booked!', 'slotsmith' ),
						'requestedTitle'   => __( 'Request received', 'slotsmith' ),
						'addToCalendar'    => __( 'Add to calendar', 'slotsmith' ),
						'bookAnother'      => __( 'Book another appointment', 'slotsmith' ),
						'error'            => __( 'Something went wrong. Please try again.', 'slotsmith' ),
						'pickService'      => __( 'No service selected', 'slotsmith' ),
					),
				)
			) . ';',
			'before'
		);
	}

	public static function render( $atts ) {
		$atts = shortcode_atts(
			array(
				'service' => 0,
				'staff'   => 0,
			),
			$atts,
			'slotsmith'
		);

		$services = Post_Types::services();
		$staff    = Post_Types::staff();

		if ( ! $services || ! $staff ) {
			if ( current_user_can( Plugin::capability() ) ) {
				return '<p class="slotsmith-notice">' . esc_html__( 'Slotsmith: add at least one service and one staff member offering it to show the booking form.', 'slotsmith' ) . '</p>';
			}
			return '';
		}

		wp_enqueue_style( 'slotsmith' );
		wp_enqueue_script( 'slotsmith' );
		self::no_page_cache();

		$tz    = wp_timezone();
		$today = new \DateTimeImmutable( 'now', $tz );

		$data = array(
			'today'     => $today->format( 'Y-m-d' ),
			'maxDate'   => $today->modify( '+' . (int) Settings::get( 'max_days_ahead' ) . ' days' )->format( 'Y-m-d' ),
			'preselect' => array(
				'service' => (int) $atts['service'],
				'staff'   => (int) $atts['staff'],
			),
			'services'  => array_map(
				function ( $service ) {
					return array(
						'id'          => $service['id'],
						'name'        => $service['name'],
						'description' => $service['description'],
						'duration'      => $service['duration'],
						'durationLabel' => self::duration_label( $service['duration'] ),
						'price'         => Post_Types::format_price( $service['price'] ),
						'photo'         => $service['photo'],
					);
				},
				$services
			),
			'staff'     => array_map(
				function ( $member ) {
					return array(
						'id'       => $member['id'],
						'name'     => $member['name'],
						'services' => $member['services'],
						'photo'    => $member['photo'],
					);
				},
				$staff
			),
		);

		// Coming back from an add-on step such as payment: show the result screen.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the secret token identifies the booking.
		$token = isset( $_GET['slotsmith_booking'] ) ? sanitize_text_field( wp_unslash( $_GET['slotsmith_booking'] ) ) : '';
		if ( preg_match( '/^[a-f0-9]{32}$/', $token ) ) {
			$booking = Bookings::get_by_token( $token );
			if ( $booking ) {
				$data['returned'] = Rest::summary( $booking );
			}
		}

		/**
		 * Filters the data the booking form is built from (e.g. to add service extras or form fields).
		 *
		 * @param array $data Form data.
		 * @param array $atts Shortcode attributes.
		 */
		$data = apply_filters( 'slotsmith_form_data', $data, $atts );

		return sprintf(
			'<div class="ssm" data-slotsmith style="%1$s"><script type="application/json" class="ssm-data">%2$s</script><noscript><p>%3$s</p></noscript></div>',
			esc_attr( Settings::style_vars() ),
			wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ),
			esc_html__( 'Please enable JavaScript to book an appointment.', 'slotsmith' )
		);
	}

	/**
	 * The form carries today's date and the current settings, so a cached copy goes stale: ask page
	 * caches to skip this page. WP Rocket, W3 Total Cache, WP Super Cache and LiteSpeed Cache honour it.
	 */
	public static function no_page_cache() {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- the standard flag read by page caches.
		}
		do_action( 'litespeed_control_set_nocache', 'Slotsmith booking form' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LiteSpeed Cache's own hook.
	}

	private static function duration_label( $minutes ) {
		if ( $minutes < 60 || $minutes % 30 ) {
			/* translators: %d: number of minutes */
			return sprintf( __( '%d min', 'slotsmith' ), $minutes );
		}
		$hours = $minutes / 60;
		/* translators: %s: number of hours, e.g. 1 or 1.5 */
		return sprintf( _n( '%s hr', '%s hrs', (int) ceil( $hours ), 'slotsmith' ), number_format_i18n( $hours, $minutes % 60 ? 1 : 0 ) );
	}
}
