=== Slotsmith – Appointment Booking ===
Contributors: roohsites
Tags: appointment booking, booking, scheduling, salon, calendar
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A beautiful, mobile-friendly booking form for salons, tutors and coaches. Unlimited staff and services, free.

== Description ==

Slotsmith lets your customers book appointments on your website in under a minute — no phone calls, no back-and-forth messages, no double bookings.

Add your services and staff, put the **Booking form** block (or the `[slotsmith]` shortcode) on a page, and you're taking bookings. It is built for **salons, barbers, spas, tutors, coaches, therapists, consultants** and any business that sells time.

= A booking form your customers will enjoy =

* **Three clear steps:** choose a service and professional → pick a date and time → enter details.
* **A real calendar** that only lets customers pick days with free times.
* **Times grouped** into morning, afternoon and evening.
* **Booking summary** with price and duration before confirming.
* **"Add to calendar"** button on the confirmation screen.
* **Mobile first:** large tap targets and a sticky Continue bar on phones.
* **Your brand colour** throughout, and it inherits your theme's fonts.

= Unlimited and free =

* Unlimited services — each with its own duration, price, buffer time and description.
* Unlimited staff — each with photo, weekly hours, days off and the services they offer.
* "Anyone available" option that books the first free professional.
* No double bookings: times are re-checked at the moment of booking.

= Simple for you to run =

* Bookings screen with Upcoming, Pending, Confirmed, Cancelled and Past views.
* Approve bookings yourself, or confirm them automatically.
* Email notifications for the customer, the staff member and you.
* Customers can cancel from a secure link in their email.
* Minimum notice and how far ahead customers can book.
* Spam protection with a hidden honeypot field and rate limiting.
* **Booking form block** for the block editor, and a `[slotsmith]` shortcode for page builders.
* Works with WordPress's privacy tools (export and erase a customer's data).
* Pick your currency from a list: the symbol on prices follows it.
* Warns you when your site's time zone is still UTC, so customers see the right times.
* Translation-ready.

= Slotsmith Pro =

Need more? [Slotsmith Pro](https://slotsmith.roohsites.com/) adds online payments and deposits (Razorpay/UPI, Stripe, PayPal), SMS and WhatsApp reminders, two-way Google Calendar sync, a drag-and-drop admin calendar, customer rescheduling, service extras, coupons, custom form questions and branded emails. The free plugin is fully usable on its own.

== Installation ==

1. In your dashboard go to **Plugins → Add New**, search for "Slotsmith" and click **Install**, then **Activate**.
2. Go to **Slotsmith → Services** and add your services (name, duration, price).
3. Go to **Slotsmith → Staff**, add each person, tick the services they offer and set their working hours.
4. Create a page (for example "Book") and add the **Booking form** block. With the classic editor or a page builder, use the `[slotsmith]` shortcode instead.
5. Optional: under **Slotsmith → Settings**, choose your brand colour, currency, slot interval and whether bookings need your approval.

== Frequently Asked Questions ==

= Does it work with my theme and page builder? =

Yes. The booking form is self-contained, so it looks the same with any theme. In the block editor, add the Booking form block. In Elementor, Divi, Beaver Builder and other builders, put `[slotsmith]` in their shortcode widget.

= Can I preselect a service or staff member? =

Yes. Select the Booking form block and pick them in the sidebar under **Start with**. With the shortcode: `[slotsmith service="12"]` or `[slotsmith service="12" staff="7"]`. The IDs are shown in the Services and Staff lists.

= Customers are not receiving emails. What should I do? =

Many hosts do not deliver WordPress email reliably. Install an SMTP plugin such as WP Mail SMTP or FluentSMTP and connect it to your email provider. Slotsmith uses the standard WordPress mail function, so it works with all of them.

= Which time zone is used? =

The time zone set in **Settings → General**. Make sure it is your business's local time zone.

= Can staff have a lunch break or different hours on holidays? =

Days off are included. Breaks and special opening hours are part of Slotsmith Pro.

= Can customers pay online? =

Online payments and deposits are part of Slotsmith Pro. In the free plugin, prices are shown and paid at the appointment.

= Is it GDPR friendly? =

Slotsmith stores the booking details your customers enter (name, email, phone, notes) in your own WordPress database and sends them nowhere else. It sets no cookies and loads no external scripts or fonts. It works with WordPress's privacy tools: **Tools → Export Personal Data** includes a customer's bookings, and **Tools → Erase Personal Data** removes their details from past and cancelled bookings. Suggested text for your privacy policy is under **Settings → Privacy**.

= Does it work with caching plugins? =

Yes. Pages with the booking form tell caching plugins (LiteSpeed Cache, WP Rocket, W3 Total Cache, WP Super Cache and others) not to cache them, so customers always see today's free times and your current settings. The rest of your site stays cached.

= What happens to my data if I delete the plugin? =

Nothing, unless you tick "Delete all data when the plugin is deleted" under **Slotsmith → Settings**.

== Screenshots ==

1. Step 1: choose a service and a professional.
2. Step 2: pick a date on the calendar and a free time.
3. Step 3: your details and the booking summary.
4. Booking confirmed, with "Add to calendar".
5. The booking form on a phone.
6. Bookings screen in the WordPress dashboard.
7. Staff member: services offered, weekly hours and days off.
8. Settings: slot interval, notice, approval and brand colour.
9. The Booking form block in the editor, with the service to start with.

== Changelog ==

= 1.0.0 =
* First public release.
* Booking form block (pick the service and staff to start with in the sidebar); the `[slotsmith]` shortcode works too.
* Three-step booking form with service cards, staff photos, a calendar of open days and times grouped by part of day.
* Service photos on the service cards, and each time shows when the appointment ends (11:00 am – 12:00 pm).
* "Start times every" per service: back to back (service length plus buffer), every 15, 30 or 60 minutes, or the site default.
* Setup wizard: business type with ready services, opening hours, services and prices, staff, and a booking page, then a test booking. Opens once after activation, can be skipped, and can be run again from Settings.
* Bookings screen opens with summary cards: total, today, upcoming, waiting for approval, this month and cancelled. Each card opens its list.
* Brand colour, font and corner style for the booking form; every colour, radius and the font are CSS variables on .ssm.
* Unlimited services and staff, weekly hours, days off and buffer times.
* Booking approval or auto-confirm, email notifications, secure cancel link.
* Works with Tools → Export / Erase Personal Data, with suggested privacy policy text.
* Booking pages are kept out of page caches, so they always show current times and settings.
* Bookings admin screen, brand colour, currency, slot interval, notice and booking window settings.
* Developer hooks for add-ons (statuses, availability, validation, emails, booking form).

== Upgrade Notice ==

= 1.0.0 =
First public release.
