<?php
/**
 * Removes Slotsmith data, but only if the site owner opted in under Settings.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$slotsmith_settings = get_option( 'slotsmith_settings' );
if ( empty( $slotsmith_settings['delete_on_uninstall'] ) ) {
	return;
}

global $wpdb;

// Removing the plugin's own table on uninstall (only when the owner opted in above).
$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . 'slotsmith_bookings' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange

foreach ( array( 'slotsmith_service', 'slotsmith_staff' ) as $slotsmith_type ) {
	$slotsmith_ids = get_posts(
		array(
			'post_type'   => $slotsmith_type,
			'post_status' => 'any',
			'numberposts' => -1,
			'fields'      => 'ids',
		)
	);
	foreach ( $slotsmith_ids as $slotsmith_id ) {
		wp_delete_post( $slotsmith_id, true );
	}
}

delete_option( 'slotsmith_settings' );
delete_option( 'slotsmith_db_version' );
delete_option( 'slotsmith_setup' );
